# Changelog

## 0.1.25

- A tool whose schema has a `pattern` naming a UTF-16 surrogate, as REA's
  path guard `^[^\uD800-\uDFFF]*$` does, is sent without that pattern.
  Command Code turned the whole request away for it, with 400 "Invalid
  schema for function "mcp__rea__close_binary": a surrogate-range regex is
  not a valid regex" (Roing, #1604). It applies on the Provider API
  and on Go's `/alpha/generate`, for every model. Every other keyword,
  `$schema`, `allOf`, `anyOf` and `oneOf` among them, and every other
  pattern go as they came, and so does a property named `pattern`
  (Claude Code's Grep). The tool's own server still checks the guard.

## 0.1.24

- A Go, GOAT or Pro account's Credits window tells its count as well as
  its share: the credits used of the month's, in credits (amount, limit,
  unit). magpie adds several accounts' credits up where it puts them
  together, as the Usage page's "All N accounts" strip and a folded
  Routing fold of accounts, "16.40 / 30 credits", instead of a mean of
  their shares (chen2652 on magpie's Discord). Bought and free credits,
  dollars at model cost, are the account's balance, a row of their own
  under the windows, no longer "+ $5.00 extra" after the count.

## 0.1.22

- Reflection's Beam (`reflection/beam:free`) is sent each earlier assistant
  message's reasoning in `reasoning_content`: its own when the history kept
  it, the thinking sent back as `reasoning`, else a period. Beam answered a
  one-turn chat and turned the second turn away with 400 "Missing required
  parameter: 'messages[N].reasoning_content'", a reply another model made
  included (EDwinpzy on magpie's Discord). Another model the Provider API
  turns away the same way is asked once more with it filled, and is sent it
  from then on. Other models' requests go as they came.

## 0.1.20

- The Credits window of a Go, GOAT or Pro account says credits, not
  dollars: "0.20 / 70.00 credits". Command Code counts those plans in
  usage-value units ("on Go, GOAT and Pro, credits are usage-value units",
  docs/resources/usage-limits, read 2026-10-31). GOAT's 70 credits a month
  are the "up to $100" its pricing page now says on a $100 model like Ling
  3.1 Flash, and $70 on GLM-5.2; Pro's 80 are "up to $110". The 5-hour and
  weekly caps billing/credits returns (GOAT's 14 and 35) are in the same
  units, so the month stays 70 and 80, as the official CLI's table has it,
  and the card no longer calls it a dollar pool (plugins #556).
- On those plans, bought and free credits (dollars at model cost) are said
  beside the month ("+ $5.00 extra") and no longer added to a pool of
  another unit. Max, Ultra and Teams Pro, where a credit is a dollar, keep
  the CLI's pool in dollars.
- Provider is pay as you go: its $15 a month carries no credits, so its card
  shows the balance and no longer a "$x / $15.00" month.
