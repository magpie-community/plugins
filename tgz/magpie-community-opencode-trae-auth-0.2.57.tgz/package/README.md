# @magpie-community/opencode-trae-auth

Two providers, one package: **Trae CN** (trae.cn, ByteDance's AI IDE, provider
id `trae-cn`) and **Trae Global** (trae.ai, the international deployment,
provider id `trae-global`). Each signs in with its own Trae account, the way
the IDE does, and makes its model requests. The free tier works as well.

The two are separate services — different domains, a different client's
catalog, barely overlapping model lists — so they are two providers rather
than a setting. They share one implementation: the request, stream and
tool-call machinery is the same code, and each realm is a table (hosts,
client, versions, usage page, fallback models, error codes) in `index.mjs`.
A fix to that machinery reaches both.

| Provider id | Signs in to | Endpoints |
|---|---|---|
| `trae-cn` | Trae CN (trae.cn) | `api.trae.cn`, `trae-api-cn.mchost.guru` |
| `trae-global` | Trae international (trae.ai) | `growsg-normal.trae.ai`, `coresg-normal.trae.ai` (SG) / `coreva-normal.trae.ai` (US) |

> **Experimental (both).** The CN protocol was worked out from two
> open-source relays, [wangqi233/trae2api](https://github.com/wangqi233/trae2api)
> and [autumnsentiment/Trae2api-cn](https://github.com/autumnsentiment/Trae2api-cn),
> and the international one from the same relays' realm table. Neither has
> been run against a real account here: Trae CN has not been tried at all, and
> Trae Global has been tried on one Free account in the SG region only — no
> Pro and no US account. Paid-account behaviour (which models a plan lists,
> what its allowance shows) is implemented from the interface's shape, not
> confirmed on a live one. If something fails, open an issue and include the
> error magpie shows.

## Sign-in

A personal account signs in with **Trae CN account (browser)** or **Trae
Global account (browser)**; an enterprise seat has its own way (see
Enterprise below). The plugin opens that realm's authorization page
(`www.trae.cn/authorization` or `www.trae.ai/authorization`, the IDE's client
`ono9krqynydwx5`). Sign in there and allow the sign-in; the page then sends the
browser back to a callback on `http://127.0.0.1:<port>/authorize` — it accepts
no other kind of callback. The callback carries the account's Cloud-IDE-JWT,
refresh token and account. Nothing needs pasting back.

An account of one realm does not sign in to the other: trae.cn's accounts are
not trae.ai's.

At sign-in the plugin creates the account's device and names it to the
authorization page: `device_id` and `machine_id` (32 hex). Every
request then sends that same device. The relays saw requests dropped when the
device was new each time. A Trae CN `device_id` is 16 digits since 0.2.16, the
shape of the ids Trae's device service gives its clients (15 or 16 digits);
Trae Global's stays 19. The daily check-in goes on a 15-digit id made from it
(see Daily check-in).

### Enterprise (SaaS) accounts

Each provider has a second way, **Trae CN enterprise account (browser)** or
**Trae Global enterprise account (browser)**, since 0.2.46. It opens the
realm's enterprise console's own authorization page
(`console.enterprise.trae.cn/authorization` or
`console.enterprise.trae.ai/authorization`) with the same parameters and
callback. There the seat signs in with its TRAE enterprise email and
password, the Doubao/Feishu tab, or the company's SSO. Since November 2026
trae.cn's own page sends a signed-out browser to a Doubao/Feishu account
sign-in (accounts.doubao.com) that has no way to an enterprise seat, so an
enterprise account signing in again there was not recognised (@yalifesign
on X). The console's page calls back with `userJwt`, `userInfo`,
`refreshToken` and `host` (its Api host), read as below; a callback naming
no host is taken as the console's seat. Read from the consoles' page code;
**not tried with a real enterprise seat**.

Since 0.2.10 the authorization page also offers Trae's enterprise (SaaS / SSO)
sign-in; before, the plugin asked the page to hide it (`hide_saas_login`), so
an enterprise subscription could only sign in as a personal account. A host
the sign-in names for the account is kept when it is an https host on Trae's
own domains (`trae.cn`, `trae.ai`, `mchost.guru`): a model host other than the
consumer site's own (`www`, `api`, `grow…`) takes the account's model
requests, and a token host the callback names (`authHost`) takes its
renewals. Any other host is ignored and the consumer hosts are used, as for a
personal account, which is unchanged. The account's tenant and login-type
fields are kept with the sign-in; nothing sends them.

**Not tried with a real enterprise account.** Which hosts and fields an
enterprise sign-in sends back is not known yet; if yours doesn't work, open an
issue with what the sign-in page showed.

One enterprise sign-in has since been seen to name
`console.enterprise.trae.cn` as the account's host, and its usage is read
from that console (see Usage). The tenant and login-type fields are still
kept and never sent.

Such a seat chats on that console, where a chat bills the seat pool. Not
every tenant's console takes chats: one that answers 4245 marks the
account, and from then on it chats on the consumer gateway, which takes
the same login but spends the login's own credits (#1127, #1155).

The international deployment has an enterprise console too, at
`console.enterprise.trae.ai`, and the same reading is done there — **not
verified**, see Usage.

### The international realm's region

Trae Global has two deployments. The sign-in's `AIRegion` (or a US auth host
such as `api-us-east.trae.ai`) selects the US one; anything else uses the SG
one. The US account's model requests go to `coreva-normal.trae.ai` and its
usage page to `api-us-east.trae.ai`; the SG account uses
`coresg-normal.trae.ai` and `api-sg-central.trae.ai`. Nothing has to be
configured: the region rides in the saved sign-in.

## Requests

Chat completions (`@ai-sdk/openai-compatible`) are translated for the IDE
agent's `POST https://trae-api-cn.mchost.guru/api/agent/v3/llm_utils_chat`:

- **Request:**
  - The messages go as `{role, content: [{type: "text", text}]}`.
  - The model goes as `config_name` and `model`, and as `model_name` the
    `__dev` model the function's list names for it, when it names one.
  - The function is the one whose model list has the model, the first that
    names a `__dev` model for it (in the order `chat_v3`, the classic IDE's;
    `solo_work_lite`, SOLO's Work mode; `solo_agent`, the TRAE agent's;
    `solo_agent_lite`; `solo_coder`, SOLO's coder roster). If Trae answers
    4001, 4023 or 1005, the plugin tries the others once and remembers which
    one worked.
  - `session_id` is the conversation's, as the IDE keeps one per conversation:
    the session magpie (or OpenCode) names the request by, else the chat's
    first user message, which every later turn repeats, together with the
    account the request is made as. Trae counts a conversation by it, so a
    fresh one per request made one user send that takes several steps (a tool
    result sent back, a retry, another function answering) count as a
    conversation of its own — several rows in the usage detail, each under no
    title. One conversation answered by two accounts (magpie failing over, or
    rotating, inside it) is named twice then, as two conversations, so Trae
    never reads one account's conversation as another's; that costs the two
    halves of such a conversation their single row. The id is a salted hash,
    so it says nothing of the words it was made from; the salt is this
    machine's own, made once in `~/.config/magpie/trae-session-salt`
    (`MAGPIE_TRAE_SESSION_SALT` names another file), so a conversation keeps
    its `session_id` when magpie restarts the plugin (on any update). If that
    file can't be read or made, each run of the plugin has a salt of its own,
    as before 0.2.32. `request_id` is the request's own, fresh on every one.
- **Headers:** TRAE SOLO CN 0.1.69's (`x-ide-version`/`x-app-version`
  0.1.69, version code 20260917; Trae offers a model only to clients new
  enough for it): `Authorization: Cloud-IDE-JWT …`, `X-Cloudide-Token`,
  `x-app-id`, the device headers and `x-uid`.
- **Answer:** Trae always answers in its own SSE events:
  - `output` gives `response`/`content` and `reasoning_content`/`reasoning`.
    Text under `message`, `delta` or an event with no name is the answer's
    too.
  - `token_usage`, `done` and `error` mark usage, the end and failures.
    What `token_usage` says the prompt cache read and wrote
    (`cache_read_input_tokens`, `cache_creation_input_tokens`) goes on under
    those names, and `reasoning_tokens` as
    `completion_tokens_details.reasoning_tokens`. DeepSeek's
    `prompt_cache_hit_tokens` and `cached_tokens` are read as cache reads
    too. A `token_usage` that names no cache count at all goes on with
    `magpie_cache_unknown: true`, so magpie shows the cache as unknown,
    not as a 0% miss (0.2.26). So does one that counts 0 read and 0
    written: Trae answers that while it bills the turn at its cache price
    (0.2.31).
    `done`'s `finish_reason` `length`/`max_tokens` is OpenAI's `length`.
  - Queue events are ignored.
  - A `{"reasoning_content": …}` object written into the text is reasoning,
    and reasoning Trae sends again is sent once.

  The plugin turns these into an OpenAI stream or a single body. A reply
  that fails (an `error` event, or Trae's stream breaking off) ends with the
  error and `[DONE]`, with no finish.
- **Tools:**
  - The tools go natively in `tools`, with `parameters` as a JSON string.
    A past call goes back as the turn Trae made it: an assistant
    `tool_calls` message carrying it (each call
    `{id, type: "function", function_call: {name, arguments}}`) and a
    `tool` message after it answering it. Trae answers such a history with
    native calls; asked for its calls in text instead — a system prompt
    describing a `<tool_call>` block, earlier calls written out as one —
    models write them as blocks, and a block the stream cuts short is an
    error (plugins#38). Trae takes no two messages of one role in a row,
    so an assistant turn's text is folded into the calls turn after it
    and consecutive calls turns join one `tool_calls` list.
  - For a Kimi (Moonshot) model the tools' schemas are first rewritten for
    Moonshot's "moonshot flavored json schema", which Trae's 4027 "tool call
    failed" quotes when it refuses them: an `enum` or `const` with no `type`
    gets the one its values have, a `$ref` beside a `type` and a `type` beside
    an `anyOf` are written as Kimi holds them (the same rules as kimi-work's).
    The request's own tools are not changed, and a schema Kimi takes as it is
    goes byte for byte. Other models' tools go as they are.
  - A call with no name is dropped, and the `tool` result answering it
    with it: Trae requires the name, and an empty `tool_calls` list with a
    result naming no call is not a turn it takes.
  - A result with no text goes as `(no output)` (`(the result's image
    follows)` when it had only an image): Trae refuses the whole request
    with 4027 when a result's text is empty, reading the calls turn as
    unanswered (measured on Trae CN in #251). A result answering no call
    the history sends goes back as text in a `user` turn.
  - A request that names no tools to Trae (none sent, or `tool_choice:
    "none"`, such as a summary) sends its past calls and results as text,
    as before: every live run of the native turns carried the tools.
  - GLM also writes its own template, `<tool_call>name<arg_key>k</arg_key>
    <arg_value>v</arg_value></tool_call>` (a string kept as written, other
    types read as JSON), and sometimes a whole call into a native call's
    name; both are read as the call. A name that holds the wrapper with
    GLM's tags where its service stopped mid-call — `{"name":"bash",
    "arguments":{"command</arg_key><arg_value>ls</arg_value>` — is read too:
    the tags are the service's own handoff, so what stands between them is
    the model's text (a quote left unescaped read as the quote it is, a
    comma inside a value kept, a field's closing tag ending the value before
    it), and the fields the native call did carry are kept beside the ones
    the name's own text fills in. A name whose tool the request doesn't
    have, or one no field can be read from, goes on as written, as any other
    unknown tool does.
  - A block is read as models get it wrong too: every quote escaped
    (`{\"name\":…}`), quotes or backslashes in a string left unescaped, an
    opener with the name as an attribute (`<tool_call name="bash">` with
    `<parameter name="k">v</parameter>`), or JSON that is whole when the
    stream ends without `</tool_call>`. A block that still can't be read,
    or is cut short, is never sent on as the answer: the reply ends with an
    error (a 502 without a stream), so the gateway can try again
    (plugins#38). A `<tool_call>` in backticks or a code fence is text.
  - Kimi and MiMo sometimes write a call in the tags they were trained on:
    Qwen's `<function=name><parameter=k>v</parameter></function>` (bare or
    inside `<tool_call>`), or Anthropic's `<function_calls>` around one or
    more `<invoke name="…"><parameter name="k">v</parameter></invoke>`.
    Each is read as a call, a parameter's value as JSON unless the tool's
    schema says string, and one cut short is an error as above. These
    tags are read only for a tool the request declared; for any other, or
    in backticks or a code fence, they stay text.
  - Calls from either source become OpenAI `tool_calls`. A name matching a
    requested tool but for case or punctuation (`Read`) goes on as the
    request's (`read`); any other goes on as written, so the agent can say
    the tool doesn't exist.
  - Trae requires the message answering a call to follow the call: the
    results of parallel calls go out as consecutive `tool` messages, with
    nothing between them, or the later ones lose their answer (11148).
  - Images: Trae's lists mark each model `multimodal` true or false (the
    Doubao-Seed models, Kimi K3 and K2.6, Qwen 3.7 Plus and MiniMax M3 take
    images; GLM-5 and DeepSeek V4 don't). A model marked true is listed
    as one that takes images, and an image sent to it goes in the
    message's content as an OpenAI `image_url` part beside the text, as
    TRAE's own agent sends one (plugins#161). A model marked false gets
    "[an image, which this model can't see]" in its place. A model whose
    list hasn't been read is sent its images, unless the fallback list
    says it takes none.
    A tool result's images go in a `user` message after the whole run of
    results, not in the `tool` turn: measured on the live endpoint, an
    `image_url` part in a `tool` turn reaches Kimi K2.6 but not
    Doubao-Seed (it answered "Blue"/"Black" to a red image), while the
    user-turn placement is read by both. The results of one turn stay
    consecutive — nothing may go between them (11148) — so the images
    wait for the last of them.

The model list is the account's own, from
`/api/ide/v1/batch_get_detail_param`, every function's list in one ask, as
TRAE SOLO CN asks it (`/api/ide/v1/get_detail_param`, one function at a
time, when the batch gives none). The lists are put together: SOLO and the
TRAE agent list models `chat_v3` doesn't (deepseek-v4.1-flash is the TRAE
agent's, `solo_agent`), and SOLO's coder roster lists models no other chat
function does (`glm-5v-turbo`, `kimi-k2.5`, `minimax-m2.7`,
`qwen-3.6-plus`, each answering through `solo_coder`). Left out are the
IDE's helpers (`usage` other than
`chat_completion`: summary, fast_apply…), configs switched off and the
custom-model slots. An enterprise's own built-in models
(`config_source` 2, "Enterprise-builtin" in Trae CN's picker) are listed
since 0.2.41 (#1258), unless the admin switched one off (`status` false); a
personal custom model (`config_source` 3) is not, its key being in the
user's IDE only. A chat with an enterprise model carries `config_source`
2, `is_custom_model` true, and the `model_name` and `provider` of its
`model_detail_list` entry (its `__dev` one, else the first) at the top of the
body, as Trae CN 3.4.20's own `llm_utils_chat` request does (0.2.43; 0.2.41
put them under `user_message_context.model_info`, and an enterprise seat got
4001 "the param is invalid" on every function; 0.2.42 read `provider` off the
config, where Trae's list doesn't carry it, sent no `model_name`, and got
4023 "something went wrong") — **not verified with a real enterprise seat**. A refused chat's error names
the model, the functions tried and the host, and says when the account's
list doesn't have the model. Context is the list's
`context_window_tokens.max` for a model measured to serve a prompt past its
`dev` budget on the base entry (yetone/magpie#5809 and the measurements in
its follow-up, all on Trae CN; the models are listed in `WIDENED`, and
Trae Global's keep `dev`), else `dev`; `dev` is
the budget Trae's own agent asks with, and on a model with that evidence a
request past it is served rather than refused. Output the `__dev` model's
`max_tokens` (an enterprise model's own detail's, since 0.2.44). That `max_tokens` is sent with every chat, the agent's limit
held to it and it sent when the agent names none, as Trae's own client
sends the model's `max_tokens` with each model: asked with none, an
enterprise seat's replies stopped at exactly 2000 output tokens (0.2.43).
They still did on 0.2.44 with `max_tokens` 4096 asked, so since 0.2.45 an
enterprise model's limit also goes in `enterprise_custom_hyper_params`
(`max_tokens`, the detail's `prompt_max_tokens`, `multimodal`), where Trae
CN 3.4.22's own agent task puts it — read from the binary, **not verified
with a real enterprise seat**. A reply Trae ends with "stop" (or no reason)
after using every token it was let have — the `max_tokens` sent, or 2000
for an enterprise model — ends with `finish_reason: "length"`, so an agent
knows it was cut. Trae's `completion_tokens` count the reasoning, which
`max_tokens` doesn't bound, so since 0.2.54 a reply is taken as cut at
`max_tokens` only when the count is that limit exactly or what it said past
its reasoning reached it (plugins#1503: GLM-5.3's whole "OK" to
`max_tokens` 16, 55 tokens of them 52 reasoning, went out as `length`). Since 0.2.48 a tool call such a reply was cut in (its
arguments not whole JSON) is not sent as a call: the reply ends with
`length` and the text before the call (plugins#1366, a call cut at 2000
went out as `tool_calls` and the agent stopped on it). A whole call in a
cut reply goes out as a call; a stream holds back only a call whose
arguments aren't whole until it ends. Trae CN 3.4.22's own llm_utils_chat
requests carry no field that lifts the 2000, so since 0.2.49 an
enterprise model's reply that Trae cut at exactly 2000 with text written
and no whole call is asked on: the same request, session and function
again, the text so far as the assistant's turn and a short ask to go on
where it stopped after it, with what is left of the agent's limit as
`max_tokens`. The answers go out as one reply, in a body or a stream, its
usage summed, its end the last answer's. A cut call is left out and the
next answer writes it. Asking stops at a whole call, at the agent's limit,
after 16 answers, or when a next ask fails (the reply then ends cut, with
`length`). A cut reply with only reasoning, or a call with nothing written
before it, is not asked on. Since 0.2.50 a later answer that Trae cut in
the model's reasoning or in a call, with no text of its own, is asked on
too, from the text the earlier answers wrote (a reasoning model asked to go
on reasons again first, and its round 2 was 7683 characters of reasoning
cut at 2000), up to 3 such answers in a row. While a next ask waits, the
stream is sent an SSE comment (`: keepalive`) after 2 seconds with nothing
sent, so the agent doesn't take the pause for a dead stream; with
`MAGPIE_TRAE_DEBUG=1` each next ask's line says its `round=` and
`wait_ms=`. **Not verified with a real enterprise seat**,
nor how cleanly a model goes on from where it stopped.

Since 0.2.53 an enterprise custom model whose detail carries a usable
`custom_config` (provider `custom_openai_compatible`, `status` true,
`auth_type` 0, an `ak`, and a `base_url` ending in `/chat/completions`) is
not asked through `llm_utils_chat` at all: its chat goes straight to that
`base_url`, as Trae CN 3.4.22's own client sends it (plugins#1366, the
reporter's captures: 8274 and 12182 output tokens with `stop` on the
same model that `llm_utils_chat` cuts at 2000). The request carries
`Authorization: Bearer <ak>`, `X-Model-Provider`, `User-Agent: hertz`,
the detail's `model_name` as `model`, the agent's `max_tokens` held to the
detail's (the detail's when none is asked), the messages and tools as the
agent sent them, and is always a stream with its usage; tool calls come
back in OpenAI form. If the endpoint isn't reached, answers an error
status, isn't a stream or a completion, or fails before writing anything,
the request goes through `llm_utils_chat` as before; a 401 or 403 there
keeps that model on `llm_utils_chat` until its list gives another `ak`.
Any other `auth_type`, or a field missing, is `llm_utils_chat` too.
**Not tried on a real enterprise seat.** A model with a `__max` model and
a bigger `context_window_tokens.max` is listed again as its Max,
`<id>-max` ("… (Max)"), with that window and the `__max` model's
`max_tokens`; the two can come from different functions' lists (chat_v3
can name the `__max` model, a SOLO list the windows). It asks the
`__max` model through the function that names it, with `max_tokens` set
and `user_message_context.model_info.prompt_max_tokens` the window less
it, as Max mode does. The lists needn't agree on a model's *name*: chat_v3
calls deepseek-v4.1-flash "DeepSeek-V4-Flash 正式版", as it once called
DeepSeek-V4-Flash-Official, where the SOLO lists call it
"DeepSeek-V4.1-Flash" (yetone/magpie#681). Trae's usage page books a
request under the name of the list it was served through, so the plugin
takes the name most of a model's lists give — the one Trae's own client is
served under — and asks that model, and its Max, through a list carrying
it. Trae renamed its official entries on 2026-10-09, leaving the name its
lists mostly agree on the only thing that tells a misnamed entry apart.

Reasoning: the models reason, and each entry of the account's list says
which levels it takes — its `reasoning_effort_config`, with the options
(`light`, `high`, `extra_high`) and the default. The request takes the same
names as `reasoning_effort`, so a level an agent picks is sent as Trae
spells it: the plugin offers each model's own levels as `variants`
(`low`/`high`/`xhigh` for `light`/`high`/`extra_high`; `medium` and `max`
keep their names where the entry names them). A model whose top level is
`extra_high` and that names no `max` — TRAE CN's DeepSeek-V4.1-Flash,
GLM-5.3 and Kimi-K3, 轻/高/极高 in Trae's app — is offered `max` too, sent
as `extra_high` (as `xhigh` is): 极高 is that model's max, so in a magpie
routing group it ranges up to max beside members that have one, and a
group set to max sends it `extra_high`. An entry naming Trae's own `max`
keeps it, with `extra_high` as `xhigh`. The plugin sends nothing
for a level the model doesn't name, or for a model whose entry names none —
Trae then serves it at its own default. An entry naming levels this map
can't spell offers none, rather than being sent one Trae would reject. A
request that wants levels for a model the list hasn't named reads the list,
and that read is remembered for five minutes whether it produced an entry or
not: a list that fails, or one that doesn't name the model, costs one read
rather than one per request. (A read costs up to two 20s timeouts when Trae's
list endpoint is slow, while the chat itself needs no list to answer.) A read
in flight is shared, not skipped: requests that arrive together — a title
request beside a session's first turn, subagents — ride the one read and all
see what it named, so a Max asked that way is still sent under its base
model's name rather than the agent's own `-max` id. The host's own catalog
refresh rides the same read, so a refresh and a request never ask twice.
A request's read swallows an expiry (the chat can still answer); the
catalog's refresh raises it, so a lapsed account is still marked — including
when the refresh merely rides a read a request started, which is why the lapse
travels on the read's record instead of being thrown from it. The host's
refresh is strict, so it reads again rather than serving a cached lapse: a
re-sign-in is asked afresh instead of being told again that the account lapsed.

The entry kept for a model is the one the request is asked through, and so
the one whose levels the request is held to, so the lists' disagreement
about a model's levels matters: `computer_use_subagent`, for one, is named
with `light`/`high` by `solo_agent` and `solo_agent_lite` and with none by
`solo_work_lite`. The three signals that pick the entry — its `__dev`
model, its not carrying another model's name, its carrying the name the
lists agree on — decide first; of entries that tie on all three, one that
names levels is kept, so a model Trae serves with levels is not left
without them by a sibling entry that names none.

Every model it lists also says it reasons in its `capabilities`
(`reasoning: true`, with `toolcall`, `temperature`, `attachment` and the
input and output modalities), the fallback list's own capabilities kept
where it has an entry: magpie reads `capabilities.reasoning` alone for a
model a plugin lists, and a model without it is shown as one that doesn't
reason (0.2.4).

When no
list can be read, the plugin uses the realm's own fallback list. Trae CN's
`chat_v3` is known to serve GLM-5.2, GLM-5, Kimi K2.6, Qwen 3.7 Plus,
DeepSeek V4 Pro and DeepSeek V4 Flash; Trae Global's serves GPT-5.4,
Gemini 3 Flash, Kimi K2.5, MiniMax M2 and DeepSeek V3.2. The live list
replaces either.

## Renewal

Trae CN (since 0.2.3) renews the JWT as its clients do, bound to the
account's device:

- **Where:** `POST api.trae.cn/trae/api/v3/oauth/ExchangeToken`, with the
  refresh token, the device (`DeviceInfo`: its id, machine id and public
  key) and a `DeviceProof`.
- **The device key:** an ECDSA P-256 key pair made for each account at
  sign-in (or at the first renewal of one signed in before 0.2.3), kept
  with the sign-in.
- **The proof:** the key's ECDSA-SHA256 signature (base64) of
  `POST\n/trae/api/v3/oauth/ExchangeToken\n{ClientID}\n{RefreshToken}\n{Timestamp}\n{Nonce}`.
- **As whom:** TRAE SOLO CN (`en1oxy7wnw8j9n`, `SOLO_PC`) first, then
  Trae CN's IDE (`ono9krqynydwx5`, `IDE_PC`).
- **The refresh token:** kept; this renewal doesn't spend it.

A token the sign-in page gives is renewed this way at once. When Trae
turns the device-bound renewal away, the plugin renews as before 0.2.3.

Trae Global, and Trae CN as a fallback, renew at the realm's auth host's
`/cloudide/api/v3/trae/oauth/ExchangeToken` (`api.trae.cn`,
`growsg-normal.trae.ai`). There Trae issues a new refresh token each time
and spends the old one, so only one renewal runs at a time.

magpie renews the JWT ten minutes before it ends (`refreshLead`) through
`auth.refresh`. Each request also checks it, two minutes before the end, for
OpenCode.

The account is marked for a new sign-in in these cases:

- the refresh token is turned away;
- a request is answered 401, or with a code that means the sign-in lapsed:
  1001 for both realms, and 20101 for Trae Global.

Trae signs other clients out of an account when its token is renewed. The
IDE may therefore ask you to sign in again after magpie renews.

## Errors

| Trae's answer | What the agent gets |
| --- | --- |
| 401 / code 1001 (both), 20101 (Global) | 401, and the account is marked for a new sign-in |
| code 4008 / 1005 (quota, plan; both), 4011 (Global) | 429 |
| code 1005 naming a plan (`extra` `{"plan":2}`), from any function | 403 "the model is not available to this account's plan", naming the plan, the model and the functions tried |
| Anything else | Trae's message and code, as a 502 or Trae's own status |

### Seeing what is sent

Start magpie with `MAGPIE_TRAE_DEBUG=1` in its environment and each chat
request writes two or three lines to magpie's log (`app.log`, and the
terminal or `docker logs` when magpie runs as `magpie serve`):

- `trae debug: request <id> POST <url> <body>`: the body the plugin sends
  Trae's `llm_utils_chat`, `max_tokens` and `enterprise_custom_hyper_params`
  included. Each message is only its role and length, each tool only its
  name; the headers, which carry the sign-in, are never written.
- `trae debug: request <id> answered <status> <content-type>`.
- `trae debug: reply <id> trae_finish=… usage=… calls=… finish_sent=…`: the
  finish Trae gave (`""` is Trae's "stop" or none), its usage, the calls
  Trae gave, `cut_calls=N` when N of them were cut and not sent, and the
  finish the agent was sent.

An enterprise model asked at its own endpoint (0.2.53) writes
`trae debug: request <id> POST <base_url> direct ak_chars=<n> <body>`: the
`ak`'s length only, never the `ak`. Any other request goes to Trae, whose
cloud asks the enterprise model's gateway, so that body is not in magpie's
log.

## Usage

magpie's usage card shows the account's plan and allowance, from whichever
page the realm bills on:

**Trae CN** — the credits page:

- **Source:** `api.trae.cn/trae/api/v2/pay/ide_user_ent_usage`.
- **What it adds up:** each entitlement pack's `credits_limit` (-1 means
  unlimited) and what the pack has used.
- **What it shows:** one Credits window: the credits used of the packs'
  total, with the share, which magpie shows as used or left like
  WorkBuddy's.

**Trae CN, an enterprise (SaaS) account** — Trae's enterprise console, which
bills in yuan rather than in the credits the consumer page counts. The
console's callback names its host bare (`console.enterprise.trae.cn`);
since 0.2.54 that is read as https, and an enterprise sign-in that names no
usable host keeps its console. A seat kept with no host before then (its
token's scope is `saas`, at its top or, since 0.2.55, under `data`) is read
as its console's with no new sign-in (plugins#1516):

- **Source:** `console.enterprise.trae.cn/trae/gtm/tob/api/v1/config/get_personal_quota`
  for the allowance and `…/get_user_model_usage` for the spend, both POST
  with an empty body; `…/get_personal_core_data` for the period's
  `ResetTime`; and the consumer credits page above for the second row.
- **What it adds up:** the seat pool in yuan (`seat_pool_currency_quota`;
  the console's pay-as-you-go sentinel is no limit), and the models' own
  `total_cost_currency` summed — the console gives no total of its own. The
  console answers an empty body with the current period's spend, which is
  what the pool resets on; a real account's sum matches its usage page. Only
  the account's own seat is counted: an administrator's answer carries every
  seat in the tenant.
- **What it shows:** a Seat Usage window, `¥used / ¥total` and the share,
  resetting when the console says the period does, then a Credits window of
  the consumer page's allowance, marked `aside`. A spend page that fails
  leaves the row saying `? / ¥total` rather than reading as nothing spent.
- **Which accounts:** the sign-in named `console.enterprise.trae.cn` as the
  account's host. A personal account, and any account whose usage pages
  answer nothing, is read as before.
- **Why both:** the consumer page answers an enterprise account too, with a
  credits allowance that real calls have been measured not to touch — two
  calls through magpie moved the console's spend by ￥0.0002 each and left
  the credits at 4.4 of 4700. The seat pool is what a request spends, so
  the credits row is `aside`: magpie shows it without routing on it. Whether
  the credits are a fallback the seat pool exhausts first is not known — no
  account has spent its pool to find out. A failure on the credits page or
  on the period leaves the seat pool standing.

**Trae Global** — the dollar billing's entitlements:

- **Source:** `POST api-sg-central.trae.ai/trae/api/v1/pay/user_current_entitlement_list`
  (a US account asks `api-us-east.trae.ai`).
- **What it adds up:** the pack's allowance in dollars
  (`basic_usage_limit` plus `bonus_usage_limit`) and what was used of each
  (`basic_usage_amount`, `bonus_usage_amount`).
- **What it shows:** one Dollar Usage window, the dollars used of the
  allowance, resetting when the pack ends.

**Trae Global, an enterprise (SaaS) account** — the international
deployment's own enterprise console, which bills in dollars:

- **Source:** `console.enterprise.trae.ai/trae/gtm/tob/api/v1/config/get_personal_quota`
  for the allowance, `…/get_user_model_usage` for the spend and
  `…/get_personal_core_data` for the period, all POST with an empty body —
  the three pages Trae CN's console has.
- **What it adds up:** the seat pool (`seat_pool_currency_quota`; the
  console's pay-as-you-go sentinel is no limit) and the models' own
  `total_cost_currency` summed.
- **What it shows:** one Seat Usage window, `$used / $total` and the share,
  resetting when the console says the period does. The international realm
  has no consumer credits page, so there is no second row.
- **Which accounts:** the sign-in named `console.enterprise.trae.ai` as the
  account's host. Any other account is read as before.

**Not verified.** No international enterprise account was available to try
this against, and `console.enterprise.trae.ai` answers another realm's token
with 请先登录 — exactly as it answers no token at all, so whether it refuses
the token or wants a console session of its own is not known either. What
the paths and fields are was read off the international console's own build,
which names `seat_pool_currency_quota`, the models' `total_cost_currency`
and `ResetTime` as Trae CN's console does; whether such an account's console
answers at all is not known. The Trae CN path above is the one that has been
run against a real account.

Because that is not known, this console is not allowed to mark the sign-in:
its 401 is reported as the read's error and the account stays signed in,
where Trae CN's console — measured to take the IDE's own token — does mark
it. A console that wants a session of its own would otherwise mark every
international enterprise account expired, and signing in again would not
clear it.

A 200 carrying an error code is shown as Trae's own message rather than as
an empty answer.

## Daily check-in

Trae CN gives credits for a daily check-in (每日签到); Trae Global has no
such page, so this is CN only. magpie can press it
once a day for each account (Settings, or the switch on the usage card),
through `auth.checkin`: `claimed` when the status says today's is in after
the claim, `done` when it said so before it, `inactive` when the page is
disabled, `ineligible` when the claim answers 9095 (this device has
checked in today) or 9074 (Trae did not take it for this account's
device) or answers code 0 while the read-back still says the day is out,
and `failed` for a turned-away sign-in or any answer that got nowhere,
which is tried again later that day. An `ineligible` is the day's answer:
magpie asks that account no more until tomorrow, and only reads its
status.
It asks Trae CN's own pages through
this plugin's fetch, which sends them as the account, as Trae CN's IDE
(3.3.104) sends them: its Cloud-IDE-JWT (renewed first when near its
end), its device (`x-device-id`, `x-device-brand`, `x-device-type`,
`x-os-version`, `x-app-version`) and a client's User-Agent (TRAE SOLO
CN's Electron shell). Since 0.2.1: Bun's own User-Agent and the chat's
headers got 9074 「当前参与用户太多，请稍后再试」 every time
(yetone/magpie#808). Since 0.2.3 the JWT is also bound to the device (see
Renewal): a JWT renewed at `/cloudide/…` carries no device, and the claim
answered it 9074 even with the client's headers.

- **Status:** `POST api.trae.cn/trae/api/v2/ug/checkin_credits/status`,
  body `{"req_source":1}` (magpie's `{}` is sent as that): `enable`,
  `checked_in`, `credits`.
- **Claim:** `POST api.trae.cn/trae/api/v2/ug/checkin_credits/claim`,
  the same, only while it is on and today's isn't in.
- **The device, when Trae CN's own client is here (0.2.14):** the
  account this machine's Trae CN desktop client is signed in as checks in
  on the client's own device, the one Trae's device service registered:
  `x-device-id` is the id in the client's
  `globalStorage/storage.json` key `iCubeAuthInfo://icube-dc:<id>`,
  `x-device-type` and `x-os-version` are this machine's, and no
  `x-device-brand` is sent. The account is matched by the `userId` in the
  client's sign-in (`iCubeAuthInfo://icube.cloudide`, plain JSON or the
  client's fixed codec, as dingminhua/dsh-connect-trae reads it). The file
  is only read: nothing in it is written, and the client's token is never
  used. On one account the client's claim went through while the
  plugin's, on its own device, got 9074 (yetone/magpie#808, #1920); that
  this header is what changes it hasn't been tried on a real account
  yet. Every other account keeps its own device, and a file that can't be
  read or made out, or holds no single device, changes nothing.
- **Every profile is read (0.2.21):** a machine can hold more than one
  Trae CN client profile — the IDE's and TRAE SOLO CN's each write their
  own `storage.json`, and each names the account that profile is signed in
  as, with that account's device. So every profile is read and the one
  signed in as the account answers with its device, which is how two
  accounts can each check in on a real client's device. Before, only the
  first profile was read and it decided for all of them: a second
  account's own profile was never seen, and one profile signed in as
  someone else (or one file that didn't parse) hid every profile after it.
  A profile that isn't signed in as the account, or that names no single
  device, is passed over rather than ending the search. Files: macOS
  `~/Library/Application Support/Trae CN/…` and `…/TRAE SOLO CN/…`, Windows
  `%APPDATA%\Trae CN\…`, `…\TRAE SOLO CN\…` (or `trae-cn`), Linux
  `~/.config/trae-cn/…`, `…/Trae CN/…`, `…/TRAE SOLO CN/…`. The IDE's
  folder has been seen in a real install (macOS and Windows); TRAE SOLO
  CN's name and its `iCubeAuthInfo://` keys are read as the same client
  of the same realm writes them, which hasn't been checked against real
  files — harmless if they differ, since a folder that isn't there, or a
  key that isn't named, is simply not read. A client started with its own
  `--user-data-dir` is not found: there is no list of those to read.
- **Every other account's device (0.2.16, 15 digits since 0.2.30):** its
  own device id, in the shape Trae CN takes. Trae CN answered a claim on the
  plugin's 19-digit id 9074, while the same account and token on a
  16-digit id were taken (magpie-community/plugins#194). On 2026-11-05 it
  answered 16 digits 9074 too (plugins#709): with the plugin's own
  headers and body, the same token and account, seconds apart, the
  account's own 16-digit id got 9074 and a 15-digit one, even a random
  one nothing had registered, was taken — on three accounts, from two
  machines on two ISPs, and with wild-work's headers alike. So since
  0.2.30 every account checks in on a 15-digit id made from its own device
  id and uid (one already 15 digits goes as it is): the same id every day,
  never rotated, never starting with 0, and no other account's. Its chat
  requests and renewals keep the device it signed in with (16 digits, or
  19 before 0.2.16): nothing measured asks for another there, and the
  device is bound into the renewed sign-in.
- **What comes back:** Trae's answer as it is. A 401 or code 1001 marks
  the account for a new sign-in. Code 9095 means this device has checked
  in today, and that holds for the day. Code 9074 means Trae did not take
  the claim for this account's device: its own words say the pool is busy,
  which two measurements do not bear out — the same account, token and
  headers were taken on a 16-digit id where a 19-digit one got 9074
  (plugins#194), and on 2026-10-23 the same account and headers were taken
  on a device id Trae had never seen while this account's own id answered
  9074. The message says so, and does not send people to Trae CN's app,
  which is not where the problem is. Signing the account in to a Trae CN
  client on this machine is the one thing seen to change a 9074, but it
  hasn't been tried on a real account, so it isn't named in the message;
  nor is it named when the claim already rode a client's device, where it
  would only tell the user to do what they did. The account's own device
  is never rotated: a 9095 is the day's answer, and a 9074 gets the one
  claim more below, on the one id made from the uid, and nothing after
  it. No account is given another account's device or its own client's
  device unless a client is signed in as that account.
- **A 9074 with no client here is claimed once more (0.2.29):** an
  account no Trae CN client on this machine is signed in as gets one more
  claim, at once, after a 9074, in the request that tools checking Trae
  CN accounts in with no client send: luckymiaow/trae-mate's (MIT), as
  iJetLi/dsh-providers-hub sends it too. Body `{}`, `x-user-region: CN`,
  User-Agent `VSCode 1.107.1 (TRAE SOLO CN)`, its market, LSCBD and
  session headers, and a 15-digit device id made from the uid alone
  (trae-mate's `device_map.rs`), with none of the IDE's device headers.
  On plugins#722 the account this plugin's claim got 9074 on checks in
  daily through providers-hub, and on plugins#709 wild-work, which also
  sends body `{}`, `x-user-region: CN` and a 15-digit id, had every claim
  taken first time, so its 8-second retry never ran: waiting is not what
  changes a 9074. plugins#709's bisect then found the id's length to be
  what decides (16 refused, 15 taken, headers and body changing nothing),
  and since 0.2.30 the first claim goes on 15 digits (above). This request
  is kept as the fallback, since it wasn't measured with a 16-digit id, and
  goes only once: a second 9074 is the day's answer,
  no other code is claimed again, and an account whose own client's
  device the claim rode is not. Not yet tried on a real Trae CN account.
- **Which device, said (0.2.25):** a 9074 or 9095 message ends with
  the device the claim went on: this machine's Trae CN client's, signed in
  as the account, or magpie's own for it, with how many client profiles
  were found and that none is signed in as the account. A client device
  that another profile, signed in as another account, also has is said
  too: both accounts check in on one device, which Trae takes once a day.
  No uid or device id is named. On plugins#436 two accounts shared one
  machine whose two profiles (`Trae CN`, `TRAE SOLO CN`) were both the
  first account's; it checked in and the second got 9074, which took
  running `clientDevice` by hand to explain. A profile started with its
  own `--user-data-dir` is not read, and there is no reason to: on
  2026-10-29 TRAE CN 3.4.4 (Windows 11) kept a second account's sign-in
  apart in such a folder but gave it the same device id as the default
  folder, and the client itself said 「本设备今日已签到」 for that
  account. The check-in is counted per device, so on one machine only the
  first account to check in gets the day's credits; the others' usage,
  models and requests are unaffected (plugins#436, closed as not
  planned).
- **A claim's code 0 is not the answer (0.2.22):** Trae answers a
  claim code 0 for one that registered nothing, so the status is read back
  after every claim and only a day that is in is reported as `claimed`.
  Since 0.2.22 one that isn't is an `ineligible` — the day's answer, not a
  `failed` to be tried again: a `failed` is retried with backoff for the
  rest of the day and each retry is another claim, which for an account
  Trae keeps answering code 0 would turn one claim a day into many, and a
  status that lags a claim that did land would read as not in once and
  claim again. Nothing is claimed again that day; the status alone is
  read, so a lag that catches up is still reported as `done`. The credit a
  claim granted is its `credits`, or its `extra_credits` when it names
  only that; Trae CN's claim usually names neither
  (`{"code":0,"message":"success"}`), and then the read-back's `credits`
  is the credit. The two are never added: the status carries
  `extra_credits` beside `credits` (100 and 100 on a real account) while
  the day gives 100.

Only `api.trae.cn`'s `/trae/api/` pages are sent this way; any other URL
that isn't a chat request is still refused (400). Needs 0.1.4 or later.
