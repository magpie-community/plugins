// Trae CN (trae.cn), ByteDance's AI IDE, as the IDE signs in to it and
// asks its models: trae.cn's authorization page sends the browser back to
// a callback on 127.0.0.1 with the account's Cloud-IDE-JWT and refresh
// token; the refresh token is exchanged for a new JWT at
// /cloudide/api/v3/trae/oauth/ExchangeToken; model requests go to the IDE
// agent's /api/agent/v3/llm_utils_chat, which answers in its own SSE
// events. Worked out from two open-source relays (wangqi233/trae2api and
// autumnsentiment/Trae2api-cn); not run against a real account here.
// The account's fetch also sends Trae CN's own pages on api.trae.cn
// (/trae/api/…) as the account, for magpie's daily check-in (每日签到:
// /trae/api/v2/ug/checkin_credits/status, then /claim).
import { createDecipheriv, createHash, generateKeyPairSync, randomBytes, randomUUID, randomInt, sign } from "node:crypto"
import { linkSync, mkdirSync, readFileSync, unlinkSync, writeFileSync } from "node:fs"
import { readFile } from "node:fs/promises"
import { createServer, STATUS_CODES } from "node:http"
import { homedir, release, version as osVersion } from "node:os"
import { dirname, join } from "node:path"

// SEES is a fallback model that takes images, as Trae's lists mark it
// (multimodal: true)
const SEES = { attachment: true, modalities: { input: ["text", "image"], output: ["text"] } }

const SITES = {
  // Trae CN (trae.cn): the authorization page sends the browser back to a
  // callback on 127.0.0.1 with the account's Cloud-IDE-JWT and refresh
  // token; the refresh token is exchanged for a new JWT at
  // /cloudide/api/v3/trae/oauth/ExchangeToken; model requests go to the IDE
  // agent's /api/agent/v3/llm_utils_chat, which answers in its own SSE
  // events. Worked out from two open-source relays (wangqi233/trae2api and
  // autumnsentiment/Trae2api-cn); not run against a real account here.
  // The account's fetch also sends Trae CN's own pages on api.trae.cn
  // (/trae/api/…) as the account, for magpie's daily check-in (每日签到:
  // /trae/api/v2/ug/checkin_credits/status, then /claim).
  "trae-cn": {
    id: "trae-cn",
    name: "Trae CN",
    realm: "Trae CN", // the name the errors and messages carry
    webHost: "trae.cn", // the bare host the sign-in copy names
    // where each part of Trae CN is served; tests point them at a fake
    hosts: {
      web: "https://www.trae.cn", // the authorization page
      auth: "https://api.trae.cn", // tokens, the account, credits
      api: "https://trae-api-cn.mchost.guru", // the models
      console: "https://console.enterprise.trae.cn", // an enterprise (SaaS) account's usage, in yuan
      // the commercial usage endpoint: the settled charge and the real cache
      // counters of a turn, which token_usage often reports as 0
      billing: "https://api5-normal.mchost.guru",
    },
    // the console an enterprise (SaaS) sign-in names as its account's host,
    // which is what tells an enterprise account apart: it bills there, not
    // on the consumer credits page. Kept apart from hosts.console so a test
    // can point the requests at a fake and still sign in as an enterprise
    // account.
    consoleHost: "console.enterprise.trae.cn",
    // Trae CN's console was measured to take the IDE's own token: the plugin's
    // own headers against get_personal_quota answer 200, and a 401 from it
    // really is a lapsed sign-in. The international console could not be
    // measured (see its realm below), so it is not allowed to say so.
    consoleTakesIdeToken: true,
    clientId: "ono9krqynydwx5", // Trae CN's IDE
    // the clients' own renewal, which binds the JWT to a device: ExchangeToken
    // under /trae/api/v3/oauth, signed with the device's P-256 key
    // (DeviceProof). A JWT renewed at /cloudide/… carries no device, and
    // Trae CN answers its check-in claim 9074 「当前参与用户太多」 every time,
    // while the client's own token is let through (mintonight's side-by-side
    // on yetone/magpie#808). Tried as TRAE SOLO CN first, the one
    // qilimixingkong/trae-checkin found the server takes, then as Trae CN's
    // IDE. It doesn't spend the refresh token.
    deviceExchange: {
      path: "/trae/api/v3/oauth/ExchangeToken",
      as: [
        { clientId: "en1oxy7wnw8j9n", platform: "SOLO_PC", version: "0.1.64" },
        { clientId: "ono9krqynydwx5", platform: "IDE_PC", version: "3.3.99" },
      ],
    },
    appId: "6eefa01c-1036-4c7e-9ca5-d891f63bfcd8",
    ideVersion: "3.3.65", // named to the authorization page
    ideVersionCode: "20260401",
    // the client the model host is told it serves: TRAE SOLO CN 0.1.69, as
    // its ai-agent names itself (same app id). Trae offers a model only to
    // clients new enough for it, and an April IDE was offered no
    // deepseek-v4.1-flash.
    clientVersion: "0.1.69",
    clientVersionCode: "20260917",
    pluginVersion: "2.3.24254",
    brand: "ASUS TUF Gaming A15 FA507RM_FA507RM",
    // the IDE's chat functions: the classic IDE's agent, then SOLO's Work
    // mode, then the TRAE agent (solo_agent, which has deepseek-v4.1-flash),
    // then SOLO Lite's agent, then SOLO's coder roster, which lists models no
    // other chat function does (glm-5v-turbo, kimi-k2.5, minimax-m2.7,
    // qwen-3.6-plus — each answers through it)
    functions: ["chat_v3", "solo_work_lite", "solo_agent", "solo_agent_lite", "solo_coder"],
    // what Trae CN's chat_v3 is known to serve; the live list replaces it
    // (the MODEL defaults are spread in at the end of the module, once MODEL
    // is defined, so a site's entry only names what differs)
    models: {
      "glm-5.2": { name: "GLM-5.2", limit: { context: 200_000, output: 32_000 } },
      "glm-5": { name: "GLM-5" },
      "kimi-k2.6": { name: "Kimi K2.6", limit: { context: 256_000, output: 0 }, ...SEES },
      "qwen-3.7-plus": { name: "Qwen 3.7 Plus", ...SEES },
      "DeepSeek-V4-Pro": { name: "DeepSeek V4 Pro" },
      "DeepSeek-V4-Flash": { name: "DeepSeek V4 Flash" },
    },
    // the model host for an account: Trae CN's own hosts serve no models,
    // so only a host that is one is taken, else the one gateway.
    //
    // The enterprise console an enterprise (SaaS) sign-in names is the
    // seat's own model host, and a chat there bills the seat pool. Not every
    // tenant's seat takes chats there: #1127's (shadow1606) answered every
    // llm_utils_chat with 4245, for every function and model, while
    // #1155's (kenanor) chats there. A seat the console turns away is
    // marked (consoleChat: false, kept with the sign-in) and chats on the
    // consumer gateway, which takes the same login but bills the login's
    // own credits — so the gateway is the fallback, never the first ask.
    // The plugin's hostOf applies the mark; this is the host before it.
    apiOf: (a) => {
      const h = traeHost(a?.api)
      if (h && new URL(h).hostname.toLowerCase() === SITES["trae-cn"].consoleHost) return a?.consoleChat === false ? SITES["trae-cn"].hosts.api : SITES["trae-cn"].hosts.console
      return h && SITES["trae-cn"].modelHost(h) ? h : SITES["trae-cn"].hosts.api
    },
    // whether a host named by a sign-in is one of the model hosts: an https
    // host on mchost.guru or named trae-api-…, as the consumer gateway is,
    // or another trae.cn host than the consumer site's own (www, api,
    // grow…), which an enterprise (SaaS) sign-in may name for its tenant
    modelHost: (h) => {
      const t = traeHost(h)
      if (!t) return false
      const n = new URL(t).hostname
      return /(^|\.)mchost\.guru$|^trae-api-/i.test(n) || (/\.trae\.cn$/i.test(n) && !/^(www|api|grow[^.]*)\./i.test(n))
    },
    // ownPage: url is one of Trae CN's own JSON pages on api.trae.cn
    // (/trae/api/…: the daily check-in, credits), which the account's fetch
    // sends as the account rather than as a chat
    ownPage: (url) => {
      try {
        const u = new URL(url)
        return u.origin === new URL(SITES["trae-cn"].hosts.auth).origin && u.pathname.startsWith("/trae/api/")
      } catch {
        return false
      }
    },
    // Trae CN's account info carries no region: its one deployment is the
    // one it is asked through
    regionOf: () => "",
    checkin: {
      status: { path: "/trae/api/v2/ug/checkin_credits/status" },
      claim: { path: "/trae/api/v2/ug/checkin_credits/claim" },
    },
    // where usage is asked, and which page it is (CN: credits)
    usage: {
      kind: "credits",
      path: "/trae/api/v2/pay/ide_user_ent_usage",
      label: "credits",
      host: (site) => site.hosts.auth,
      body: { require_usage: true, req_source: 0 },
      // an enterprise (SaaS) account bills in yuan on Trae's console, not on
      // the consumer credits page: its allowance is the seat pool the
      // console names, and what it spent is the models' own cost — two of
      // the console's pages, not one. A personal account is read as before.
      //
      // The consumer page answers such an account too, with a credits
      // allowance that real calls have been measured not to touch (two calls
      // through magpie moved the console's spend by ￥0.0002 each and left
      // the credits at 4.4 of 4700). It is shown beside the seat pool so the
      // card holds both numbers, but marked aside: the seat pool is what a
      // request spends, so the credits must not read as allowance magpie can
      // route on. Whether they are a fallback the seat pool exhausts first
      // is not known — no account has spent its pool to find out.
      ent: {
        quota: { path: "/trae/gtm/tob/api/v1/config/get_personal_quota" },
        spent: { path: "/trae/gtm/tob/api/v1/config/get_user_model_usage" },
        // the console's own period, which is the seat pool's: the usage page
        // says "席位额度将于 <ResetTime> 重置" from exactly this call, while
        // get_personal_quota names the allowance and no date at all
        core: { path: "/trae/gtm/tob/api/v1/config/get_personal_core_data" },
        read: ({ quota, spent, core, credits: page }, a, signIn, { credits, round }) => {
          const q = seatPoolOf(quota)
          if (!q) return { error: "Trae CN usage: the console named no seat pool", signIn, user: a.name }
          const out = { plan: "Enterprise", user: a.name || a.uid, signIn }
          const windows = []
          if (q.unlimited) out.balance = "unlimited"
          else if (q.limit > 0) windows.push(seatUsageWindow(q, seatSpentOf(spent, quota?.user_model_quota?.user_id), entResetOf(core), yuan, "CNY"))
          const c = page ? credits(page) : null
          if (c && !c.unlimited && c.limit > 0) {
            const w = {
              name: "Credits",
              used: Math.max(0, Math.min(100, (c.used / c.limit) * 100)),
              display: `${round(c.used)} / ${round(c.limit)}`,
              amount: round(c.used),
              limit: round(c.limit),
              unit: "credits",
              aside: true,
            }
            if (c.until) w.resetsAt = new Date(c.until).toISOString()
            if (c.until && c.lapsing > 0) Object.assign(w, { runsOutAt: new Date(c.until).toISOString(), runsOut: round(c.lapsing) })
            windows.push(w)
          }
          if (windows.length) out.windows = windows
          // a pool of nothing and no credits row leave the card nothing to
          // show: it says what the console and the page answered rather
          // than standing empty (#1143)
          else if (!out.balance) return { error: `Trae CN usage: the console gives this seat a pool of ¥${q.limit}, and the credits page ${!page ? "could not be read" : c?.unlimited ? "says unlimited" : "shows no allowance"}`, signIn, user: a.name || a.uid }
          return out
        },
      },
      read: (v, a, signIn, { credits, round }) => {
        const c = credits(v)
        const out = { plan: v.is_credits_billing ? "Credits" : "Free", user: a.name || a.uid, signIn }
        if (c.unlimited) out.balance = "unlimited"
        else if (c.limit > 0) {
          // the count rides on the window (amount of limit, in credits), as
          // WorkBuddy's does, so magpie says it in the window's row, used or
          // left, in its own words and number format, rather than as an
          // English balance line beside it (yetone/magpie#694)
          const w = { name: "Credits", used: Math.max(0, Math.min(100, (c.used / c.limit) * 100)), amount: round(c.used), limit: round(c.limit), unit: "credits" }
          if (c.until) w.resetsAt = new Date(c.until).toISOString()
          if (c.until && c.lapsing > 0) Object.assign(w, { runsOutAt: new Date(c.until).toISOString(), runsOut: round(c.lapsing) })
          out.windows = [w]
        }
        return out
      },
    },
  },
  // Trae international (trae.ai): the same IDE sign-in flow against the
  // international deployment. Its own authorization page, its own auth and
  // chat hosts, a second (US) deployment the account's region selects, and
  // the dollar billing's entitlements rather than the CN credits page.
  // Worked out from the realm table of wangqi233/trae2api (cn/sg dual-region)
  // and the login URL of wefew/trae2api; run against one Free SG account.
  "trae-global": {
    id: "trae-global",
    name: "Trae Global",
    realm: "Trae Global",
    // its lists mark Auto-mode channels and pay-as-you-go twins
    // is_invisible_to_user, which its picker hides; Trae CN's lists are
    // served whole, as they were before Global joined this package
    hidesInvisible: true,
    webHost: "trae.ai",
    hosts: {
      web: "https://www.trae.ai", // the authorization page
      auth: "https://growsg-normal.trae.ai", // tokens, the account
      api: "https://coresg-normal.trae.ai", // the models, SG
      us: "https://coreva-normal.trae.ai", // the models, US
      pay: "https://api-sg-central.trae.ai", // usage
      usPay: "https://api-us-east.trae.ai", // usage, the US deployment
      console: "https://console.enterprise.trae.ai", // an enterprise (SaaS) account's usage, in dollars
      // No billing host: api5-normal.trae.ai does not resolve (NXDOMAIN on
      // this machine, 1.1.1.1 and 8.8.8.8), and no Global IDE's own host was
      // measured. A realm without one reads no settlement, rather than asking
      // a host that never answers (TRAE_USAGE_API_HOST still names one).
    },
    // the console an enterprise (SaaS) sign-in names as its account's host,
    // as on Trae CN: it bills there, not on the dollar billing's page. Kept
    // apart from hosts.console for the same reason as Trae CN's.
    consoleHost: "console.enterprise.trae.ai",
    // Not measured: no international enterprise account could be found, and
    // console.enterprise.trae.ai answers a foreign realm's token with 请先登录
    // exactly as it answers no token at all, so whether it refuses the token
    // or wants a console session is unknown. Until an account says otherwise,
    // its 401 is a failed read, never a lapsed sign-in.
    consoleTakesIdeToken: false,
    clientId: "ono9krqynydwx5",
    appId: "6eefa01c-1036-4c7e-9ca5-d891f63bfcd8",
    ideVersion: "3.5.51", // named to the international IDE's current build
    ideVersionCode: "20260401",
    clientVersion: "0.1.69",
    clientVersionCode: "20260917",
    pluginVersion: "2.3.62834",
    brand: "ASUS TUF Gaming A15 FA507RM_FA507RM",
    functions: ["chat_v3", "solo_work_lite", "solo_agent", "solo_agent_lite", "solo_coder"],
    // what Trae Global's chat is known to serve (its catalog barely overlaps
    // the CN one's); the live list replaces it
    models: {
      "gpt-5.4": { name: "GPT-5.4" },
      "gemini-3-flash": { name: "Gemini 3 Flash", limit: { context: 1_000_000, output: 0 } },
      "kimi-k2.5": { name: "Kimi K2.5", limit: { context: 256_000, output: 0 } },
      "minimax-m2": { name: "MiniMax M2" },
      "deepseek-v3.2": { name: "DeepSeek V3.2" },
    },
    // the model host: the account's region (or a US host the sign-in named)
    // selects the US deployment, else the SG one
    apiOf: (a) => {
      const h = traeHost(a?.api)
      const n = h ? new URL(h).hostname : ""
      const region = String(a?.region ?? "").toUpperCase()
      if (/coreva/i.test(n) || /api-us(?:[-.]|$)/i.test(n) || /^US(?:[-_ ]|$)/.test(region)) return SITES["trae-global"].hosts.us
      if (/coresg/i.test(n)) return h
      // another trae.ai host than the site's own (www, api-…, grow…): one an
      // enterprise (SaaS) sign-in named for its tenant
      if (/\.trae\.ai$/i.test(n) && !/^(www\.|api[-.]|grow)/i.test(n)) return h
      return SITES["trae-global"].hosts.api
    },
    // a sign-in names a host of Trae's, which can be an auth host
    // (api-us-east), not the chat host
    modelHost: (h) => {
      const t = traeHost(h)
      return !!t && /(^|\.)trae\.ai$/i.test(new URL(t).hostname)
    },
    // Trae Global serves no own JSON pages through the account's fetch
    ownPage: () => false,
    // the account's region, from the sign-in's user info
    regionOf: (s) => String(s?.region ?? s?.aiRegion ?? s?.Region ?? s?.AIRegion ?? "").trim(),
    // the international deployment also answers these
    lapsed: [1001, "1001", 20101, "20101", 401, "401"],
    quota: [4008, "4008", 1005, "1005", 4011, "4011"],
    // where usage is asked, and which page it is (Global: the dollar
    // billing's entitlements)
    usage: {
      kind: "dollar",
      path: "/trae/api/v1/pay/user_current_entitlement_list",
      label: "usage",
      // the US account pays on its own host, the rest on the central one —
      // the auth host's own /cloudide/api/v2/pay pages answer 403 Api Scope
      // Forbidden here
      host: (site, a) => (/^US(?:[-_ ]|$)/i.test(String(a?.region ?? "")) || /api-us/i.test(String(a?.api ?? "")) ? site.hosts.usPay : site.hosts.pay),
      body: {},
      // An enterprise (SaaS) account bills on Trae's enterprise console
      // here too, on the same three pages Trae CN's console has and in
      // dollars. The international deployment has no consumer credits page
      // (its own page is the dollar billing's), so the card is the seat
      // pool alone.
      //
      // NOT VERIFIED against a real account: no international enterprise
      // account was available, and console.enterprise.trae.ai answers
      // another realm's token with 请先登录 — as it answers no token at all,
      // so whether it refuses the token or wants a console session is not
      // known either. The paths and fields below are the CN console's shape
      // read off the international console's own build, which names
      // seat_pool_currency_quota, the models' total_cost_currency and
      // ResetTime exactly as Trae CN's does. Whether such an account's
      // console answers at all is not known.
      ent: {
        quota: { path: "/trae/gtm/tob/api/v1/config/get_personal_quota" },
        spent: { path: "/trae/gtm/tob/api/v1/config/get_user_model_usage" },
        core: { path: "/trae/gtm/tob/api/v1/config/get_personal_core_data" },
        read: ({ quota, spent, core }, a, signIn) => {
          const q = seatPoolOf(quota)
          if (!q) return { error: "Trae Global usage: the console named no seat pool", signIn, user: a.name }
          const out = { plan: "Enterprise", user: a.name || a.uid, signIn }
          if (q.unlimited) out.balance = "unlimited"
          else if (q.limit > 0) out.windows = [seatUsageWindow(q, seatSpentOf(spent, quota?.user_model_quota?.user_id), entResetOf(core), DOLLARS, "usd")]
          // a pool of nothing leaves the card nothing to show (#1143)
          else return { error: `Trae Global usage: the console gives this seat a pool of $${q.limit}`, signIn, user: a.name || a.uid }
          return out
        },
      },
      read: (v, a, signIn, { round }) => {
        const d = dollarUsageOf(v)
        if (!d) return { error: "Trae Global usage: no entitlement pack in the answer", signIn, user: a.name }
        const total = d.basic + d.bonus
        const used = d.used + d.usedBonus
        const out = { plan: d.plan || "Free", user: a.name || a.uid, signIn }
        if (total > 0) {
          // the allowance rides the window (amount of limit, in dollars), as
          // WorkBuddy's does, so magpie says it in the window's row, used or
          // left, in its own words and number format (yetone/magpie#694)
          const w = { name: "Dollar Usage", used: Math.round(Math.max(0, Math.min(100, (used / total) * 100)) * 100) / 100, amount: round(used), limit: round(total), unit: "usd" }
          if (d.end) w.resetsAt = new Date(d.end).toISOString()
          out.windows = [w]
        }
        return out
      },
    },
  },
}

// traeHost is a host a sign-in named, when it is a well-formed https one
// on Trae's own domains (no port, no credentials), as origin plus any path;
// "" for anything else, which is then not taken
const TRAE_DOMAINS = ["trae.cn", "trae.ai", "mchost.guru"]
function traeHost(h) {
  try {
    const u = new URL(String(h ?? "").trim())
    if (u.protocol !== "https:" || u.username || u.password || u.port || u.search || u.hash) return ""
    const n = u.hostname.toLowerCase()
    if (!TRAE_DOMAINS.some((d) => n === d || n.endsWith("." + d))) return ""
    return (u.origin + u.pathname).replace(/\/+$/, "")
  } catch {
    return ""
  }
}

// namedHost is a host as a sign-in's callback names it, read as https when
// it names no scheme: Trae CN's enterprise console names its own as a bare
// hostname ("console.enterprise.trae.cn"), and that seat's sign-in was
// kept with no host at all and chatted on the consumer gateway, which
// serves it no c-* model and answers glm-5.4 with 1005 (plugins#1516). A
// value with a scheme is kept as named, so http and the rest are still
// refused by traeHost.
function namedHost(h) {
  const t = String(h ?? "").trim()
  return t && !/^[a-z][a-z0-9+.-]*:\/\//i.test(t) ? "https://" + t : t
}

// saasToken: the access token is an enterprise (SaaS) seat's, as its JWT's
// scope says ({"scope":"saas","tenant_id":"tob_online",…}, plugins#1516).
// A tenant's token may hold its claims under data ({"data":{"scope":"saas",
// …},"exp":…}), and the scope is read there too
function saasToken(token) {
  try {
    const p = JSON.parse(Buffer.from(String(token).split(".")[1], "base64url").toString())
    const scope = typeof p?.scope === "string" ? p.scope : p?.data?.scope
    return String(scope ?? "").toLowerCase() === "saas"
  } catch {
    return false
  }
}

// authHostOf is the host a sign-in named for its tokens, when it named one
// on the site's own domain (an enterprise's may differ from the consumer
// one); "" when it named none, and the site's own is used
function authHostOf(h, site) {
  const t = traeHost(h)
  if (!t) return ""
  const n = new URL(t).hostname
  return n === site.webHost || n.endsWith("." + site.webHost) ? t : ""
}

// accountOf keeps the account fields of the sign-in's user info that say
// what kind of account it is (tenant, enterprise, login type), plain values
// only and never anything that looks like a secret, for later use; nothing
// sends them
function accountOf(info) {
  const out = {}
  for (const [k, v] of Object.entries(info ?? {})) {
    if (!/tenant|enterprise|saas|login|org|team|sso|^ent|usertype|accounttype/i.test(k)) continue
    if (/token|secret|key|password|cookie|session|jwt/i.test(k)) continue
    if (v === null || ["string", "number", "boolean"].includes(typeof v)) out[k] = v
  }
  return out
}

const SIGN_IN_TIMEOUT = 10 * 60 * 1000
const EARLY_MS = 2 * 60 * 1000 // a token this close to its end is renewed before a request
const LEAD_MS = 10 * 60 * 1000 // and this close, magpie renews it ahead of time (auth.refresh)
const DAY = 24 * 3600 * 1000
// REREAD_MS is how long a list read keeps its answer before a request that
// wants levels may read the list again: it holds whether the read produced an
// entry for the model or not, so a list answering badly (or one that doesn't
// name the model) costs one read, not one per request. A request path that
// reads on every attempt would otherwise pay two 20s timeouts on each turn —
// the branch costs the chat itself nothing to answer from.
const REREAD_MS = 5 * 60 * 1000

// a reply limit of 0 is one Trae doesn't say: magpie then takes models.dev's
// for the model (magpie's catalog), where a made-up 32K told agents a far
// smaller one than DeepSeek V4.1 Flash's (ARNO on magpie's Discord)
const MODEL = { attachment: false, tool_call: true, reasoning: true, temperature: true, limit: { context: 128_000, output: 0 }, modalities: { input: ["text"], output: ["text"] } }
// a site's fallback list names only what differs from MODEL: the defaults go
// in here, where MODEL is defined (a site table above can't spread it)
for (const site of Object.values(SITES)) {
  for (const [id, m] of Object.entries(site.models)) site.models[id] = { ...MODEL, ...m }
}

const digits = (n) => Array.from({ length: n }, (_, i) => (i === 0 ? randomInt(1, 10) : randomInt(0, 10))).join("")
const statusLine = (status) => `${status} ${STATUS_CODES[status] ?? ""}`.trim()
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

// device is the machine an account signs in from, made once at sign-in and
// named to trae.cn's authorization page, then sent with every request: a
// fresh one each time is what the relays saw requests dropped for. Trae
// CN's id has the shape its clients' have, 16 digits: the device service
// gives the IDE a 15- or 16-digit one (iCubeAuthInfo://icube-dc:<id>, see
// clientDevice), and Trae CN answers a check-in claim on a 19-digit id
// 9074 where the same account and token on a 16-digit one are taken
// (magpie-community/plugins#194). The check-in no longer goes on it: since
// plugins#709 Trae CN refuses 16 digits there too, and ugDevice makes the
// claim's 15-digit id. Trae's global site keeps the 19 digits it was signed
// in with: nothing says its ids are shaped otherwise.
const newDevice = (site) => ({ deviceId: digits(site?.id === "trae-cn" ? 16 : 19), machineId: randomBytes(16).toString("hex"), ...newDeviceKey() })

// ugDevice is the device id a Trae CN account's check-in goes on when this
// machine's client isn't signed in as it: its own when that is already 15
// digits, else a 15-digit id made from its own device id and uid. On
// 2026-11-05 (plugins#709) Trae CN answered the plugin's claim on an
// account's own 16-digit id 9074, and the same account, token, headers and
// body, seconds later, on a 15-digit id (a random one nothing had
// registered) were taken: on three accounts, from two machines on two
// ISPs, with magpie's headers and with wild-work's alike, 16 digits was
// refused every time and 15 taken every time. The client-less tools that
// check in (trae-mate, providers-hub, wild-work) all send 15 digits too.
// #194 had found 19 refused and 16 taken; a server-side change between
// the two is the plain reading. The id is the same on every check-in of
// the account, never rotated and never another account's, and its first
// digit is never 0 (a 0 would make it 14 digits as a number): it is the
// account's own device in the shape Trae CN takes, not a new device to get
// past a refusal, and a 9095 (this device is in for today) on it stays the
// day's answer. The chat's pages and the renewal keep the device the
// account signed in with (16 digits since 0.2.16, 19 before): nothing
// measured says they want another, and the device is bound into the
// renewed JWT.
function ugDevice(a) {
  const id = String(a.deviceId ?? "")
  if (/^\d{15}$/.test(id)) return id
  if (!id && !a.uid) return id
  const n = BigInt("0x" + createHash("sha256").update(`trae-cn-device\0${id}\0${a.uid ?? ""}`).digest("hex").slice(0, 30))
  return String(100_000_000_000_000n + (n % 900_000_000_000_000n))
}

// newDeviceKey is the device's key pair, an ECDSA P-256 one as the clients
// keep (iCubeAuthInfo://icube-dc:<device>), whose public half goes with a
// renewal and whose private half signs it (DeviceProof). An account signed
// in before 0.2.3 has none and is given one at its next renewal.
function newDeviceKey() {
  const { publicKey, privateKey } = generateKeyPairSync("ec", { namedCurve: "prime256v1" })
  return {
    devicePublicKey: publicKey.export({ type: "spki", format: "pem" }),
    devicePrivateKey: privateKey.export({ type: "pkcs8", format: "pem" }),
  }
}

// whenOf reads one of Trae's expiry times: seconds, milliseconds or ISO
function whenOf(v) {
  if (v === undefined || v === null || v === "") return 0
  if (typeof v === "string" && !/^\d+$/.test(v.trim())) {
    const t = Date.parse(v)
    return isNaN(t) ? 0 : t
  }
  const n = Number(v)
  if (!Number.isFinite(n) || n <= 0) return 0
  return n < 1e11 ? n * 1000 : n
}

// jwtExp is a JWT's exp, in ms, 0 when it has none
function jwtExp(token) {
  try {
    const p = JSON.parse(Buffer.from(String(token).split(".")[1], "base64url").toString())
    return whenOf(p?.exp)
  } catch {
    return 0
  }
}

const parseJSON = (s) => {
  if (s && typeof s === "object") return s
  try {
    const v = JSON.parse(String(s ?? ""))
    return v && typeof v === "object" ? v : {}
  } catch {
    return {}
  }
}

// ---- the sign-in as kept ------------------------------------------------------

// The sign-in is kept as OpenCode keeps an OAuth one: access the
// Cloud-IDE-JWT, refresh the refresh token, expires the JWT's end; beside
// them the account, the client it was issued to and its device.
function toAuth(s, site) {
  return {
    type: "oauth",
    access: s.token,
    refresh: s.refresh,
    expires: s.expires || jwtExp(s.token) || Date.now() + DAY,
    accountId: s.name || s.uid,
    uid: s.uid,
    clientId: s.clientId || site.clientId,
    deviceId: s.deviceId,
    machineId: s.machineId,
    ...(s.devicePrivateKey ? { devicePublicKey: s.devicePublicKey, devicePrivateKey: s.devicePrivateKey } : {}),
    // the model host the sign-in named, if it named one
    ...(site.modelHost(s.api) ? { api: s.api } : {}),
    ...(s.region ? { region: s.region } : {}),
    // the host the sign-in named, its own token host if it named one, and
    // what kind of account it is (an enterprise one's tenant), kept as given
    ...(traeHost(s.host) ? { host: traeHost(s.host) } : {}),
    ...(authHostOf(s.authHost, site) ? { authHost: authHostOf(s.authHost, site) } : {}),
    ...(s.account && Object.keys(s.account).length ? { account: s.account } : {}),
    // an enterprise seat its console turned a chat away from (4245)
    ...(s.consoleChat === false ? { consoleChat: false } : {}),
  }
}

function fromAuth(auth, site) {
  if (auth?.type !== "oauth" || !auth.access) return null
  return {
    token: auth.access,
    refresh: auth.refresh ?? "",
    expires: Number(auth.expires) || 0,
    uid: String(auth.uid ?? ""),
    name: String(auth.accountId ?? ""),
    clientId: auth.clientId || site.clientId,
    deviceId: auth.deviceId || "",
    machineId: auth.machineId || "",
    devicePublicKey: auth.devicePublicKey || "",
    devicePrivateKey: auth.devicePrivateKey || "",
    // a seat kept with no host (before 0.2.54 a console naming its host bare
    // left both out, plugins#1516) is its console's, as its token says
    api: auth.api || (!auth.host && saasToken(auth.access) ? traeHost(namedHost(site.consoleHost)) : ""),
    region: site.regionOf(auth),
    host: auth.host || (!auth.api && saasToken(auth.access) ? traeHost(namedHost(site.consoleHost)) : ""),
    authHost: authHostOf(auth.authHost, site),
    account: auth.account && typeof auth.account === "object" ? auth.account : {},
    ...(auth.consoleChat === false ? { consoleChat: false } : {}),
  }
}

// apiOf is the model host for an account
function apiOf(a, site) {
  return site.apiOf(a)
}

// ownPage: url is one of Trae's own JSON pages (the daily check-in,
// credits), which the account's fetch sends as the account rather than as
// a chat
function ownPage(url, site) {
  return site.ownPage(url)
}

// ---- errors --------------------------------------------------------------------

class Expired extends Error {
  constructor(msg) {
    super(msg)
    this.signIn = "expired"
  }
}

// errorOf is what Trae said went wrong, from its several shapes: a business
// {code, message}, {error: {code, message}}, or ByteDance's
// {ResponseMetadata: {Error: {Code, Message}}}
function errorOf(v) {
  v = parseJSON(v)
  const meta = v?.ResponseMetadata?.Error
  if (meta && (meta.Code || meta.Message)) return { code: meta.Code ?? "", message: String(meta.Message ?? meta.Code ?? "") }
  const e = v?.error && typeof v.error === "object" ? v.error : v
  const code = e?.code ?? e?.Code ?? v?.code ?? ""
  const message = e?.message ?? e?.msg ?? e?.Message ?? (typeof v?.error === "string" ? v.error : "") ?? ""
  return { code, message: String(message || "") }
}

// lapsed: Trae turned the token away. 1001 is its "not signed in".
// The realms differ in which codes they send: the international deployment
// also answers 20101 for a token it no longer takes.
const CN_LAPSED = [1001, "1001", 401, "401"]
const lapsedCode = (code, site) => (site?.lapsed ?? CN_LAPSED).includes(code)
const lapsedWords = /not ?log(ged)? ?in|unauthori[sz]ed|token (is )?(expired|invalid)|jwt|未登录|登录(已)?(过期|失效)/i
const CN_QUOTA = [4008, "4008", 1005, "1005"]
const quotaCode = (code, site) => (site?.quota ?? CN_QUOTA).includes(code)
const quotaWords = /quota|credit|insufficient|exceed|limit|额度|积分|次数|上限|用完/i

// errorResponse is an OpenAI-style error, as the agent reads one
const errorResponse = (status, message, signIn) => {
  const headers = { "content-type": "application/json" }
  if (signIn) headers["X-Magpie-Sign-In"] = signIn
  return new Response(JSON.stringify({ error: { message, type: status === 429 ? "rate_limit_error" : "api_error", code: null } }), { status, headers })
}

// ---- tokens -----------------------------------------------------------------------

// exchange trades a refresh token for a new Cloud-IDE-JWT, as the IDE
// does: the answer's Result holds the new token pair and the account.
// Trae issues a new refresh token each time and spends the old one.
async function exchange(refresh, clientId, site, host = site.hosts.auth) {
  let res
  try {
    res = await fetch(host.replace(/\/+$/, "") + "/cloudide/api/v3/trae/oauth/ExchangeToken", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ClientID: clientId || site.clientId, RefreshToken: refresh, ClientSecret: "-", UserID: "" }),
      signal: AbortSignal.timeout(20_000),
    })
  } catch (e) {
    throw new Error(`${site.realm}: renewing the sign-in: ` + (e?.message ?? e))
  }
  const text = await res.text()
  const v = parseJSON(text)
  const r = v.Result ?? v.result ?? v
  const token = r?.Token ?? r?.token ?? ""
  if (res.ok && token) {
    const info = parseJSON(r.UserInfo ?? r.userInfo)
    return {
      token,
      refresh: r.RefreshToken ?? r.refreshToken ?? refresh,
      expires: whenOf(r.TokenExpireAt ?? r.tokenExpireAt) || jwtExp(token),
      clientId: r.ClientID ?? r.clientId ?? clientId,
      uid: String(info.UserID ?? info.userId ?? r.UserID ?? ""),
      name: String(info.ScreenName ?? info.screenName ?? ""),
      api: info.Host ?? "",
      region: site.regionOf(info),
      account: accountOf(info),
    }
  }
  const e = errorOf(text)
  const msg = e.message || (text.trim() ? text.trim().slice(0, 200) : statusLine(res.status))
  // a refresh token Trae no longer takes (spent, revoked, past its end, or
  // of another client) is a sign-in to make again
  if ([400, 401, 403].includes(res.status) || /refresh|expired|invalid|not matched|revoked|unauthori/i.test(msg) || String(e.code) === "10101") {
    throw new Expired(`${site.realm}'s sign-in has expired (${msg}); sign in again`)
  }
  throw new Error(`${site.realm}: renewing the sign-in: ${statusLine(res.status)} ${msg}`.trim())
}

// proofOf is a renewal's DeviceProof: the device key's ECDSA-SHA256
// signature (DER, base64) of the method, path, client, refresh token, time
// and nonce, one to a line, as the clients sign it
function proofOf(path, clientId, refresh, privateKey, at = Math.floor(Date.now() / 1000), nonce = randomBytes(16).toString("hex")) {
  const text = ["POST", path, clientId, refresh, String(at), nonce].join("\n")
  return { Signature: sign("sha256", Buffer.from(text), privateKey).toString("base64"), Timestamp: at, Nonce: nonce }
}

// deviceInfo is the device a renewal names, its public key with it
function deviceInfo(a, as, site) {
  return {
    DeviceID: a.deviceId,
    MachineID: a.machineId,
    PlatformCode: as.platform,
    DeviceType: "PC",
    DeviceName: "",
    DeviceModel: "",
    ClientVersion: as.version,
    DevicePublicKey: a.devicePublicKey,
    DeviceBrand: site.brand,
    DeviceCPU: "AMD",
    OSInfo: "Windows",
    OSVersion: "10.0.22631",
  }
}

// boundExchange renews the JWT as the clients do (site.deviceExchange), so
// that it is bound to the account's device; an account with no device key
// is given one first. It tries each client the site names, and throws the
// last answer when none takes it.
async function boundExchange(a, site, host = site.hosts.auth) {
  const dx = site.deviceExchange
  const d = a.devicePrivateKey && a.devicePublicKey ? a : { ...a, ...newDeviceKey() }
  let last
  for (const as of dx.as) {
    let res
    try {
      res = await fetch(host.replace(/\/+$/, "") + dx.path, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...(a.token ? { Authorization: `Cloud-IDE-JWT ${a.token}` } : {}) },
        body: JSON.stringify({
          ClientID: as.clientId,
          ClientSecret: "",
          RefreshToken: a.refresh,
          DeviceInfo: deviceInfo(d, as, site),
          DeviceProof: proofOf(dx.path, as.clientId, a.refresh, d.devicePrivateKey),
          IDEVersion: as.version,
        }),
        signal: AbortSignal.timeout(20_000),
      })
    } catch (e) {
      last = new Error(`${site.realm}: renewing the sign-in for its device: ` + (e?.message ?? e))
      continue
    }
    const text = await res.text()
    const v = parseJSON(text)
    const r = v.Result ?? v.result ?? {}
    const token = r.Token ?? r.token ?? ""
    if (res.ok && token) {
      return {
        token,
        refresh: r.RefreshToken ?? r.refreshToken ?? a.refresh,
        expires: whenOf(r.TokenExpireAt ?? r.tokenExpireAt) || jwtExp(token),
        devicePublicKey: d.devicePublicKey,
        devicePrivateKey: d.devicePrivateKey,
      }
    }
    const e = errorOf(text)
    last = new Error(`${site.realm}: renewing the sign-in for its device: ${statusLine(res.status)} ${e.message || text.trim().slice(0, 200)}`.trim())
  }
  throw last
}

// renewal renews an account's JWT: bound to its device where the site can
// (boundExchange), else, or when Trae turns that away, at /cloudide/… as
// before 0.2.3 (exchange). A device key made for the account goes with
// either, so the next renewal signs with the same one.
async function renewal(a, site) {
  // the token host the sign-in named, else the site's
  const host = authHostOf(a.authHost, site) || site.hosts.auth
  if (!site.deviceExchange) return exchange(a.refresh, a.clientId, site, host)
  const keys = a.devicePrivateKey && a.devicePublicKey ? {} : newDeviceKey()
  try {
    return await boundExchange({ ...a, ...keys }, site, host)
  } catch {}
  return { ...(await exchange(a.refresh, a.clientId, site, host)), ...keys }
}

// ---- the browser sign-in --------------------------------------------------------

const page = (ok, title, text) => `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${title}</title>
<style>body{font:15px/1.5 -apple-system,system-ui,sans-serif;margin:0;display:grid;place-items:center;min-height:100vh;background:#f6f6f4;color:#222}
@media(prefers-color-scheme:dark){body{background:#1c1c1c;color:#eee}}main{max-width:420px;padding:24px}h1{font-size:20px;margin:0 0 8px}p{margin:0;opacity:.75}
.dot{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:8px;background:${ok ? "#2a9d58" : "#d1453b"}}</style>
<main><h1><span class="dot"></span>${title}</h1><p>${String(text).replace(/[<>&]/g, (c) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;" })[c])}</p></main>`

// signedIn reads trae.cn's callback: userJwt (the token pair) and userInfo
// (the account), or, from its older page, a refresh token alone, which is
// exchanged for the pair
async function signedIn(q, device, site, { enterprise = false } = {}) {
  const jwt = parseJSON(q.get("userJwt"))
  const info = parseJSON(q.get("userInfo"))
  // the enterprise console's page names its Api host; one that names none
  // still names its console, which is the seat's host
  // (bare or not: namedHost), the first that is a Trae host
  const named = [q.get("host"), info.Host, ...(enterprise ? [q.get("consoleHost"), site.consoleHost] : [])]
  const host = named.map((h) => traeHost(namedHost(h))).find(Boolean) ?? ""
  let s = {
    token: jwt.Token ?? jwt.token ?? "",
    refresh: jwt.RefreshToken ?? jwt.refreshToken ?? q.get("refreshToken") ?? "",
    expires: whenOf(jwt.TokenExpireAt ?? jwt.tokenExpireAt),
    clientId: jwt.ClientID ?? jwt.clientId ?? q.get("clientId") ?? site.clientId,
    uid: String(info.UserID ?? info.userId ?? q.get("userId") ?? ""),
    name: String(info.ScreenName ?? info.screenName ?? ""),
    api: host,
    region: site.regionOf(info),
    host,
    // a token host the callback named, if it named one
    authHost: authHostOf(q.get("authHost") || q.get("auth_host") || info.AuthHost || info.authHost, site),
    account: accountOf(info),
  }
  const authHost = s.authHost || site.hosts.auth
  if (!s.token && s.refresh) {
    const x = await exchange(s.refresh, s.clientId, site, authHost)
    s = { ...s, ...x, uid: x.uid || s.uid, name: x.name || s.name, api: x.api || s.api, region: x.region || s.region, host: s.host || x.api, account: { ...x.account, ...s.account } }
  }
  if (!s.token) throw new Error(`${site.webHost} sent back no token`)
  if (!s.refresh) throw new Error(`${site.webHost} sent back no refresh token`)
  s = { ...s, ...device }
  // the token the page gives is bound to no device: it is renewed for this
  // one at once, so a check-in takes it; when Trae won't, it does as is
  if (site.deviceExchange) {
    try {
      const x = await boundExchange(s, site, authHost)
      s = { ...s, token: x.token, refresh: x.refresh, expires: x.expires || s.expires }
    } catch {}
  }
  return s
}

// browserSignIn is the IDE's sign-in: trae.cn's authorization page, back
// to a callback on 127.0.0.1 (the page takes no other kind).
//
// enterprise opens the realm's enterprise console's own authorization page
// (console.enterprise.trae.cn/authorization, the same parameters and the
// same callback) instead of the consumer site's. Since November 2026 trae.cn's
// page sends a signed-out browser to a Doubao/Feishu account sign-in
// (accounts.doubao.com) with no way to an enterprise one, so a seat that
// signs in with its TRAE enterprise email, the console's Doubao/Feishu tab
// or the tenant's SSO has to start on the console (@yalifesign on X). The
// console's page calls back with userJwt, userInfo, refreshToken and host
// (its own Api host), which signedIn reads as before.
async function browserSignIn(site, { enterprise = false } = {}) {
  const device = newDevice(site)
  const trace = randomUUID()
  let over = false
  let settle
  const done = new Promise((r) => (settle = r))
  const finish = (result) => {
    if (over) return
    over = true
    settle(result)
  }
  const server = createServer(async (req, res) => {
    // the site's page may call the callback from script as well as open it
    const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "GET, OPTIONS", "Access-Control-Allow-Headers": "Content-Type" }
    if (req.method === "OPTIONS") return res.writeHead(204, cors).end()
    const url = new URL(req.url ?? "/", "http://127.0.0.1")
    const html = (body) => {
      res.writeHead(200, { ...cors, "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" })
      res.end(body)
    }
    if (url.pathname !== "/authorize") return res.writeHead(404, cors).end()
    const q = url.searchParams
    if (over) return html(page(false, "This sign-in is over", "Start it again in magpie."))
    if (q.get("error")) {
      const msg = q.get("error_description") || q.get("error")
      finish({ type: "failed", error: msg })
      return html(page(false, "Sign-in didn't finish", msg))
    }
    if (!q.get("userJwt") && !q.get("refreshToken")) return html(page(false, "Nothing to sign in with", `${site.webHost} sent no token; start the sign-in again.`))
    try {
      const s = await signedIn(q, device, site, { enterprise })
      finish({ ...toAuth(s, site), type: "success" })
      html(page(true, "You're signed in", `${s.name || s.uid || `Your ${site.name} account`} is signed in. You can close this tab.`))
    } catch (e) {
      finish({ type: "failed", error: e.message })
      html(page(false, "Sign-in didn't finish", e.message))
    }
  })
  await new Promise((resolve, reject) => {
    server.once("error", reject)
    server.listen(0, "127.0.0.1", resolve)
  })
  const callback = `http://127.0.0.1:${server.address().port}/authorize`
  const timer = setTimeout(() => finish({ type: "failed", error: "the sign-in timed out" }), SIGN_IN_TIMEOUT)
  done.then(() => {
    clearTimeout(timer)
    setTimeout(() => server.close(), 5_000).unref?.()
  })
  const q = new URLSearchParams({
    login_version: "1",
    auth_from: "solo",
    login_channel: "native_ide",
    plugin_version: site.pluginVersion,
    auth_type: "local",
    client_id: site.clientId,
    redirect: "0",
    login_trace_id: trace,
    auth_callback_url: callback,
    machine_id: device.machineId,
    device_id: device.deviceId,
    x_device_id: device.deviceId,
    x_machine_id: device.machineId,
    x_device_brand: site.brand,
    x_device_type: "windows",
    x_os_version: "Windows 10 Pro",
    x_env: "",
    x_app_version: site.ideVersion,
    x_app_type: "stable",
    // the enterprise (SaaS) sign-in is offered beside the personal one: an
    // enterprise subscription signs in there (@shad70w0 on X)
    hide_saas_login: "false",
  })
  return {
    url: `${enterprise ? site.hosts.console : site.hosts.web}/authorization?${q}`,
    instructions: enterprise
      ? `Sign in to your ${site.name} enterprise seat in the browser (enterprise email, Doubao/Feishu or your company's SSO) and allow the sign-in. It finishes here by itself.`
      : `Sign in to ${site.name} (${site.webHost}) in the browser and allow the sign-in. It finishes here by itself.`,
    method: "auto",
    callback: () => done,
  }
}

// ---- requests ---------------------------------------------------------------------

// headers are the IDE's, for the account and its device
function ideHeaders(a, site, extra = {}) {
  return {
    "Content-Type": "application/json",
    Authorization: `Cloud-IDE-JWT ${a.token}`,
    "X-Cloudide-Token": a.token,
    "x-ide-token": a.token,
    "x-uid": a.uid,
    "x-app-id": site.appId,
    "x-device-id": a.deviceId,
    "x-machine-id": a.machineId,
    "x-request-id": randomUUID(),
    "x-app-version": site.clientVersion,
    "x-app-version-code": site.clientVersionCode,
    "x-ide-version": site.clientVersion,
    "x-ide-version-code": site.clientVersionCode,
    "x-ide-version-type": "stable",
    "x-device-cpu": "AMD",
    "x-device-brand": site.brand,
    "x-device-type": "windows",
    "x-os-version": "Windows 10",
    "x-system-type": "Windows",
    ...extra,
  }
}

// ugUA is the User-Agent a growth page (/trae/api/v2/ug/…: the daily
// check-in) is sent with: TRAE SOLO CN's Electron shell, as its version
// is named. Bun's own (Bun/1.x) reads as a script, and Trae answers a
// script's check-in with 9074 「当前参与用户太多，请稍后再试」 however
// seldom it asks (yetone/magpie#808; qilimixingkong/trae-checkin found
// the same).
const ugUA = (site) =>
  `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) TRAE-SOLO-CN/${site.clientVersion} Chrome/120.0.6099.291 Electron/28.2.10 Safari/537.36`

// ugHeaders are the headers Trae CN's IDE (3.3.104) sends a growth page
// with, and only those: its JWT, then its device (fb: x-device-id,
// x-device-brand, x-device-type, x-os-version, x-app-version), not the
// chat's tokens and versions. own is this machine's Trae CN client, when
// it is signed in as this very account (ownClient): its device id and
// this machine's OS go instead of the account's, and no brand is named
// (fb leaves it out when it has no model to name).
function ugHeaders(a, site, extra = {}, own) {
  const h = {
    "Content-Type": "application/json",
    Authorization: `Cloud-IDE-JWT ${a.token}`,
    "User-Agent": ugUA(site),
    "x-device-id": a.deviceId,
    "x-device-brand": site.brand,
    "x-device-type": "Windows",
    "x-os-version": "10.0.22631",
    "x-app-version": site.clientVersion,
  }
  if (own) {
    h["x-device-id"] = own.deviceId
    h["x-device-type"] = own.type
    h["x-os-version"] = own.os
    delete h["x-device-brand"]
  }
  return { ...h, ...extra }
}

// clientShape is the claim request that three tools which check in Trae CN
// accounts with no Trae CN client on the machine send, and which Trae CN
// takes: luckymiaow/trae-mate (checkin.rs build_headers, device_map.rs;
// MIT), iJetLi/dsh-providers-hub's port of it (traeCheckinHeaders), and
// rockswang/wild-work. All three send body {}, `x-user-region: CN` and a
// 15-digit device id, none sends the Electron User-Agent or 0.1.69, and
// none retries a 9074 (wild-work's 8s retry never ran: every one of its
// claims was taken first time, plugins#709). On plugins#722 the same
// account this plugin's claim gets 9074 on checks in daily through
// providers-hub. This is trae-mate's request as it is: its headers, and
// its device, market user and session ids made from the uid alone, so an
// account checks in on the device those tools already use for it.
// plugins#709's bisect then found the id's length to be what Trae CN
// decides on (16 refused, 15 taken, the headers and body changing
// nothing), so since 0.2.30 the first claim goes on 15 digits too
// (ugDevice). This request stays as the one fallback after a 9074: the
// bisect didn't send it with a 16-digit id, so that nothing else in it
// matters is not measured.
const seeded = (seed, salt, n) => {
  const out = []
  for (let i = 0; out.length < n; i++) {
    const c = Buffer.alloc(4)
    c.writeUInt32BE(i)
    out.push(...createHash("sha256").update(`${salt}:${seed}`).update(c).digest())
  }
  return out.slice(0, n)
}
const shapeDevice = (uid) => seeded(String(uid), "devid", 15).map((b) => b % 10).join("")
function shapeMarketUser(uid) {
  const b = seeded(String(uid), "market", 16)
  b[6] = (b[6] & 0x0f) | 0x40
  b[8] = (b[8] & 0x3f) | 0x80
  const h = Buffer.from(b).toString("hex")
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`
}
function clientShapeHeaders(a) {
  const uid = String(a.uid)
  return {
    Authorization: `Cloud-IDE-JWT ${a.token}`,
    Accept: "*/*",
    "Accept-Encoding": "gzip, deflate",
    "Accept-Language": "zh-CN",
    "Content-Type": "application/json",
    "User-Agent": "VSCode 1.107.1 (TRAE SOLO CN)",
    "x-market-client-id": "VSCode 1.107.1",
    "x-market-user-id": shapeMarketUser(uid),
    "x-user-region": "CN",
    "x-device-id": shapeDevice(uid),
    "x-lgw-req-sdk-type": "3",
    "package-type": "stable_cn",
    "x-lscbd-aid": "787976",
    "x-lscbd-platform": "windows",
    "app-version": "0.1.45",
    "x-tt-trace-id": `00-${randomBytes(8).toString("hex")}-01`,
    "vscode-sessionid": Buffer.from(seeded(uid, "sess", 32)).toString("hex"),
    "x-request-id": randomUUID(),
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "no-cors",
    "sec-fetch-site": "none",
  }
}

// ---- this machine's own Trae CN client ----------------------------------------------

// Trae CN's desktop client keeps its state in a VS Code-style
// globalStorage/storage.json. The device id Trae's device service gave
// it is in a key's name, iCubeAuthInfo://icube-dc:<digits> (15 or 16
// digits seen); its sign-in is the value of iCubeAuthInfo://icube.cloudide,
// a JSON envelope (userId, token, …) stored as is or obfuscated with the
// client's fixed AES-128-CBC codec. Seen in real clients' files
// (yetone/magpie#808: the same id in the client's own did= query;
// yetone/magpie#1705) and read the same way by dingminhua/dsh-connect-trae
// (MIT), whose codec this is.
const DC_KEY = "iCubeAuthInfo://icube-dc:"
const AUTH_KEY = "iCubeAuthInfo://icube.cloudide"

// ownClient.paths are where storage.json may be, in order; tests replace it
const ownClient = {
  paths: () => clientStoragePaths(process.platform, homedir(), process.env),
}

// CLIENT_PROFILES are the folder names a Trae CN client profile is kept
// under: the IDE's own, and TRAE SOLO CN's, which is a client of the same
// realm and signs in its own account. A profile started with its own
// --user-data-dir is found only if it is one of these; there is no list of
// them to read, and nothing is guessed from a folder's contents.
const CLIENT_PROFILES = ["Trae CN", "TRAE SOLO CN", "trae-cn"]

function clientStoragePaths(platform, home, env) {
  const file = (root, name) => join(root, name, "User", "globalStorage", "storage.json")
  if (platform === "darwin") return CLIENT_PROFILES.filter((n) => n !== "trae-cn").map((n) => file(join(home, "Library", "Application Support"), n))
  if (platform === "win32") {
    // the two roots are often the same folder: APPDATA and the home's own
    // AppData\Roaming. They are compared as one system spells them, so a
    // difference of separator or case alone doesn't read the same file twice
    const spell = (r) => String(r ?? "").replace(/[\\/]+/g, "\\").replace(/\\+$/, "").toLowerCase()
    const roots = []
    for (const r of [env.APPDATA, join(home, "AppData", "Roaming")]) {
      if (!r) continue
      if (roots.some((was) => spell(was) === spell(r))) continue
      roots.push(r)
    }
    return roots.flatMap((r) => CLIENT_PROFILES.map((n) => file(r, n)))
  }
  if (platform === "linux") return CLIENT_PROFILES.map((n) => file(env.XDG_CONFIG_HOME || join(home, ".config"), n))
  return []
}

// clientDevice is the device id of a Trae CN client profile on this machine
// that is signed in as uid, else undefined. It only reads: nothing of the
// client's is written, kept or sent but that id, and the client's own token
// is read past, never used. Never an id made up or changed: an account no
// profile is signed in as never gets a client's id.
//
// A machine can hold more than one profile — Trae CN and TRAE SOLO CN each
// write one, and a client started with its own --user-data-dir writes
// another — and each profile's storage.json names the account it is signed
// in as, with that account's device. So every profile is read and the one
// signed in as uid answers with its device, which is what lets two accounts
// each check in on a real client's device. A profile that isn't signed in
// as uid, that can't be read or made out, or that names no single device
// is passed over rather than ending the search: before, the first profile
// read decided for all of them, so a second account's own profile was never
// seen (and one unreadable file hid every profile after it).
async function clientDevice(uid) {
  if (!uid) return undefined
  return (await clientProfiles()).find((p) => String(p.uid) === String(uid))?.device
}

// clientProfiles are this machine's Trae CN client profiles that can be
// made out, in ownClient.paths' order: the account each is signed in as
// and its one device. A file that isn't there, can't be read or parsed,
// names no single device or has a sign-in that doesn't decode is left out.
async function clientProfiles() {
  const out = []
  for (const p of ownClient.paths()) {
    let text
    try {
      text = await readFile(p, "utf8")
    } catch {
      continue // not installed here
    }
    let doc
    try {
      doc = JSON.parse(text)
    } catch {
      continue // not a file we can make out: the next profile may be
    }
    try {
      const ids = Object.keys(doc ?? {}).filter((k) => k.startsWith(DC_KEY)).map((k) => k.slice(DC_KEY.length))
      if (ids.length !== 1 || !/^\d{8,20}$/.test(ids[0])) continue
      const who = clientAuth(doc[AUTH_KEY])?.userId
      if (who != null && String(who) !== "") out.push({ uid: String(who), device: ids[0] })
    } catch {
      continue // a sign-in that doesn't decode: the next profile may be
    }
  }
  return out
}

// deviceNote says which device a Trae CN check-in went on, for the message
// of a claim Trae refused (9074) or found already in (9095): the device of
// a client on this machine signed in as uid, or magpie's own for the
// account and why — how many client profiles were found, and that none is
// signed in as it. It names no uid and no device id. A client's device
// that another profile, signed in as another account, also has is said:
// both accounts check in on one device, and Trae takes one a day
// (plugins#436). It only states what was read; it promises no fix.
async function deviceNote(uid) {
  const all = await clientProfiles()
  const mine = all.find((p) => String(p.uid) === String(uid ?? ""))
  if (mine) {
    const shared = all.some((p) => p.device === mine.device && String(p.uid) !== String(uid))
    return shared
      ? "sent on this machine's Trae CN client's device, signed in as this account — another profile here, signed in as another account, has the same device"
      : "sent on this machine's Trae CN client's device, signed in as this account"
  }
  if (!all.length) return "sent on magpie's own device for this account: no Trae CN client profile was found on this machine"
  const n = all.length
  return `sent on magpie's own device for this account: ${n} Trae CN client profile${n === 1 ? " is" : "s are"} on this machine, none signed in as this account`
}

// clientAuth is the client's sign-in envelope, as stored or decoded
function clientAuth(v) {
  if (typeof v !== "string" || !v.trim()) return undefined
  const t = v.trim()
  return JSON.parse(t.startsWith("{") ? t : clientDecode(t))
}

const xorOf = (a, b) => Buffer.from(a.map((x, i) => x ^ b[i]))
const CODEC = {
  "746305100000": xorOf(
    [82, 9, 106, 213, 48, 54, 165, 56, 191, 64, 163, 158, 129, 243, 215, 251, 124, 227, 57, 130, 155, 47, 255, 135, 52, 142, 67, 68, 196, 222, 233, 203, 84, 123, 148, 50, 166, 194, 35, 61, 238, 76, 149, 11, 66, 250, 195, 78, 8, 46, 161, 102, 40, 217, 36, 178, 118, 91, 162, 73, 109, 139, 209, 37],
    [31, 221, 168, 51, 136, 7, 199, 49, 177, 18, 16, 89, 39, 128, 236, 95, 96, 81, 127, 169, 25, 181, 74, 13, 45, 229, 122, 159, 147, 201, 156, 239, 160, 224, 59, 77, 174, 42, 245, 176, 200, 235, 187, 60, 131, 83, 153, 97, 23, 43, 4, 126, 186, 119, 214, 38, 225, 105, 20, 99, 85, 33, 12, 125],
  ),
  "123920200203": xorOf(
    [191, 192, 216, 250, 122, 246, 220, 97, 31, 254, 98, 27, 8, 72, 71, 176, 135, 99, 96, 18, 127, 101, 203, 104, 211, 102, 191, 125, 37, 72, 150, 156, 51, 229, 121, 35, 17, 153, 141, 177, 110, 131, 150, 128, 172, 255, 254, 6, 18, 140, 55, 62, 236, 249, 135, 64, 135, 12, 117, 4, 89, 149, 168, 209],
    [246, 204, 26, 232, 232, 70, 129, 109, 223, 146, 169, 242, 23, 241, 105, 145, 50, 196, 165, 42, 254, 120, 3, 54, 244, 207, 209, 85, 53, 6, 138, 106, 175, 148, 31, 204, 186, 186, 165, 182, 87, 142, 49, 10, 39, 110, 26, 154, 86, 56, 173, 125, 18, 64, 198, 225, 99, 99, 83, 82, 191, 134, 76, 170],
  ),
}

// clientDecode undoes the client's codec: a 6-byte header naming the salt,
// 32 random bytes, then AES-128-CBC under sha512(sha512(random) + salt);
// the plaintext is led by its own sha512, which is checked
function clientDecode(b64) {
  const buf = Buffer.from(b64, "base64")
  const salt = CODEC[buf.subarray(0, 6).toString("hex")]
  if (!salt || buf.length <= 102) throw new Error("not the client's codec")
  const key = createHash("sha512").update(Buffer.concat([createHash("sha512").update(buf.subarray(6, 38)).digest(), salt])).digest()
  const d = createDecipheriv("aes-128-cbc", key.subarray(0, 16), key.subarray(16, 32))
  const out = Buffer.concat([d.update(buf.subarray(38)), d.final()])
  const body = out.subarray(64)
  if (out.length < 64 || !createHash("sha512").update(body).digest().equals(out.subarray(0, 64))) throw new Error("the client's value doesn't check")
  return body.toString("utf8")
}

// thisMachine is how the client names this machine's OS: its type, and
// the OS's own version (Windows' product name, as "Windows 11 Home China"
// was seen, else its build; elsewhere the kernel's release)
function thisMachine(platform = process.platform) {
  if (platform === "win32") {
    let v = ""
    try {
      v = osVersion()
    } catch {}
    return { type: "windows", os: /^Windows \d/.test(v) ? v : `Windows ${release()}` }
  }
  return { type: platform === "darwin" ? "mac" : platform, os: `${platform === "darwin" ? "macOS" : platform} ${release()}` }
}

// ugPage: url is one of Trae's growth pages (the check-in)
const ugPage = (url) => {
  try {
    return new URL(url).pathname.startsWith("/trae/api/v2/ug/")
  } catch {
    return false
  }
}

// A model that writes a tool call as text still writes it, mostly GLM and
// DeepSeek: the blocks are read as the calls they mean (the tools also go
// natively in the body, and a past call is a native turn, so an answer is
// usually native; the text form is read for when it is not).
const OPEN = "<tool_call>"
const CLOSE = "</tool_call>"


const partText = (content) => {
  if (typeof content === "string") return content
  if (!Array.isArray(content)) return content == null ? "" : String(content)
  return content
    .map((p) => (typeof p === "string" ? p : p?.type === "text" || p?.type === "input_text" ? p.text ?? "" : p?.type === "image_url" ? "[an image, which this model can't see]" : ""))
    .filter(Boolean)
    .join("\n")
}

// imageOf is an image part of a message as Trae's chat takes one: OpenAI's
// image_url part, {url} in it, which is what TRAE's ai-agent sends
// (LLMRawMultiContent's image_url, LLMRawChatImageURL) and what the
// open-source relays pass llm_utils_chat unchanged. null for a part that
// isn't an image, or one with no url.
function imageOf(p) {
  if (p?.type !== "image_url" && p?.type !== "input_image") return null
  const url = typeof p.image_url === "string" ? p.image_url : p.image_url?.url ?? p.url
  return typeof url === "string" && url ? { type: "image_url", image_url: { url } } : null
}

// partsOf is a message's text and, for a model that sees, its images apart
// from it; a model that doesn't is told in the text that one was there
const partsOf = (content, sees) => {
  if (!sees || !Array.isArray(content)) return { text: partText(content), images: [] }
  const images = content.map(imageOf).filter(Boolean)
  return { text: partText(content.filter((p) => !imageOf(p))), images }
}

// traeMessages is the conversation as Trae's chat takes it. sees is whether
// the model takes images: Trae's list says so of each model (multimodal),
// and a model it says doesn't is sent the placeholder, not the image.
function traeMessages(req, sees = false) {
  // native is whether the body names the tools to Trae (chatBody's own
  // test). Past calls go back as Trae's own turns only then: every live
  // run of that shape carried the tools, and a request without them (a
  // summary, tool_choice "none") keeps the text form it always had
  const native = Array.isArray(req.tools) && req.tools.length > 0 && req.tool_choice !== "none"
  const names = new Map()
  const out = []
  // dropped is every call id a turn carried but Trae cannot be sent: an
  // assistant turn whose calls all lost their name takes its results with it
  const dropped = new Set()
  // images of tool results, held until the run of results ends: Trae
  // takes no message between a call's results, so they cannot go after
  // each one — one user message once they are all in
  const pending = []
  const flushImages = () => {
    if (pending.length) out.push({ role: "user", images: pending.splice(0) })
  }
  for (const m of req.messages ?? []) {
    const role = m.role === "developer" ? "system" : m.role
    let { text, images } = partsOf(m.content, sees)
    if (!native && role === "assistant" && Array.isArray(m.tool_calls) && m.tool_calls.length) {
      const calls = m.tool_calls.map((c) => {
        names.set(String(c.id ?? ""), c.function?.name)
        let args = c.function?.arguments ?? "{}"
        try {
          args = JSON.parse(args)
        } catch {}
        return OPEN + JSON.stringify({ name: c.function?.name, arguments: args }) + CLOSE
      })
      out.push({ role: "assistant", text: [text, ...calls].filter(Boolean).join("\n") })
      continue
    }
    if (role === "assistant" && Array.isArray(m.tool_calls) && m.tool_calls.length) {
      // a past call goes back as the turn Trae made it: an assistant
      // tool_calls message, its result in the tool message after it. Trae
      // answers such a history with native calls; written out as a
      // <tool_call> block in the text it answers in blocks too, and a block
      // the stream cuts short ends the turn as an error (plugins#38).
      const calls = []
      for (const c of m.tool_calls) {
        const name = String(c.function?.name ?? c.name ?? "").trim()
        // a call Trae cannot be sent is dropped here; its result goes too
        // (an empty tool_calls list and a result naming no call are not a
        // turn Trae takes)
        if (!name) {
          if (c.id != null) dropped.add(String(c.id))
          continue
        }
        names.set(String(c.id ?? ""), name)
        let args = c.function?.arguments ?? c.arguments ?? "{}"
        if (typeof args !== "string") {
          try {
            args = JSON.stringify(args)
          } catch {
            args = "{}"
          }
        }
        calls.push({ id: String(c.id ?? "call_" + (names.size + 1)), type: "function", function_call: { name, arguments: args } })
      }
      if (calls.length) out.push({ role: "assistant", text, images, calls })
      else if (text || images.length) out.push({ role: "assistant", text, images })
      continue
    }
    if (role === "assistant") {
      flushImages()
      out.push({ role: "assistant", text, images })
    } else if (role === "tool") {
      const id = String(m.tool_call_id ?? "")
      if (dropped.has(id)) continue
      // a result answering no call this history sends (the text form, or
      // a call cut away before it) is no turn Trae takes: it goes as text
      if (!native || !names.has(id)) {
        flushImages()
        out.push({ role: "user", text: `Result of ${names.get(id) || m.name || "the tool"} (call ${m.tool_call_id ?? "?"}):\n${text}`, images })
        continue
      }
      // Trae's own result turn: the call it answers, its text as parts
      // (an empty one for a result with no text). Its images wait: a
      // tool turn's image_url reaches some models (Kimi) and not others
      // (Doubao-Seed), so they go in a user message after the whole run
      // of results, which every multimodal model reads
      if (images.length) pending.push(...images)
      // Trae refuses a result with no text (4027: the calls turn reads as
      // unanswered), so one that printed nothing says so (plugins#251)
      out.push({ role: "tool", tool_call_id: id, text: text || (images.length ? "(the result's image follows)" : "(no output)") })
    } else {
      flushImages()
      out.push({ role: role === "system" ? "system" : "user", text, images })
    }
  }
  flushImages()
  // Trae takes no two messages of one role in a row, so an assistant turn is
  // folded into the turn after it: text into the calls turn it introduces
  // (agents send "let me read" and then the call, and parallel calls split
  // over two assistant turns), calls joined into one list. A message of an
  // image alone is not empty; tool results are turns of their own, each
  // answering its own call.
  const merged = []
  for (const m of out) {
    const images = m.images ?? []
    if (m.role === "tool") {
      merged.push(m)
      continue
    }
    if (m.role === "assistant") {
      const last = merged.at(-1)
      if (last && last.role === "assistant") {
        // fold: text and images join, calls append to the same list
        last.text = [last.text, m.text].filter(Boolean).join("\n\n")
        last.images = [...(last.images ?? []), ...images]
        if (m.calls) last.calls = [...(last.calls ?? []), ...m.calls]
        if (!last.text && !last.images.length && !last.calls) merged.pop()
        continue
      }
      if (!m.text && !images.length && !m.calls) continue
      merged.push({ role: "assistant", text: m.text, images, ...(m.calls ? { calls: m.calls } : {}) })
      continue
    }
    if (!m.text && !images.length) continue
    const last = merged.at(-1)
    if (last && last.role === m.role && m.role !== "system") {
      last.text = [last.text, m.text].filter(Boolean).join("\n\n")
      last.images = [...(last.images ?? []), ...images]
    } else merged.push({ role: m.role, text: m.text, images })
  }
  return merged.map((m) => {
    const content = [...(m.text ? [{ type: "text", text: m.text }] : []), ...(m.images ?? [])]
    if (m.calls) return { role: "assistant", content: content.length ? content : null, tool_calls: m.calls }
    if (m.role === "tool") return { role: "tool", tool_call_id: m.tool_call_id, content } // results of one turn stay consecutive: nothing may go between them (11148)
    return { role: m.role, content }
  })
}

// Moonshot (Kimi) validates tools against its own "moonshot flavored json
// schema" and refuses the whole request (Trae answers code 4027, "tool call
// failed: Invalid request: tools.function.parameters is not a valid moonshot
// flavored json schema, details: <At path 'properties.ops.items.properties.op':
// type is not defined>") for shapes a JSON Schema allows and agents send: an
// enum or const with no type (Claude Code's tools carry them), a $ref beside a
// type, a type beside an anyOf. Trae passes the tools to Kimi as they are, so
// they are rewritten here for the rules Kimi has been seen to hold, for a
// Kimi/Moonshot model only (moonshotModel). This is kimi-work's moonshotSchema,
// which carries the reasons for each rule, ported. The tools sent are
// a copy: the request's own stay as they were, and a schema Kimi takes as it is
// goes byte for byte.
const jsIsObj=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const msMAP_KEYS=['properties','$defs','definitions','dependentSchemas','patternProperties'];
const msSUB_KEYS=['items','additionalProperties','contains','propertyNames','not','if','then','else','allOf','anyOf','oneOf','prefixItems','unevaluatedProperties','unevaluatedItems','contentSchema'];
const msALL_TYPES=['string','number','integer','boolean','object','array','null'];

function msEachSchema(node,f) {
  if(Array.isArray(node)) {for(const v of node)msEachSchema(v,f);return;}
  if(!jsIsObj(node))return;
  f(node);
  for(const k of msMAP_KEYS) if(jsIsObj(node[k])) for(const v of Object.values(node[k])) msEachSchema(v,f);
  for(const k of msSUB_KEYS) if(k in node) msEachSchema(node[k],f);
}

function msRefTarget(root,ref) {
  if(typeof ref!=='string'||(ref!=='#'&&!ref.startsWith('#/')))return undefined;
  let cur=root;
  for(let tok of ref.split('/').slice(1)) {
    tok=tok.replace(/~1/g,'/').replace(/~0/g,'~');
    try{tok=decodeURIComponent(tok);}catch{}
    if(!jsIsObj(cur)&&!Array.isArray(cur))return undefined;
    if(!Object.hasOwn(cur,tok))return undefined;
    cur=cur[tok];
  }
  return cur;
}

const msHasRefInside=s=>JSON.stringify(s).includes('"$ref"');

function msValueType(v) {
  if(v===null)return 'null';
  switch(typeof v){
    case 'string':return 'string';
    case 'boolean':return 'boolean';
    case 'number':return Number.isInteger(v)?'integer':'number';
  }
  return Array.isArray(v)?'array':'object';
}

// the type an enum of vals is given: the one all non-null values have, with
// "null" when a null is among them; undefined when there are none or they
// are of more than one kind
function msEnumType(vals) {
  let t,nul=false;
  for(const v of vals) {
    const vt=msValueType(v);
    if(vt==='null'){nul=true;continue;}
    if(vt==='array'||vt==='object')return undefined;
    if(t===undefined||t===vt)t=vt;
    else if((t==='integer'&&vt==='number')||(t==='number'&&vt==='integer'))t='number';
    else return undefined;
  }
  if(t===undefined)return undefined;
  return nul?[t,'null']:t;
}

// the types s can have, as its type, keywords, values or branches say;
// undefined when they don't say
function msSchemaTypes(root,s,depth=0) {
  if(depth>16||!jsIsObj(s))return undefined;
  if('type' in s)return new Set([].concat(s.type).map(String));
  if('$ref' in s){const t=msRefTarget(root,s.$ref);return t===undefined?undefined:msSchemaTypes(root,t,depth+1);}
  if(Array.isArray(s.enum)||'const' in s)return new Set(('const' in s?[s.const]:s.enum).map(msValueType));
  for(const k of ['oneOf','anyOf','allOf']) {
    if(!Array.isArray(s[k]))continue;
    const ts=new Set();
    for(const b of s[k]) {
      const bt=msSchemaTypes(root,b,depth+1);
      if(!bt){if(k!=='allOf')return undefined;continue;}
      for(const t of bt)ts.add(t);
    }
    if(ts.size)return ts;
  }
  const has=(...ks)=>ks.some(k=>k in s);
  if(has('properties','required','additionalProperties','patternProperties','minProperties','maxProperties','propertyNames','dependentRequired','dependentSchemas','unevaluatedProperties'))return new Set(['object']);
  if(has('items','prefixItems','minItems','maxItems','uniqueItems','contains','unevaluatedItems'))return new Set(['array']);
  if(has('minLength','maxLength','pattern','format','contentEncoding','contentMediaType'))return new Set(['string']);
  if(has('minimum','maximum','exclusiveMinimum','exclusiveMaximum','multipleOf'))return new Set(['number']);
  return undefined;
}

function msTypeFor(root,s) {
  if(Array.isArray(s.enum))return msEnumType(s.enum);
  if('const' in s)return msEnumType([s.const]);
  const ts=msSchemaTypes(root,s);
  if(!ts||!ts.size)return [...msALL_TYPES];
  if(ts.has('integer')&&ts.has('number'))ts.delete('integer');
  const names=msALL_TYPES.filter(t=>ts.has(t));
  return names.length===1?names[0]:names;
}

// the same object with type written first, as an agent would have
const msWithType=(s,type)=>{const rest={...s};delete rest.type;for(const k of Object.keys(s))delete s[k];Object.assign(s,{type},rest);};

function moonshotSchema(root) {
  let changed=false;
  // a $ref beside a type, and a type beside an anyOf
  msEachSchema(root,s=>{
    if('$ref' in s&&'type' in s) {
      const t=msRefTarget(root,s.$ref);
      if(jsIsObj(t)&&!msHasRefInside(t)) {
        const own={...s};delete own.$ref;
        for(const k of Object.keys(s))delete s[k];
        Object.assign(s,structuredClone(t),own);
      } else delete s.type;
      changed=true;
    }
    if(Array.isArray(s.anyOf)&&'type' in s){delete s.type;changed=true;}
  });
  // an enum or const with no type
  msEachSchema(root,s=>{
    if('type' in s||!(Array.isArray(s.enum)||'const' in s))return;
    const t=msEnumType(Array.isArray(s.enum)?s.enum:[s.const]);
    if(t!==undefined){msWithType(s,t);changed=true;}
  });
  // a $ref's target with no type
  msEachSchema(root,s=>{
    if(typeof s.$ref!=='string')return;
    const t=msRefTarget(root,s.$ref);
    if(!jsIsObj(t)||'type' in t||'anyOf' in t||'$ref' in t||!Object.keys(t).length)return;
    const typ=msTypeFor(root,t);
    if(typ!==undefined){msWithType(t,typ);changed=true;}
  });
  return changed;
}


const moonshotModel = (...names) => names.some((n) => /kimi|moonshot/i.test(String(n ?? "")))

// nativeTools are the tools as Trae names them: parameters a JSON string.
// moonshot is whether a Kimi model takes them (moonshotSchema)
const nativeTools = (tools, moonshot = false) =>
  tools.map((t) => {
    const f = t.function ?? t
    let p = f.parameters
    if (moonshot && jsIsObj(p)) {
      p = structuredClone(p)
      moonshotSchema(p)
    }
    return { type: "function", function: { name: f.name, description: f.description ?? "", parameters: typeof p === "string" ? p : JSON.stringify(p ?? {}) } }
  })

// SESSION carries the conversation magpie (or OpenCode) names a request by,
// from the chat.headers hook to the loader's fetch. It goes no further.
const SESSION = "x-magpie-trae-session"

// saltOf is what the id is derived with, so it says nothing to Trae of the
// words it was made from. It is this machine's own, kept in a file of the
// plugin's (saltFile) and made once, so a conversation keeps its session_id
// when the plugin's process starts again: magpie restarts its plugins on an
// update of magpie or of any plugin, and a salt new in each process gave
// every conversation going on then a session of its new own — Trae counting
// it as a conversation started anew, with nothing of the one before (baoguo
// on magpie's Discord). The file is made under another name and linked into
// place, so two processes starting at once both read the one that won, never
// a half-written one. A file that can't be read or made, or holds anything
// but a salt, is left as it is, and the process uses a salt of its own, as
// every process did before.
const saltFile = () => process.env.MAGPIE_TRAE_SESSION_SALT || join(homedir(), ".config", "magpie", "trae-session-salt")
const SALT_SHAPE = /^[0-9a-f]{32}$/
let salt = ""
function saltOf() {
  if (salt) return salt
  const file = saltFile()
  const read = () => {
    try {
      const s = readFileSync(file, "utf8").trim()
      return SALT_SHAPE.test(s) ? s : null
    } catch (e) {
      return e?.code === "ENOENT" ? "" : null
    }
  }
  let s = read()
  if (s === "") {
    const tmp = `${file}.${process.pid}.${randomBytes(4).toString("hex")}.tmp`
    try {
      mkdirSync(dirname(file), { recursive: true })
      writeFileSync(tmp, randomBytes(16).toString("hex") + "\n", { mode: 0o600 })
      try {
        linkSync(tmp, file)
      } catch (e) {
        if (e?.code !== "EEXIST") throw e
      }
      s = read()
    } catch {
      s = null
    } finally {
      try {
        unlinkSync(tmp)
      } catch {}
    }
  }
  salt = s || randomBytes(16).toString("hex")
  return salt
}

// conversationID is the conversation a chat belongs to, as the UUID the
// request's session_id wants: the session magpie or OpenCode names (its
// chat.headers hook), else the chat's first user message, which every later
// turn of the conversation repeats. "" when neither names one — a body that
// isn't a chat, or one with no user message in it — and the caller then makes
// a fresh id per request, as before: a made-up conversation of the request's
// own is the very splitting this is here to end.
//
// who is the account the request is made as (its uid, else its name), and it
// is part of what the id is made of, so one conversation answered by two
// accounts (magpie failing over, or rotating, inside it) is two conversations
// as Trae is concerned — an id a fresh random one never linked, and one that
// would let Trae read one conversation as another's. The cost is that such a
// conversation's two halves are counted apart again, which is what it did
// before this named one at all.
function conversationID(chat, session, who = "") {
  const account = String(who ?? "").trim()
  if (session) return uuidOf("magpie-trae-session|" + account + "|" + session)
  const first = (Array.isArray(chat?.messages) ? chat.messages : []).find((m) => m?.role === "user")
  const text = partText(first?.content ?? "")
  return text.trim() ? uuidOf("magpie-trae-first|" + account + "|" + text) : ""
}

// uuidOf is a version 4 UUID made of a hash's first 16 bytes: the shape
// randomUUID() returns, since that is what session_id carried before.
function uuidOf(s) {
  const b = Buffer.from(createHash("sha256").update(saltOf() + "|" + s).digest().subarray(0, 16))
  b[6] = (b[6] & 0x0f) | 0x40
  b[8] = (b[8] & 0x3f) | 0x80
  const h = b.toString("hex")
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`
}

// sessionOf takes the session a chat.headers hook named off the headers, with
// the header: it goes no further than here. Its length is capped as magpie's
// own session ids are, the id being derived from it anyway.
function sessionOf(headers) {
  const s = String(headers.get(SESSION) ?? "").trim()
  headers.delete(SESSION)
  return s.slice(0, 128)
}

// chatBody is the request for llm_utils_chat; modelName is the model the
// function's list names for the config (its __dev one), when it named one,
// and most the max_tokens it gives that model (0: none given), which a
// request asking more is held to. A Max model (max: {base, window}) asks
// the config base by its __max model, max_tokens always set, and gives
// the prompt the room the window has beside it, as the IDE's Max mode does.
//
// session is the conversation's id, made by conversationID, so every request
// of one conversation carries one: Trae counts a conversation by the session
// the requests name, and a request naming a new session each time is counted
// as a conversation of its own — one user send that takes several steps (a
// tool result sent back, a retry, another function answering) shows up in the
// usage detail as several, each under no title at all. request_id stays a
// fresh id per request, being that request's own.
//
// levels is the model's own levels (levelsOf of its entry): the effort the
// request asks for is sent as the Trae name that model takes, and left out
// when it takes none of that name — Trae rejects a level a model has no entry
// for, and serves its default when none is asked.
function chatBody(req, fn, modelName, most = 0, max = null, session = "", sees = false, levels = null, entry = null) {
  // an enterprise model is asked by its own config_name, as Trae's client
  // asks it: the id it is listed under can be its twin id (twinId), which
  // Trae doesn't know
  const config = enterpriseModel(entry) && entry.config_name != null ? String(entry.config_name) : max?.base ?? req.model
  const body = {
    messages: traeMessages(req, sees),
    function: fn,
    config_name: config,
    model: config,
    ...(modelName ? { model_name: modelName } : {}),
    stream: true, // Trae answers in SSE either way
    request_id: randomUUID(),
    // session_id is the conversation's, as the IDE keeps one per conversation
    // (plugins#58): Trae counts a conversation by the session its requests
    // name, and one user send that takes several steps (a tool result sent
    // back, a retry, another function answering) is one conversation, not
    // several. It is also the session the commercial record of a turn is
    // booked under, which is why that record is read as a conversation's and
    // each turn takes its share of it (turnBilling).
    session_id: session || randomUUID(),
  }
  const effort = effortOf(levels, req.reasoning_effort ?? req.reasoningEffort)
  if (effort) body.reasoning_effort = effort
  // the reply limit is always sent when the list gives the model one, as
  // Trae's own client does: its agent's ModelConfig carries the detail's
  // max_tokens with every model (ai-agent, "[ModelConfig] Received
  // config_name=, model_name=, …, max_tokens="). Asked with none, an
  // enterprise seat's every reply stopped at exactly 2000 output tokens,
  // where the same model in Trae wrote more (@liuyuexue2020 on X,
  // AI/deekseek-v4.1-flash, 0.2.43), most likely the limit Trae gives a
  // request naming none (no seat to measure it on). An enterprise
  // model has no __dev detail for most to come from, so its own detail's
  // max_tokens is the one.
  if (!(most > 0) && enterpriseModel(entry)) most = Number(enterpriseDetail(entry)?.max_tokens) || 0
  const asked = req.max_completion_tokens ?? req.max_tokens
  if (Number.isFinite(asked) && asked > 0) body.max_tokens = most > 0 ? Math.min(Math.floor(asked), most) : Math.floor(asked)
  else if (most > 0) body.max_tokens = most
  if (max?.window) {
    body.user_message_context = { model_info: { prompt_max_tokens: max.window - (body.max_tokens || 0) } }
  }
  // an enterprise's built-in model says where its config comes from beside
  // config_name, at the top of the body: Trae CN 3.4.20's own llm_utils_chat
  // request (libharness, worktree/branch_name.rs, asked with the user's
  // selected model) is usage, function, messages, conversation_id,
  // access_type, config_name, model_name, config_source, is_custom_model,
  // provider. Without them Trae looks the config up among its own presets
  // and answers 4001 "the param is invalid" on every function (#1258, an
  // enterprise seat on console.enterprise.trae.cn, 0.2.41, which sent them
  // under user_message_context.model_info, the agent task's shape). Not yet
  // seen answering from a real enterprise seat: a Trae preset is sent as
  // before.
  //
  // model_name and provider are the entry's model detail's: Trae's list
  // types (libharness CloudModelConfigInfo / CloudModelDetailInfo) carry
  // provider on each model_detail_list item, beside its model_name, and
  // not on the config, and an enterprise model's detail has no __dev name
  // for modelName to come from. 0.2.42 read provider off the config and
  // sent no model_name, so both were missing, and the reporter's seat got
  // 4023 "We're sorry, something went wrong" on every function (#1258,
  // AI/deekseek-v4.1-flash and volc/deepseek-v4-1-flash).
  if (enterpriseModel(entry)) {
    body.config_source = ENTERPRISE
    body.is_custom_model = true
    const detail = enterpriseDetail(entry)
    if (!body.model_name && detail?.model_name) body.model_name = String(detail.model_name)
    const provider = entry.provider || detail?.provider
    if (provider) body.provider = String(provider)
    // the reply limit again, where Trae's own client puts it for an
    // enterprise model: its agent task (libharness 3.4.22, AgentSpec and
    // CreateTaskRequest) carries enterprise_custom_hyper_params
    // {max_tokens, prompt_max_tokens, multimodal} beside config_source and
    // is_custom_model, and no top-level max_tokens. 0.2.44 sent the top-level
    // one only, and the reporter's seat still stopped at exactly 2000 with
    // max_tokens 4096 asked, on four models (@liuyuexue2020 on X). Inferred
    // from the binary, not measured: no enterprise seat to try it on.
    if (body.max_tokens > 0) {
      const hyper = { max_tokens: body.max_tokens }
      const prompt = Number(detail?.prompt_max_tokens) || 0
      if (prompt > 0) hyper.prompt_max_tokens = prompt
      const sees = seesOf(entry)
      if (sees !== null) hyper.multimodal = sees
      body.enterprise_custom_hyper_params = hyper
    }
  }
  if (typeof req.temperature === "number") body.temperature = req.temperature
  if (Array.isArray(req.tools) && req.tools.length && req.tool_choice !== "none") {
    body.tools = nativeTools(req.tools, moonshotModel(config, modelName, req.model))
    const c = req.tool_choice
    if (c && typeof c === "object") body.tool_choice = c.function?.name || c.name || "auto"
    else if (typeof c === "string") body.tool_choice = c
    if (typeof req.parallel_tool_calls === "boolean") body.parallel_tool_calls = req.parallel_tool_calls
  }
  return body
}

// ---- an enterprise model's own endpoint ------------------------------------
//
// directOf is where Trae's own client sends an enterprise model's chat, when
// the model's detail says: an enterprise custom model whose provider is
// custom_openai_compatible carries custom_config {base_url, ak, auth_type,
// status, client_connect, custom_model_id, is_custom_base_url}, and Trae CN
// 3.4.22 POSTs the chat straight to base_url (an OpenAI chat/completions
// URL) with Authorization "Bearer <ak>" (auth_type 0), X-Model-Provider
// the detail's provider, User-Agent hertz, the detail's model_name as model
// and its max_tokens (plugins#1366, the reporter's captures of 2026-11-24:
// tokenerpgw.asiainfo.com/erp/v1/chat/completions, max_tokens 32768, 8274
// and 12182 completion tokens, finish_reason stop). llm_utils_chat cuts the
// same model at 2000 a round (TRAE_CUT). null for anything else — another
// auth_type, a model switched off, a field missing, a URL that isn't a chat
// completions one — which goes through llm_utils_chat as before.
const DIRECT_PROVIDER = "custom_openai_compatible"
function directOf(entry) {
  if (!enterpriseModel(entry)) return null
  const d = enterpriseDetail(entry)
  const c = d?.custom_config
  if (!c || typeof c !== "object" || c.status !== true) return null
  if (c.auth_type !== 0 && c.auth_type !== "0") return null
  const provider = String(d.provider || entry.provider || "")
  if (provider !== DIRECT_PROVIDER || !d.model_name) return null
  const ak = typeof c.ak === "string" ? c.ak.trim() : ""
  if (!ak) return null
  let url
  try {
    url = new URL(String(c.base_url ?? "").trim())
  } catch {
    return null
  }
  if (!/^https?:$/.test(url.protocol) || !/\/chat\/completions\/?$/.test(url.pathname)) return null
  return { url: url.href, ak, provider, model: String(d.model_name), most: Number(d.max_tokens) || 0 }
}

// akKey names an ak without keeping it: the one its endpoint turned away
const akKey = (ak) => createHash("sha256").update(ak).digest("hex").slice(0, 16)

// directBody is the request for an enterprise model's own endpoint: the
// caller's OpenAI chat as it came, under the detail's model name, its
// max_tokens held to the detail's as llm_utils_chat's is, always streamed
// with the usage (as Trae's client asks it; a caller that didn't ask a
// stream gets the reply whole from openai)
const DIRECT_PASSED = ["temperature", "top_p", "stop", "presence_penalty", "frequency_penalty", "seed", "response_format"]
function directBody(req, dir) {
  const body = { model: dir.model }
  const asked = req.max_completion_tokens ?? req.max_tokens
  if (Number.isFinite(asked) && asked > 0) body.max_tokens = dir.most > 0 ? Math.min(Math.floor(asked), dir.most) : Math.floor(asked)
  else if (dir.most > 0) body.max_tokens = dir.most
  body.stream = true
  if (Array.isArray(req.tools) && req.tools.length) {
    body.tools = req.tools
    if (req.tool_choice !== undefined) body.tool_choice = req.tool_choice
    if (typeof req.parallel_tool_calls === "boolean") body.parallel_tool_calls = req.parallel_tool_calls
  }
  body.stream_options = { include_usage: true }
  for (const k of DIRECT_PASSED) if (req[k] !== undefined && req[k] !== null) body[k] = req[k]
  body.messages = req.messages
  return body
}

// directHeaders are Trae's client's for the endpoint (the reporter's
// capture): the X-AhaNet-* / x-bridge-transport / x-rust-request-timeout
// ones it also carried are its own network layer's, not the endpoint's
const directHeaders = (dir, rid) => ({
  "Content-Type": "application/json",
  "User-Agent": "hertz",
  "X-Model-Provider": dir.provider,
  "x-request-id": "req_" + rid,
  Authorization: "Bearer " + dir.ak,
})

// directParts turns an OpenAI chat completion's chunks (or one whole
// completion) into the answer's parts: text, reasoning (reasoning_content,
// or vLLM's reasoning, as the reporter's endpoint sends it), the tool calls
// gathered by index and sent whole at the end, the usage and the finish
async function* directParts(events) {
  const calls = new Map()
  let lastKey = null
  let finish = ""
  for await (const { data } of events) {
    if (data === "[DONE]") break
    if (!data || typeof data !== "object") continue
    if (data.error) {
      const e = errorOf(data)
      yield { error: e.message || "the endpoint returned an error", code: e.code || null }
      return
    }
    for (const ch of Array.isArray(data.choices) ? data.choices : []) {
      const d = (ch?.delta && typeof ch.delta === "object" ? ch.delta : ch?.message) ?? {}
      const r = [d.reasoning_content, d.reasoning].find((v) => typeof v === "string" && v)
      if (r) yield { reasoning: r }
      if (typeof d.content === "string" && d.content) yield { text: d.content }
      for (const tc of Array.isArray(d.tool_calls) ? d.tool_calls : []) {
        const key = Number.isInteger(tc?.index) ? tc.index : tc?.id && ![...calls.values()].some((c) => c.id === tc.id) ? `id:${tc.id}` : lastKey ?? 0
        lastKey = key
        const c = calls.get(key) ?? { id: "", name: "", arguments: "" }
        if (tc?.id) c.id = String(tc.id)
        if (tc?.function?.name && !c.name) c.name = String(tc.function.name)
        const a = tc?.function?.arguments
        if (typeof a === "string") c.arguments += a
        else if (a && typeof a === "object") c.arguments += JSON.stringify(a)
        calls.set(key, c)
      }
      finish = finishOf(ch) || finish
    }
    const u = tokensOf(data.usage)
    if (u) yield { usage: u }
  }
  for (const c of calls.values()) yield { call: { id: c.id || callId(), name: c.name, arguments: c.arguments || "{}" } }
  if (finish) yield { finish }
}

// directRefused is, per model, the ak its endpoint turned away (401, 403),
// by akKey: the endpoint isn't asked again until the list gives another
const directRefused = new Map()

// askDirect asks an enterprise model's own endpoint (directOf) and is its
// answer as an OpenAI chat completion, or null when the endpoint didn't
// answer one (not reached, an error status, not a stream or a completion,
// an error before anything was written): the request then goes through
// llm_utils_chat as before. The ak is never written: the debug line says
// how long it is.
async function askDirect(req, dir, base, ac, site) {
  const sent = directBody(req, dir)
  const rid = randomUUID()
  const dbg = traeDebug()
  if (dbg) console.error(`trae debug: request ${rid} POST ${dir.url} direct ak_chars=${dir.ak.length} ${JSON.stringify(debugBody(sent))}`)
  let res
  try {
    res = await fetch(dir.url, { method: "POST", headers: directHeaders(dir, rid), body: JSON.stringify(sent), signal: ac.signal })
  } catch (e) {
    if (ac.signal.aborted) throw e
    if (dbg) console.error(`trae debug: request ${rid} not answered (${e?.name ?? "error"}); asking llm_utils_chat`)
    return null
  }
  const type = res.headers.get("content-type") ?? ""
  if (dbg) console.error(`trae debug: request ${rid} answered ${res.status} ${type}`)
  if (!res.ok || !res.body) {
    if (res.status === 401 || res.status === 403) directRefused.set(base, akKey(dir.ak))
    await res.body?.cancel().catch(() => {})
    return null
  }
  let events
  if (/event-stream/i.test(type)) events = sse(res.body)
  else if (/json/i.test(type)) {
    const whole = parseJSON(await res.text())
    events = (async function* () {
      yield { data: whole }
    })()
  } else {
    await res.body.cancel().catch(() => {})
    return null
  }
  const it = directParts(events)
  const got = await first(it)
  if (got.held.some((p) => p.error) || (got.done && !got.held.length)) {
    if (dbg) console.error(`trae debug: request ${rid} answered no reply; asking llm_utils_chat`)
    await it.return?.().catch(() => {})
    return null
  }
  let parts = chain(got.held, it)
  if (dbg) parts = debugEnd(rid, parts, sent.max_tokens || 0, 0)
  return openai(req, parts, () => ac.abort(), site, sent.max_tokens || 0, 0)
}

// MAGPIE_TRAE_DEBUG=1 in magpie's environment writes each chat request the
// plugin sends and how Trae's answer ended to stderr, which magpie keeps in
// app.log (plugins#1366: a seat's replies stopped at 2000 output tokens,
// and the reporter could see only TLS to Trae). Read on every request, so
// it is on for the next one after a restart and off by default. What goes
// out is the URL and the body with nothing of the user's in it: each
// message is its role and its length, each tool its name. The headers,
// which carry the sign-in, are never written.
const traeDebug = () => !!process.env.MAGPIE_TRAE_DEBUG && process.env.MAGPIE_TRAE_DEBUG !== "0"

function debugBody(sent) {
  const out = { ...sent }
  if (Array.isArray(sent.messages)) {
    out.messages = sent.messages.map((m) => ({ role: m?.role, chars: JSON.stringify(m?.content ?? "").length, ...(m?.tool_calls ? { tool_calls: m.tool_calls.length } : {}) }))
  }
  if (Array.isArray(sent.tools)) out.tools = sent.tools.map((t) => t?.function?.name ?? t?.name ?? "?")
  return out
}

function debugSent(url, rid, sent) {
  if (traeDebug()) console.error(`trae debug: request ${rid} POST ${url} ${JSON.stringify(debugBody(sent))}`)
}

// debugEnd passes the answer's parts on and, when the stream ends, writes
// what Trae said of it: its finish (Trae's "stop", or none, reads as ""),
// its usage, and the reply's length
async function* debugEnd(rid, parts, limit, cut) {
  let usage = null
  let finish = ""
  let text = 0
  let reasoning = 0
  const calls = []
  try {
    for await (const p of parts) {
      if (p.usage) usage = p.usage
      if (p.finish) finish = p.finish
      if (p.text) text += p.text.length
      if (p.reasoning) reasoning += p.reasoning.length
      if (p.call) calls.push(p.call)
      yield p
    }
  } finally {
    const end = ending(calls, finish, usage, limit, cut)
    console.error(`trae debug: reply ${rid} trae_finish=${JSON.stringify(finish)} usage=${JSON.stringify(usage)} text_chars=${text} reasoning_chars=${reasoning} calls=${calls.length}${end.dropped ? ` cut_calls=${end.dropped}` : ""} finish_sent=${end.finish}`)
  }
}

// sse reads Trae's events: {event, data} for each, data parsed when JSON
async function* sse(stream) {
  const reader = stream.getReader()
  const dec = new TextDecoder()
  let buf = ""
  let event = ""
  let data = []
  const flush = function* () {
    if (!data.length) return
    const raw = data.join("\n")
    data = []
    let v = raw
    try {
      v = JSON.parse(raw)
    } catch {}
    yield { event: event || (v && typeof v === "object" ? String(v.event ?? v.type ?? "") : ""), data: v }
    event = ""
  }
  try {
    for (;;) {
      const { value, done } = await reader.read()
      if (done) break
      buf += dec.decode(value, { stream: true })
      let i
      while ((i = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, i).replace(/\r$/, "")
        buf = buf.slice(i + 1)
        if (!line) {
          yield* flush()
          continue
        }
        if (line.startsWith(":")) continue
        if (line.startsWith("event:")) {
          yield* flush()
          event = line.slice(6).trim()
        } else if (line.startsWith("data:")) data.push(line.slice(5).trimStart())
      }
    }
    buf += dec.decode()
    if (buf.startsWith("data:")) data.push(buf.slice(5).trimStart())
    yield* flush()
  } finally {
    // the answer the agent goes away from (a tool call made, a request
    // aborted) closes this generator mid-read: let Trae's connection go,
    // or the read hangs on and the host the next ask reuses is one Trae
    // has dropped — a stream that runs, then dies
    reader.cancel().catch(() => {})
  }
}

// normalised event names: "TokenUsage", "token-usage" → token_usage
const eventName = (s) =>
  String(s ?? "")
    .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
    .replace(/[^A-Za-z0-9]+/g, "_")
    .toLowerCase()
    .replace(/^_|_$/g, "")

// tokensOf maps Trae's token counts to OpenAI's. Trae's token_usage event
// (TRAE SOLO CN's ai-agent, TokenUsageEvent: name, prompt_tokens,
// completion_tokens, total_tokens, reasoning_tokens,
// cache_creation_input_tokens, cache_read_input_tokens,
// prompt_tokens_total, completion_tokens_total) says what the prompt cache
// read and wrote under Anthropic's names. They go on under those names,
// which magpie reads beside prompt_tokens as it reads a relay's in front of
// Claude (whether prompt_tokens counts them too is judged there, by
// whether it is at least as big); without them every request read as no
// cache hit (01huadalang on magpie's Discord: K3, 53 calls, all 0)
//
// A count that names no cache at all — Trae's token_usage as
// {"prompt_tokens":1717,"completion_tokens":2,"total_tokens":1719}, a shape
// plugins#455 captured from Trae — says magpie_cache_unknown, as the Kiro
// plugin does: Trae didn't say what its cache read, so magpie shows no hit
// rate rather than a 0% Trae never gave. Before, it and a count of 0 both
// went on with no cache field, which magpie can only read as a miss, so
// since 10-28 every chat showed 0 (yetone/magpie#3979, #3991; plugins#434
// says Trae stopped sending cache_read_input_tokens then). A count naming
// the cache with nothing read and nothing written is unknown too: Trae
// answers 0 and 0 while it bills the turn at its cache price (a real
// Trae CN account on 10-29, deepseek-v4.1-flash, a 146k prompt: 5.84
// credits cold, 0.12 warm, cache_read 0 on both; dingminhua/dsh-connect-
// trae's docs/ISSUE69_DIAGNOSIS.md), so a 0 says nothing of the cache
// (feng2787 on magpie's Discord: every hit 0). A nonzero read or write is
// Trae's word, as before.
// DeepSeek's prompt_cache_hit_tokens, a bare cached_tokens and the
// Responses-style input_tokens_details are read too, the largest of them,
// should Trae pass a model's own usage on.
const CACHE_NAMED = ["cache_read_input_tokens", "cacheReadInputTokens", "cache_creation_input_tokens", "cacheCreationInputTokens", "prompt_cache_hit_tokens", "cached_tokens"]
const namesCache = (u) =>
  CACHE_NAMED.some((k) => u[k] != null) || u.prompt_tokens_details?.cached_tokens != null || u.input_tokens_details?.cached_tokens != null
function tokensOf(u) {
  if (!u || typeof u !== "object") return null
  const n = (...v) => Number(v.find((x) => x != null) ?? 0) || 0
  const p = n(u.prompt_tokens, u.input_tokens, u.promptTokens, u.inputTokens)
  const c = n(u.completion_tokens, u.output_tokens, u.completionTokens, u.outputTokens)
  if (!p && !c) return null
  const out = { prompt_tokens: p, completion_tokens: c, total_tokens: n(u.total_tokens, u.totalTokens) || p + c }
  const read = Math.max(...[u.prompt_tokens_details?.cached_tokens, u.input_tokens_details?.cached_tokens, u.prompt_cache_hit_tokens, u.cached_tokens].map((x) => Number(x) || 0))
  const write = n(u.prompt_tokens_details?.cache_write_tokens)
  if (read || write) out.prompt_tokens_details = { cached_tokens: read, ...(write ? { cache_write_tokens: write } : {}) }
  else if (!namesCache(u)) out.magpie_cache_unknown = true
  else {
    const r = n(u.cache_read_input_tokens, u.cacheReadInputTokens)
    const w = n(u.cache_creation_input_tokens, u.cacheCreationInputTokens)
    if (r) out.cache_read_input_tokens = r
    if (w) out.cache_creation_input_tokens = w
    if (!r && !w) out.magpie_cache_unknown = true
  }
  const thought = n(u.reasoning_tokens, u.completion_tokens_details?.reasoning_tokens)
  if (thought) out.completion_tokens_details = { reasoning_tokens: thought }
  return out
}

// A turn's settled charge is the only place Trae names what it really spent:
// token_usage often names no cache (or a 0 read) while Trae still bills the
// turn at its cache price, and the credits the turn used are in the same
// record (credits_by_source, a string with the precision credits_float
// rounds away). The record is the conversation's, not the turn's: since
// plugins#58 the session_id a request carries is the conversation's, and
// Trae books every turn of it under that one session. So a turn's share is
// the record now, less the record this plugin last read for the same
// conversation. A turn with no baseline yet - the conversation's first one
// here, or a caller that names no conversation and so gets a session of its
// own per request - reports the record as it is when it holds only that
// turn's own prompt and reply (ownCharge), and the reading it takes is the
// baseline of the turns after it. The realm must name a billing host to be
// read at all: Trae Global's commercial host is not known, so it reads none.
const BILLING_PATH = "/api/v1/commercial/get_session_usage"
// BILLING_TIMEOUT is the longest one read may take: no answer is held by a
// connection that hangs. BILLING_WAIT is how long an answer's end waits for
// the record at all: a stream's is short, because a settled record arrives
// with the answer and a stream's end must not be held back for it; a body's
// is the longer one, since nothing closes early there. BILLING_SETTLE is how
// long a record still being written is asked again, within that wait.
const BILLING_TIMEOUT = 2000
const BILLING_WAIT = { stream: 400, body: 2500 }
const BILLING_SETTLE = [150, 300, 600]
const BILLING_KEPT = 512 // conversations whose last reading is remembered
const BILLING_CREDITS = ["credits_float", "creditsFloat", "credits_consumed", "consumed_credits", "credit_cost", "credits_cost", "amount_float", "amountFloat"]
const numOrNull = (v) => {
  const x = typeof v === "string" ? Number(v.trim()) : Number(v)
  return v != null && Number.isFinite(x) ? x : null
}

// readings is each conversation's last settled record, by account and
// session. Two accounts answering one conversation are two conversations to
// Trae (#58), so each keeps its own reading.
const readings = new Map()

// signalWithTimeout is signal, plus one abort of its own after ms.
function signalWithTimeout(signal, ms) {
  const ctl = new AbortController()
  const timer = setTimeout(() => ctl.abort(), ms)
  const onAbort = () => ctl.abort()
  if (signal) {
    if (signal.aborted) ctl.abort()
    else signal.addEventListener("abort", onAbort, { once: true })
  }
  return {
    signal: ctl.signal,
    done() {
      clearTimeout(timer)
      signal?.removeEventListener?.("abort", onAbort)
    },
  }
}

// recordOf reads the conversation's record once, within budget ms. null when
// Trae refuses it, or names nothing settled yet: an empty record is one still
// being written, not a turn that spent nothing.
async function recordOf(a, site, session, signal, budget) {
  // a realm with no billing host (Trae Global) has no settlement to read, and
  // no request is made for one
  const host = process.env.TRAE_USAGE_API_HOST || site.hosts.billing
  if (!host) return false
  const url = String(host).replace(/\/+$/, "") + BILLING_PATH
  const headers = { "content-type": "application/json", authorization: "Cloud-IDE-JWT " + a.token }
  const t = signalWithTimeout(signal, Math.max(50, Math.min(BILLING_TIMEOUT, budget)))
  try {
    const res = await fetch(url, { method: "POST", headers, body: JSON.stringify({ session_id: session }), signal: t.signal })
    // a 4xx is a record this turn will not get: asking again will not settle
    // it. A 429 or a 5xx may settle, and is asked again within the wait.
    if (!res.ok) return res.status === 429 || res.status >= 500 ? null : false
    const payload = await res.json()
    const data = payload.data && typeof payload.data === "object" ? payload.data : payload
    const code = String(data.code ?? payload.code ?? 0)
    if (code !== "0") return false // a rejected record will not settle during this turn
    const bill = data.user_usage_group_by_session ?? data.userUsageGroupBySession ?? data
    const info = bill?.extra_info ?? bill?.extraInfo ?? {}
    const bySource = bill?.credits_by_source ?? bill?.creditsBySource
    const fromSource = bySource && typeof bySource === "object" ? Object.values(bySource).map(numOrNull).filter((v) => v != null) : []
    const number = (keys) => {
      for (const k of keys) {
        const v = numOrNull(bill?.[k])
        if (v != null) return v
      }
      return null
    }
    const credits = fromSource.length ? fromSource.reduce((x, y) => x + y, 0) : number(BILLING_CREDITS)
    const cacheRead = numOrNull(info.cache_read_token ?? info.cacheReadToken)
    const input = numOrNull(info.input_token ?? info.inputToken)
    const output = numOrNull(info.output_token ?? info.outputToken)
    // an empty envelope is a record still being written: keep waiting
    if ((credits || 0) > 0 || (input || 0) > 0 || (output || 0) > 0 || (cacheRead || 0) > 0) return { credits, cacheRead, input, output }
    return null
  } catch {
    return null
  } finally {
    t.done()
  }
}

// total is what a reading comes to: its tokens, cache and charge together.
// Every one of them only grows within a conversation, so two readings of the
// same total are the same record, and one that went back is another record.
const total = (r) => (r?.input ?? 0) + (r?.output ?? 0) + (r?.cacheRead ?? 0) + (r?.credits ?? 0)

// remember keeps a reading as the conversation's baseline, keeping the map
// from growing without bound.
function remember(key, record) {
  if (!readings.has(key) && readings.size >= BILLING_KEPT) readings.delete(readings.keys().next().value)
  readings.set(key, record)
}

// ownCharge says a reading is this turn's own charge: its prompt is the one
// this turn sent, no earlier turn's added, and its reply no more than this
// one's. Trae counts a session's turns into one record, so only a record with
// just this turn's prompt in it can be reported without a baseline.
function ownCharge(record, usage) {
  const asked = Number(usage?.prompt_tokens) || 0
  const wrote = Number(usage?.completion_tokens) || 0
  if (!(asked > 0) || record.input == null) return false
  if (Math.abs(record.input - asked) > Math.max(64, asked * 0.02)) return false
  return record.output == null || record.output <= wrote + 64
}

// turnBilling is one turn's share of the conversation's record. wait bounds
// how long the answer's end waits for it, so a slow settlement costs the
// answer a bounded delay at most, never an open connection. A record that
// hasn't moved past the last reading is one still being written - Trae has the
// earlier turns in it already, and this one's charge is not there yet - so it
// is asked again within the wait, and a turn that never moved reports nothing
// rather than a false 0: its share is then taken with the next turn's, which
// is what keeps a real cache hit from reading as a 0% miss.
async function turnBilling(a, site, session, { usage = null, signal = null, wait = BILLING_WAIT.body } = {}) {
  if (!session) return null
  const key = (a.uid || a.accountId || "") + "|" + session
  const before = readings.get(key) ?? null
  const saw = before ? total(before) : null
  const deadline = Date.now() + wait
  let record = null
  for (let attempt = 0; ; attempt++) {
    record = await recordOf(a, site, session, signal, deadline - Date.now())
    if (record === false) return null // a record Trae refused: asking again will not settle it
    if (record && (saw === null || total(record) > saw)) break // this turn's charge is in it
    if (record && total(record) < saw) {
      // its books went back: another record (a new period, a reset), not
      // this turn's share. It becomes the baseline, and this turn reports
      // nothing of Trae's.
      remember(key, record)
      return null
    }
    const pause = BILLING_SETTLE[attempt]
    if (!pause || Date.now() + pause >= deadline) break
    await new Promise((r) => setTimeout(r, pause))
  }
  if (traeDebug()) console.error(`trae debug: billing ${String(session).slice(0, 8)} ${record ? `in=${record.input} out=${record.output} cache=${record.cacheRead} credits=${record.credits}` : "no settled record"}${before ? " (a baseline is held)" : ""}`)
  if (!record || (saw !== null && total(record) <= saw)) return null // never moved: keep the old baseline
  remember(key, record)
  if (!before) {
    // no baseline for this conversation: a record that holds only this turn's
    // own prompt and reply is this turn's charge - a conversation this plugin
    // has not read before, or one whose session names the turn (a caller that
    // names no conversation) - and is reported as it is. One that holds more
    // is the conversation's, and is only the baseline of the turns after it.
    return ownCharge(record, usage) ? { credits: record.credits, cacheRead: record.cacheRead } : null
  }
  const share = (now, then) => Math.max(0, (now ?? 0) - (then ?? 0))
  return { credits: share(record.credits, before.credits), cacheRead: share(record.cacheRead, before.cacheRead) }
}

let callSeq = 0
const callId = () => "call_" + randomBytes(12).toString("hex") + (callSeq++).toString(36)

// TextTools splits the model's text into what the agent sees and the tool
// calls it wrote as blocks, holding back the start of a block until it
// is whole. A block is ours (<tool_call>{…}</tool_call>), its JSON taken
// once whole even when DeepSeek closes it with its own tags in place of
// </tool_call>, or DeepSeek's (<｜DSML｜invoke name="…">, magpie#823); the
// tags left around a call are dropped.
//
// GLM writes a call as its own template has it, <tool_call>name
// <arg_key>k</arg_key><arg_value>v</arg_value></tool_call>, which is read
// too; and a {"reasoning_content": …} object in the text is the model's
// reasoning, not its answer (歧路亡羊 on magpie's Discord).
class TextTools {
  constructor(tools = []) {
    this.buf = ""
    this.after = false
    this.tools = tools
    this.sent = "" // the text given out so far, to tell a block in code from a call
    this.bad = new Set() // where the waiting block's JSON was tried and not read, not tried again
    this.mark = 0 // where in sent the text after the last call starts
  }
  push(s, end = false) {
    this.buf += s
    let text = ""
    let reasoning = ""
    const calls = []
    for (;;) {
      if (this.after) {
        const m = this.buf.match(LEFTOVER)
        if (m) this.buf = this.buf.slice(m[0].length)
        if (!this.buf || (!end && MARKS.some((k) => k.startsWith(this.buf)))) break
        // a tag cut short at the end (</), after the others: dropped too
        if (end && this.buf.length > 1 && MARKS.some((k) => k.startsWith(this.buf.trimEnd()))) {
          this.buf = ""
          break
        }
        this.after = false
      }
      const om = this.buf.match(OPEN_AT)
      const i = om ? om.index : -1
      const d = this.buf.search(DSML_AT)
      const r = this.buf.search(REASON_AT)
      const sm = this.buf.match(STRAY_AT)
      const s = sm ? sm.index : -1
      const x = this.buf.search(XML_AT)
      const j = jsonCallAt(this.buf, this.sent + text)
      if (j >= 0 && [i, d, r, x, s].every((y) => y < 0 || j < y)) {
        // OpenAI's own wire shape written as text, {"tool_calls":[{…}]} on
        // a line of its own (plugins#1114): whole and readable, its calls;
        // cut short, a failure; in code or not readable, text
        const head = this.buf.slice(0, j)
        const brace = this.buf.indexOf("{", j)
        const o = quoted(this.sent + text + head) ? -2 : objectEnd(this.buf, brace)
        if (o === -1 && !end) {
          text += head
          this.buf = this.buf.slice(j)
          break
        }
        if (o === -1) {
          this.buf = ""
          text += head
          this.sent += text
          return { text, calls, reasoning, error: CUT_SHORT }
        }
        const got = o > 0 ? jsonCalls(this.buf.slice(brace, o)) : null
        if (!got) {
          text += this.buf.slice(0, brace + 1)
          this.buf = this.buf.slice(brace + 1)
          continue
        }
        text += head
        calls.push(...got)
        this.mark = this.sent.length + text.length
        this.buf = this.buf.slice(o)
        this.after = true
        continue
      }
      if (s >= 0 && [i, d, r, x].every((y) => y < 0 || s < y)) {
        // a close with no call open, with what GLM left before it
        // (}}</tool_call>, magpie#1945): not the answer, dropped; in code,
        // shown
        const head = this.buf.slice(0, s)
        // only a tail: a close with nothing before it since the last call
        // (or the start), or with GLM's braces, quotes or > right before
        // it; a close a sentence names in passing stays
        const tail = /^[}\]"'>]/.test(sm[0]) || !(this.sent + text + head).slice(this.mark).trim()
        if (!tail || quoted(this.sent + text + head)) {
          text += this.buf.slice(0, s + sm[0].length)
          this.buf = this.buf.slice(s + sm[0].length)
          continue
        }
        text += head
        this.buf = this.buf.slice(s + sm[0].length)
        this.after = true
        continue
      }
      if (r >= 0 && (i < 0 || r < i) && (d < 0 || r < d) && (x < 0 || r < x)) {
        const o = objectEnd(this.buf, r)
        if (o === -1 && !end) {
          // not whole yet: held, the text before it sent
          text += this.buf.slice(0, r)
          this.buf = this.buf.slice(r)
          break
        }
        const v = o > 0 ? looseJSON(this.buf.slice(r, o)) : null
        if (v && typeof v.reasoning_content === "string") {
          text += this.buf.slice(0, r)
          reasoning += v.reasoning_content
          this.buf = this.buf.slice(o)
          continue
        }
        // not one after all: text, and what follows read on
        text += this.buf.slice(0, r + 1)
        this.buf = this.buf.slice(r + 1)
        continue
      }
      if (i < 0 && d < 0 && x < 0) break
      if (x >= 0 && (i < 0 || x < i) && (d < 0 || x < d)) {
        // Anthropic's <function_calls><invoke name="…"> or Qwen's
        // <function=…>, as Kimi and MiMo write a call (01huadalang on
        // magpie's Discord, dsh): a call only for a tool the request
        // declared, and never in a code fence or backticks
        const head = this.buf.slice(0, x)
        const at = this.buf.slice(x)
        const opener = at.match(/^<[^<>]*>?/)[0]
        if (quoted(this.sent + text + head)) {
          text += head + opener
          this.buf = at.slice(opener.length)
          continue
        }
        const b = this.xmlCall(at, end)
        if (b.wait) break
        if (b.text) {
          text += head + opener
          this.buf = at.slice(opener.length)
          continue
        }
        text += head
        if (b.error) {
          this.buf = ""
          this.sent += text
          return { text, calls, reasoning, error: b.error }
        }
        calls.push(b.call)
        this.mark = this.sent.length + text.length
        this.buf = b.rest
        this.after = true
        continue
      }
      if (d >= 0 && (i < 0 || d < i)) {
        text += this.buf.slice(0, d)
        this.buf = this.buf.slice(d)
        const tag = this.buf.match(DSML_TAG)
        if (!tag) {
          // a tag not closed yet; at the end, or with another tag after it,
          // a stray one dropped
          const next = this.buf.indexOf("<", 1)
          if (next < 0 && !end) break
          this.buf = next < 0 ? "" : this.buf.slice(next)
          continue
        }
        const inv = tag[0].match(DSML_INVOKE)
        if (!inv) {
          // function_calls, a parameter's close, any other tag: dropped,
          // with the blanks after it
          this.buf = this.buf.slice(tag[0].length)
          this.after = true
          continue
        }
        const body = this.buf.slice(tag[0].length)
        const c = body.match(DSML_CLOSE)
        const n = body.search(DSML_INVOKE_AT)
        let stop = c ? c.index : n >= 0 ? n : -1
        if (n >= 0 && n < stop) stop = n
        if (stop < 0) {
          if (!end) break
          stop = body.length
        }
        calls.push({ name: inv[1], arguments: dsmlArgs(body.slice(0, stop)) })
        this.mark = this.sent.length + text.length
        this.buf = body.slice(c && c.index === stop ? stop + c[0].length : stop)
        this.after = true
        continue
      }
      const head = this.buf.slice(0, i)
      const body = this.buf.slice(i + om[0].length)
      if (quoted(this.sent + text + head)) {
        // a <tool_call> in backticks or a code fence is prose about one
        text += head + om[0]
        this.buf = body
        continue
      }
      const named = om[1]?.match(/\bname\s*=\s*"([^"]+)"/)?.[1]
      const inner = body.trimStart()
      if (!named && (inner.startsWith("<") || (end && !inner))) {
        // no JSON in it: DeepSeek's own invoke, or only the closes of one
        // (magpie#823 again); the opener is dropped and what follows read
        // as it is
        text += head
        this.buf = inner
        this.after = true
        continue
      }
      const b = this.block(body, named, end)
      if (b.wait) break
      this.bad.clear()
      if (b.text) {
        // not a call: the opener is text, and what follows read on
        text += head + om[0]
        this.buf = body
        continue
      }
      text += head
      if (b.error) {
        // a call that can't be read is not the answer (plugins#38): the
        // turn ends as a failure, so the gateway can try it again
        this.buf = ""
        this.sent += text
        return { text, calls, reasoning, error: b.error }
      }
      calls.push(b.call)
      this.mark = this.sent.length + text.length
      this.buf = b.rest
      this.after = true
    }
    if (end) {
      // an opener the stream ended inside (<tool_call name): a call cut
      // short, not the answer (plugins#38)
      const h = this.buf.search(OPEN_HOLD)
      if (h >= 0 && !quoted(this.sent + text + this.buf.slice(0, h))) {
        text += this.buf.slice(0, h)
        this.buf = ""
        this.sent += text
        return { text, calls, reasoning, error: CUT_SHORT }
      }
      text += this.buf
      this.buf = ""
    } else {
      // keep back an opened block, or what may be the start of one
      const at = [this.buf.search(OPEN_AT), this.buf.search(OPEN_HOLD), this.buf.search(DSML_AT), this.buf.search(REASON_AT), this.buf.search(XML_AT), this.buf.search(XML_HOLD), jsonCallAt(this.buf, this.sent + text), jsonHoldAt(this.buf, this.sent + text)].filter((x) => x >= 0)
      let keep = at.length ? this.buf.length - Math.min(...at) : 0
      if (!keep) for (let k = Math.min(MARK_MAX - 1, this.buf.length); k > 0; k--) if (MARKS.some((m) => m.startsWith(this.buf.slice(-k)))) { keep = k; break }
      // and braces, brackets, quotes or a > a close may still come after
      const sh = this.buf.slice(0, this.buf.length - keep).match(STRAY_HOLD)
      if (sh) keep = this.buf.length - sh.index
      text += this.buf.slice(0, this.buf.length - keep)
      this.buf = this.buf.slice(this.buf.length - keep)
    }
    this.sent += text
    return { text, calls, reasoning }
  }

  // xmlCall reads a call written in Anthropic's tags (<function_calls>
  // around one or more <invoke name="…"><parameter name="k">v</parameter>
  // </invoke>) or Qwen's (<function=…><parameter=k>v</parameter>
  // </function>), s starting at its first tag: {call, rest}, {wait}
  // while it may still become one, {text} when it is no call (a tool the
  // request didn't declare, a tag named in prose), {error} for one cut
  // short. Each invoke is a call of its own; the tags between them are
  // dropped as the leftovers of one.
  xmlCall(s, end) {
    const w = s.match(/^<(?:antml:)?function_calls>/)
    if (w) {
      const rest = s.slice(w[0].length).replace(/^\s+/, "")
      if (!end && (!rest || XML_STARTS.some((k) => k.startsWith(rest)))) return { wait: true }
      return this.xmlInvoke(rest, end)
    }
    return this.xmlInvoke(s, end)
  }

  xmlInvoke(s, end) {
    let m = s.match(/^<(?:antml:)?invoke\s+name\s*=\s*"([^"<>]+)"\s*>/)
    let closeRe = /<\/(?:antml:)?invoke\s*>/
    if (!m) {
      m = s.match(/^<function=([^\s<>]+?)\s*>/)
      closeRe = /<\/function\s*>/
    }
    if (!m) {
      // an opener still being written
      if (!end && (XML_STARTS.some((k) => k.startsWith(s)) || /^<(?:antml:)?(?:invoke\s|function=)[^<>]{0,300}$/.test(s))) return { wait: true }
      return { text: true }
    }
    const declared = this.tools.map((t) => (t.function ?? t)?.name).filter(Boolean)
    const name = toolNamed(m[1].trim(), this.tools)
    if (!declared.includes(name)) return { text: true }
    const body = s.slice(m[0].length)
    const c = body.match(closeRe)
    const n = body.search(XML_NEXT)
    let stop = c ? c.index : -1
    if (n >= 0 && (stop < 0 || n < stop)) stop = n
    if (stop < 0) {
      if (!end) return { wait: true }
      stop = body.length
    }
    const whole = !!c && c.index === stop
    const region = body.slice(0, stop).replace(/<(\/?)antml:parameter\b/g, "<$1parameter")
    const p = paramArgs(region, name, this.tools)
    if (!whole && !p.closed) {
      // no parameter and no close: a tag named in passing; a parameter
      // left open: the call cut short (plugins#38)
      if (!/<parameter\b/.test(region)) return { text: true }
      return { error: CUT_SHORT }
    }
    return { call: { name, arguments: JSON.stringify(p.args) }, rest: whole ? body.slice(stop + c[0].length) : body.slice(stop) }
  }

  // block reads what follows a <tool_call> opener: {call, rest} for a
  // call, {wait} while it may still become one, {text} when it is no call
  // at all, {error} for one that can't be read: cut short, or not JSON
  // even as models get it wrong (plugins#38). named is the name an opener
  // gave as <tool_call name="…">.
  block(body, named, end) {
    if (!end && !body.trim()) return { wait: true }
    const [close, closeLen] = closeAt(body)
    if (named) {
      if (close < 0 && !end) return { wait: true }
      const region = close >= 0 ? body.slice(0, close) : body
      const rest = close >= 0 ? body.slice(close + closeLen) : ""
      if (region.trimStart().startsWith("{")) {
        const v = repairedJSON(region.trim())
        if (!v) return { error: close >= 0 ? UNREADABLE : CUT_SHORT }
        return { call: v.name ? { name: String(v.name), arguments: callArgs(v) } : { name: named, arguments: JSON.stringify(v) }, rest }
      }
      if (region.includes("<arg_key>")) {
        const w = glmCall(named + region, this.tools)
        return w ? { call: { name: w.name, arguments: callArgs(w) }, rest } : { error: close >= 0 ? UNREADABLE : CUT_SHORT }
      }
      const p = paramArgs(region, named, this.tools)
      // cut short at the end: whole only when each parameter was closed
      if (close < 0 && !p.closed) return { error: CUT_SHORT }
      return { call: { name: named, arguments: JSON.stringify(p.args) }, rest }
    }
    if (body.trimStart().startsWith("{")) {
      const ph = body.match(PARAM_HEAD)
      if (ph) {
        // DeepSeek's half-and-half: the name as JSON, then its parameters
        // (magpie#917)
        if (close < 0 && !end) return { wait: true }
        const region = body.slice(ph[0].length, close >= 0 ? close : body.length)
        const p = paramArgs(region, ph[1], this.tools)
        if (close < 0 && !p.closed) return { error: CUT_SHORT }
        return { call: { name: ph[1], arguments: JSON.stringify(p.args) }, rest: close >= 0 ? body.slice(close + closeLen) : "" }
      }
      const o = objectEnd(body, 0)
      if (o > 0 && !this.bad.has(":" + o)) {
        const v = callJSON(body.slice(0, o))
        // a name alone may have its parameters still to come
        if (v && !end && Object.keys(v).length === 1 && "<parameter".startsWith(body.slice(o).replace(/^\s*>?\s*/, ""))) return { wait: true }
        if (v) {
          // what follows the object up to the close: GLM leaves braces,
          // brackets, quotes or a > of its own there (}}</tool_call>,
          // "></tool_call>, magpie#1945), dropped with the close; held
          // while only those have come
          const tail = body.slice(o)
          const junk = tail.match(TAIL_JUNK)[0]
          const next = tail.slice(junk.length)
          const call = { name: String(v.name), arguments: callArgs(v) }
          if (!end && (!next || ["</tool_call>", "</toolcall>"].some((k) => k.startsWith(next)))) return { wait: true }
          const [c, n] = closeAt(next)
          if (c === 0) return { call, rest: next.slice(n) }
          // after blanks alone, or with no close to come: the call, and
          // what follows read on as before. Other text before the close
          // right after the object means the object ended early, at a
          // quote inside a string left unescaped: that cut is wrong (a
          // heredoc's command cut short, magpie#1945), so it is read up to
          // the close below, or not at all
          if (!/\S/.test(junk) && !/^[^\s<]/.test(next)) return { call, rest: tail }
          if (close < 0 && end) return { call, rest: tail }
        } else this.bad.add(":" + o)
      }
      // not whole, or not JSON as it stands: read up to a close (a file's
      // content may hold one), or at the end all of it
      for (let [j, n] = [close, closeLen]; j >= 0; [j, n] = closeAt(body, j + 1)) {
        if (this.bad.has("<" + j)) continue
        const v = callJSON(body.slice(0, j))
        if (v) return { call: { name: String(v.name), arguments: callArgs(v) }, rest: body.slice(j + n) }
        this.bad.add("<" + j)
      }
      if (!end) return { wait: true }
      const v = callJSON(body)
      if (v) return { call: { name: String(v.name), arguments: callArgs(v) }, rest: "" }
      return { error: close >= 0 ? UNREADABLE : CUT_SHORT }
    }
    // GLM's own (a name, then <arg_key>/<arg_value> pairs), or text
    if (!/^\s*[\w.:-]{1,128}\s*(?:<|$)/.test(body)) return { text: true }
    if (close < 0 && !end) return { wait: true }
    const region = close >= 0 ? body.slice(0, close) : body
    const w = glmCall(region, this.tools)
    // GLM's call, cut short at the end, is still the call
    if (w) return { call: { name: w.name, arguments: callArgs(w) }, rest: close >= 0 ? body.slice(close + closeLen) : "" }
    if (/^\s*[\w.:-]{1,128}\s*<arg_key>/.test(body)) return { error: close >= 0 ? UNREADABLE : CUT_SHORT }
    return { text: true }
  }
}

// A {"tool_calls":[{ at a line's start (plugins#1114); before refers to
// what came before buf, the start of a line only after a line break or
// blanks.
const JSON_CALL_AT = /(^|\n)[ \t]*\{\s*"tool_calls"\s*:\s*\[\s*\{/g
const JSON_CALL_KEY = '{"tool_calls":[{'
const atLineStart = (before) => !/\S/.test(before.slice(before.lastIndexOf("\n") + 1))

// jsonCallAt is where in buf the line holding such an object starts, or -1
function jsonCallAt(buf, before) {
  for (const m of buf.matchAll(JSON_CALL_AT)) {
    const at = m.index + m[1].length
    if (at > 0 || atLineStart(before)) return at
  }
  return -1
}

// jsonHoldAt is where buf's last line starts when it may still grow into
// one (its indent alone too), or -1
function jsonHoldAt(buf, before) {
  const k = buf.lastIndexOf("\n") + 1
  if (k === 0 && !atLineStart(before)) return -1
  const line = buf.slice(k)
  return line && JSON_CALL_KEY.startsWith(line.replace(/\s+/g, "")) ? k : -1
}

// jsonCalls reads such an object's calls: {"name","arguments"} entries or
// OpenAI's {"type":"function","function":{…}}; null when there are none or
// one has no name
function jsonCalls(s) {
  const list = looseJSON(s)?.tool_calls
  if (!Array.isArray(list) || !list.length) return null
  const out = []
  for (const e of list) {
    const f = e?.function ?? e
    if (!f || typeof f.name !== "string" || !f.name) return null
    out.push({ name: f.name, arguments: callArgs(f) })
  }
  return out
}

const CUT_SHORT = "the model's tool call, written as text, was cut short; it is not sent on as the answer"
const UNREADABLE = "the model's tool call, written as text, can't be read; it is not sent on as the answer"

// an opener: <tool_call>, one with attributes (<tool_call name="bash">),
// or <tool_call right before its JSON; and one still being written. GLM
// also writes it without the underscore, <toolcall> (plugins#38)
const OPEN_AT = /<tool_?call(?:(\s[^<>{}]*)?>|(?=\s*\{))/
const OPEN_HOLD = /<tool_?call(?:\s[^<>{}\n]{0,200})?$/
// what GLM leaves between a call's JSON and its close: blanks, closing
// braces and brackets, quotes, a > (magpie#1945)
const TAIL_JUNK = /^[\s}\]"'>]*/
// a close with no call open, and that leftover before it: the tail of a
// call Trae's service read itself, or of one already read (magpie#1945)
const STRAY_AT = /[}\]"'>]*\s*<\/tool_?calls?>/
// the end of text that may be such a tail still being written
const STRAY_HOLD = /[}\]"'>][\s}\]"'>]*$/
// closeAt is where the next close is from i, </tool_call> or </toolcall>,
// and its length: [-1, 0] when there is none
function closeAt(s, i = 0) {
  const re = /<\/tool_?call>/g
  re.lastIndex = i
  const m = re.exec(s)
  return m ? [m.index, m[0].length] : [-1, 0]
}
// DeepSeek's half-and-half call: {"name":"x"} (or its brace or > left
// out), then <parameter name="k">v</parameter> or Qwen's <parameter=k>
const PARAM_HEAD = /^\s*\{\s*"name"\s*:\s*"([^"]+)"\s*\}?\s*>?\s*(?=<parameter\b)/
const PARAM_OPEN = /<parameter(?:\s+name\s*=\s*"([^"]+)"|=([^\s>]+))\s*>/g

// quoted says text ends inside a code fence or inline code: what comes
// next is shown, not done
function quoted(text) {
  if ((text.match(/```/g)?.length ?? 0) % 2) return true
  const line = text.slice(text.lastIndexOf("\n") + 1).replace(/```/g, "")
  return (line.match(/`/g)?.length ?? 0) % 2 === 1
}

// paramArgs reads <parameter name="k">v</parameter> (or <parameter=k>)
// arguments; a value runs to its close, the next parameter or the end. A
// value is its text where the tool's schema says string (or it isn't
// JSON), else its JSON. closed says each one had its close.
function paramArgs(s, name, tools = []) {
  const props = (tools.find((t) => (t.function ?? t)?.name === name)?.function ?? {}).parameters?.properties ?? {}
  const opens = [...s.matchAll(PARAM_OPEN)]
  const args = {}
  let closed = opens.length > 0
  opens.forEach((m, k) => {
    const from = m.index + m[0].length
    const to = k + 1 < opens.length ? opens[k + 1].index : s.length
    let v = s.slice(from, to)
    const c = v.indexOf("</parameter>")
    if (c >= 0) v = v.slice(0, c)
    else closed = false
    v = v.replace(/^\r?\n|\r?\n$/g, "")
    const key = m[1] ?? m[2]
    if (props[key]?.type === "string") {
      args[key] = v
      return
    }
    try {
      args[key] = JSON.parse(v.trim())
    } catch {
      args[key] = v
    }
  })
  return { args, closed }
}

// callJSON is a block's call ({name, …}) as a model may get its JSON
// wrong, null when it isn't one even so
function callJSON(s) {
  const v = repairedJSON(s)
  return v && typeof v.name === "string" && v.name ? v : null
}

// repairedJSON reads a JSON object as looseJSON does, and else as models
// get it wrong (plugins#38): every quote escaped ({\"name\":…}), a
// backslash that escapes nothing JSON knows (\_ \| C:\Users in a file's
// content), or quotes inside a string left unescaped ("官方" in a write's
// content)
function repairedJSON(s) {
  const v = looseJSON(s)
  if (v) return v
  const t = escapeRaw(s)
  const tries = []
  if (/^\s*\{\s*\\"/.test(s)) {
    try {
      const u = JSON.parse('"' + s.trim().replace(/[\n\r\t]/g, (c) => (c === "\n" ? "\\n" : c === "\r" ? "\\r" : "\\t")) + '"')
      tries.push(u, escapeRaw(u))
    } catch {}
    tries.push(s.replace(/\\"/g, '"'))
  }
  tries.push(fixEscapes(t), quoteFix(fixEscapes(t)))
  for (const x of tries) {
    try {
      const v = JSON.parse(x)
      if (v && typeof v === "object" && !Array.isArray(v)) return v
    } catch {}
  }
  return null
}

// fixEscapes makes a backslash that escapes nothing JSON knows a backslash
// of its own (\' is the quote it meant)
function fixEscapes(s) {
  return s.replace(/\\(u[0-9a-fA-F]{4}|["\\/bfnrt])|\\'|\\/g, (m, ok) => (ok ? m : m === "\\'" ? "'" : "\\\\"))
}

// quoteFix escapes the quotes inside strings a model left unescaped: a
// quote ends a key only before its colon, and a value only before what
// may follow the last of one (closing braces or brackets, then the end or
// a comma and the next key or value)
function quoteFix(s) {
  let out = ""
  const stack = []
  let key = false
  for (let i = 0; i < s.length; ) {
    const ch = s[i]
    if (ch !== '"') {
      if (ch === "{") {
        stack.push("{")
        key = true
      } else if (ch === "[") stack.push("[")
      else if (ch === "}" || ch === "]") stack.pop()
      else if (ch === ",") key = stack.at(-1) === "{"
      else if (ch === ":") key = false
      out += ch
      i++
      continue
    }
    const isKey = key && stack.at(-1) === "{"
    const inArray = stack.at(-1) === "["
    out += ch
    i++
    for (; i < s.length; i++) {
      const c = s[i]
      if (c === "\\") {
        out += c + (s[i + 1] ?? "")
        i++
        continue
      }
      if (c !== '"') {
        out += c
        continue
      }
      const after = s.slice(i + 1)
      const ends = isKey ? /^\s*:/.test(after) : (inArray ? /^\s*(?:[}\]]\s*)*(?:$|,\s*["{[\d\-tfn])/ : /^\s*(?:[}\]]\s*)*(?:$|,\s*")/).test(after)
      if (ends) {
        out += c
        i++
        break
      }
      out += '\\"'
    }
    key = false
  }
  return out
}

// GLM's call template: the tool's name, then each argument as
// <arg_key>k</arg_key><arg_value>v</arg_value>
const GLM_ARG = /<arg_key>\s*([\s\S]*?)\s*<\/arg_key>\s*<arg_value>([\s\S]*?)<\/arg_value>/g

// glmCall is a call GLM wrote in its template ({name, arguments}), null
// when s isn't one. A value is its text where the tool's schema says
// string (or the text isn't JSON), else its JSON, as GLM's template writes
// a value that isn't a string. A name alone is a call only to a tool the
// request has.
function glmCall(s, tools = []) {
  s = String(s ?? "").replace(/<\/tool_?call>\s*$/, "")
  const k = s.indexOf("<arg_key>")
  const name = (k < 0 ? s : s.slice(0, k)).trim()
  if (!/^[\w.:-]{1,128}$/.test(name)) return null
  if (k < 0 && !tools.some((t) => (t.function ?? t)?.name === name)) return null
  const props = (tools.find((t) => (t.function ?? t)?.name === name)?.function ?? {}).parameters?.properties ?? {}
  const args = {}
  for (const m of s.matchAll(GLM_ARG)) {
    const raw = m[2]
    if (props[m[1]]?.type === "string") {
      args[m[1]] = raw
      continue
    }
    try {
      args[m[1]] = JSON.parse(raw.trim())
    } catch {
      args[m[1]] = raw
    }
  }
  if (k >= 0 && !Object.keys(args).length) return null
  return { name, arguments: args }
}

// Trae reads a model's call for it and hands a call it could not read on as
// the native call: the wrapper the client's prompt asked for, with GLM's own
// template tags where the model wrote them and a field's close left behind
// (``{"name":"bash","arguments":{"command</arg_key><arg_value>ls</arg_value>``).
// The name then holds the call the model meant, and the call's own arguments
// — where the model wrote them — hold the rest of it.
const NAMECALL = /^\s*\{\s*"name"\s*:\s*"([^"\\]*)"\s*,\s*"(?:arguments|input|parameters)"\s*:\s*\{/
// a wrapper the service put text in front of (`bash_abstract_command_0>{…}`):
// the same shape, wherever it starts
const NAMEHEAD = /\{\s*"name"\s*:\s*"([^"\\]*)"\s*,\s*"(?:arguments|input|parameters)"\s*:\s*\{/
const NAMETAG = /<\/?arg_(?:key|value)\s*>/

// nameCall is the call a name holds when it is one the model wrote there
// ({name, arguments}), null when it isn't: a name without the wrapper, one
// whose tool the request doesn't have, or one no field could be read from.
// The wrapper and the tags are the service's own handoff, so what stands
// between them is the model's text as it wrote it — a quote it left
// unescaped is read as the quote it is, the way repairedJSON reads a file's
// content. A value is JSON where the tool's schema says the field is no
// string and the text is one; else the text, cut where the value was cut.
function nameCall(s, tools = []) {
  const text = String(s ?? "")
  // a wrapper the service put text in front of (`bash_abstract_command_0>{…}`)
  // is the call it holds, that text being no name the request has
  const at = text.indexOf("{")
  if (at < 0) return null
  const m = NAMECALL.exec(text.slice(at))
  if (!m) return null
  const name = m[1]
  const tool = tools.map((t) => t.function ?? t).find((t) => t?.name === name)
  if (!tool) return null
  const fields = nameFields(text.slice(at + m[0].length))
  const args = {}
  for (const [key, value] of fields) {
    // a field the schema says is no string is its JSON where it is one (a
    // number the model wrote, an object), else the text it is
    if (tool.parameters?.properties?.[key]?.type !== "string") {
      try {
        args[key] = JSON.parse(value.trim())
        continue
      } catch {}
    }
    args[key] = value
  }
  return Object.keys(args).length ? { name, arguments: args } : null
}

// nameFields reads a wrapper's body as its fields: a key, then its value.
// A tag stands where the service cut a colon or a quote, so a value ends at
// the tag that ends it, at the next key, or at the structure that closes it
// — and at a closing tag (`</description>`) whose name is a field's, because
// what follows such a tag is the service's own text, not the model's.
// What none of those reached is no field's text and is left out, so a call
// cut in the middle keeps what it has.
function nameFields(body) {
  const out = []
  let i = 0
  for (let n = 0; n < 64 && i < body.length; n++) {
    // between fields: blanks, a comma, or the tags that stand for either
    i += (body.slice(i).match(/^[\s,]+|^<\/?[a-z_]+\s*>/) || [""])[0].length
    if (body[i] !== '"') break
    const key = nameString(body, i, () => true)
    i = key.i
    if (!key.text) break
    const colon = body.slice(i).match(/^\s*:\s*/)
    if (colon) i += colon[0].length
    // a value the service cut at its tag: what stands after the tag is the
    // model's text (limit</arg_key><arg_value>55)
    i += (body.slice(i).match(/^(?:<\/?[a-z_]+\s*>)+/) || [""])[0].length
    let value
    if (body[i] === '"') {
      const v = nameString(body, i, (rest) => endsValue(rest))
      value = v.text
      i = v.i
      if (!value && !v.closed) break // an open quote with nothing in it
    } else {
      const rest = body.slice(i)
      const stop = valueEnd(rest)
      value = rest.slice(0, stop).replace(/^[\s,:]+/, "")
      // the field's own close: the structure that follows it, and a quote
      // the service cut it at where an escape isn't what stands before it
      value = value.replace(/[\s,}\]]+$/, "").replace(/(?<!\\)"$/, "").replace(/[\s,}\]]+$/, "")
      i += stop
      // nothing introduced a value (no colon, no quote, no tag) and none
      // stands: the wrapper is cut at the key, and an empty call read out
      // of it would be a call the model never wrote
      if (!value) break
    }
    out.push([key.text, value])
  }
  return out
}

// endsValue is what may stand after a string's closing quote: the structure
// that closes the field (`,`, `}`, `]`, the end), a tag that stands for one,
// or the next field's key.
function endsValue(rest) {
  if (/^\s*(?:[,}\]$]|<\/?[a-z_]+\s*>)/.test(rest)) return true
  return /^\s*"(?:[^"\\]|\\.)*"\s*(?::|<\/?[a-z_]+\s*>)/.test(rest)
}

// valueEnd is where an unquoted value runs out: the next key, a tag that
// ends it, or the structure that closes the field. A comma inside it is the
// model's own (sed -n 1,9p), so only a brace or a bracket closes a field.
function valueEnd(rest) {
  const stops = [
    rest.search(/"(?:(?:[^"\\<>]*)"\s*(?::|,|\s*<\/?[a-z_]+\s*>)|[^"\\<>]*<\/?[a-z_]+\s*>)/),
    rest.search(/<\/?[a-z_]+\s*>/),
    rest.search(/[}\]]/),
  ].filter((x) => x >= 0)
  return stops.length ? Math.min(...stops) : rest.length
}

// nameString reads the string at s[i] === '"', its escapes kept as written.
// ends says, for what follows a quote, whether that quote ended the string:
// a quote the model left unescaped inside a value is escaped as read on.
// `closed` is whether the model's own quote ended it, where the read ran
// into a tag or the end of the text.
function nameString(s, i, ends) {
  i++ // the opening quote
  let src = ""
  while (i < s.length) {
    const ch = s[i]
    if (ch === "\\") {
      src += s[i] + (s[i + 1] ?? "")
      i += 2
      continue
    }
    if (ch === "<") {
      // a tag ends the run: the service cut the value at it, whether it is
      // one of its own (`</arg_value>`) or a field's (`</description>`),
      // for neither is text the model wrote
      if (/^<\/?[a-z_][\w-]*\s*>/.test(s.slice(i))) break
    }
    if (ch === '"') {
      if (ends(s.slice(i + 1))) {
        i++
        return { text: decode(src), i, closed: true }
      }
      src += '\\"'
      i++
      continue
    }
    src += ch
    i++
  }
  return { text: decode(src), i, closed: false }
}

// decode is a string's own source as the string: the escapes the model wrote
// are the characters they stand for, a newline among them
function decode(src) {
  try {
    return JSON.parse('"' + escapeRaw(src) + '"')
  } catch {
    return src
  }
}

// toolNamed is the request's own name for a tool a model named otherwise
// (Read for read, list-files for list_files); name itself when the request
// has none like it. A tool it has none of goes on as named: the agent tells
// the model there's no such tool, which it can act on, where a call
// dropped here would end the turn with nothing.
function toolNamed(name, tools) {
  const names = tools.map((t) => (t.function ?? t)?.name).filter(Boolean)
  if (!names.length || names.includes(name)) return name
  const norm = (n) => String(n).toLowerCase().replace(/[^a-z0-9]/g, "")
  return names.find((n) => norm(n) === norm(name)) ?? name
}

// unwrapped is a call's arguments with the layer a model put around them
// taken off: asked for {"name":…,"arguments":{…}}, some write the
// arguments as {"arguments":{…}} again, natively or in the block, and the
// agent got {"arguments":{"content":…,"path":…}} for its write (bee2an on
// X). A lone arguments, input, parameters or args key holding an object is
// that layer when the tool has no parameter of that name.
const WRAPS = ["arguments", "input", "parameters", "args"]
function unwrapped(args, name, tools) {
  const t = tools.map((x) => x.function ?? x).find((f) => f?.name === name)
  if (!t) return args
  const props = t.parameters?.properties ?? {}
  let v = looseJSON(args)
  let changed = false
  for (let k = 0; k < 3 && v && typeof v === "object" && !Array.isArray(v); k++) {
    const keys = Object.keys(v)
    if (keys.length !== 1 || !WRAPS.includes(keys[0]) || keys[0] in props) break
    let inner = v[keys[0]]
    if (typeof inner === "string") inner = looseJSON(inner)
    if (!inner || typeof inner !== "object" || Array.isArray(inner)) break
    v = inner
    changed = true
  }
  return changed ? JSON.stringify(v) : args
}

// DeepSeek's tags, with its full-width bar or a plain one
const DSML = String.raw`<\s*\/?\s*[|｜][\s|｜]*DSML[\s|｜]*`
const DSML_AT = new RegExp(DSML)
const DSML_TAG = new RegExp("^" + DSML + "[^<>]*>")
const DSML_INVOKE = new RegExp(String.raw`^<\s*[|｜][\s|｜]*DSML[\s|｜]*invoke\s+name\s*=\s*"([^"]+)"\s*>`)
const DSML_INVOKE_AT = new RegExp(String.raw`<\s*[|｜][\s|｜]*DSML[\s|｜]*invoke\s+name\s*=`)
const DSML_CLOSE = new RegExp(String.raw`<\s*\/\s*[|｜][\s|｜]*DSML[\s|｜]*invoke\s*>`)
const DSML_PARAM = new RegExp(String.raw`<\s*[|｜][\s|｜]*DSML[\s|｜]*parameter\s+name\s*=\s*"([^"]+)"((?:\s+\w+\s*=\s*"[^"]*")*)\s*>([\s\S]*?)` + DSML + String.raw`parameter\s*>`, "g")
// Anthropic's and Qwen's call tags (xmlCall): where one starts, an
// opener still being written, the openers a wrapper is followed by, and
// the next call's opener
const XML_AT = /<(?:antml:)?(?:function_calls>|invoke\s+name\s*=|function=)/
const XML_HOLD = /<(?:antml:)?(?:invoke\s[^<>]{0,300}|function=[^<>]{0,300})$/
const XML_STARTS = ["<invoke ", "<antml:invoke ", "<function="]
const XML_NEXT = /<(?:antml:)?invoke\s+name\s*=|<function=/
// what is left after a call: blanks, our close, DeepSeek's tags but the
// next call's, the closes of Anthropic's and Qwen's
const LEFTOVER = new RegExp(String.raw`^(?:\s+|<\/tool_?calls?>|<tool_?calls>|<\/(?:antml:)?(?:function_calls|invoke|function)>|` + DSML + String.raw`(?![\s|｜]*invoke\b)[^<>]*>)+`)
// what text may be the start of, so held back
const MARKS = [OPEN, CLOSE, "<toolcall>", "</toolcall>", "<｜DSML｜", "<|DSML|", "</｜DSML｜", "</|DSML|", '{"reasoning_content"', "<function_calls>", "</function_calls>", "<antml:function_calls>", "</antml:function_calls>", "<invoke ", "<antml:invoke ", "</invoke>", "</antml:invoke>", "<function=", "</function>"]
// reasoning a model wrote into its text as JSON
const REASON_AT = /\{\s*"reasoning_content"\s*:/
const MARK_MAX = Math.max(...MARKS.map((m) => m.length))

// dsmlArgs is the arguments of a DSML invoke as JSON: a parameter marked
// string="true" is its text, any other its JSON (its text when not JSON)
function dsmlArgs(body) {
  const args = {}
  for (const p of body.matchAll(DSML_PARAM)) {
    if (/string\s*=\s*"true"/.test(p[2])) {
      args[p[1]] = p[3]
      continue
    }
    try {
      args[p[1]] = JSON.parse(p[3].trim())
    } catch {
      args[p[1]] = p[3]
    }
  }
  return JSON.stringify(args)
}

// objectEnd is where the JSON object starting at from (after blanks) ends:
// past its closing brace, -1 when it isn't whole yet, -2 when there's none
function objectEnd(s, from) {
  let k = from
  while (k < s.length && /\s/.test(s[k])) k++
  if (k >= s.length) return -1
  if (s[k] !== "{") return -2
  let depth = 0
  let str = false
  let esc = false
  for (; k < s.length; k++) {
    const ch = s[k]
    if (str) {
      if (esc) esc = false
      else if (ch === "\\") esc = true
      else if (ch === '"') str = false
      continue
    }
    if (ch === '"') str = true
    else if (ch === "{") depth++
    else if (ch === "}" && --depth === 0) return k + 1
  }
  return -1
}

// looseJSON reads a JSON object as a model writes one: a string holding a
// raw newline or tab (a file's content written out, #799) is read as if
// they were escaped. null when it isn't one even so.
function looseJSON(s) {
  for (const t of [s, escapeRaw(s)]) {
    try {
      const v = JSON.parse(t)
      if (v && typeof v === "object" && !Array.isArray(v)) return v
    } catch {}
  }
  return null
}

// escapeRaw escapes the control characters inside JSON strings
function escapeRaw(s) {
  let out = ""
  let str = false
  let esc = false
  for (const ch of String(s ?? "")) {
    if (str && !esc && ch < " ") {
      out += ch === "\n" ? "\\n" : ch === "\r" ? "\\r" : ch === "\t" ? "\\t" : "\\u" + ch.charCodeAt(0).toString(16).padStart(4, "0")
      continue
    }
    if (str && ch === "\\" && !esc) esc = true
    else {
      if (ch === '"' && !esc) str = !str
      esc = false
    }
    out += ch
  }
  return out
}

// callArgs is a tagged block's arguments as JSON: under arguments (an
// object, or a string of one), input or parameters, else the block's other
// keys, as a model that writes them beside the name means them (#799: a
// write that went out as {})
function callArgs(v) {
  let a = v.arguments ?? v.input ?? v.parameters
  if (a === undefined) {
    const { name, type, id, ...rest } = v
    a = rest
  }
  if (typeof a === "string") return a.trim() ? (looseJSON(a) ? JSON.stringify(looseJSON(a)) : a) : "{}"
  return JSON.stringify(a ?? {})
}

// nativeCall is a tool call as Trae's events carry one
function nativeCall(tc) {
  const f = tc?.function ?? tc?.function_call ?? tc
  const name = f?.name ?? tc?.tool_name ?? ""
  const index = Number.isInteger(tc?.index) ? tc.index : null
  const a = f?.arguments ?? f?.args ?? tc?.params ?? tc?.input ?? tc?.parameters ?? ""
  const args = typeof a === "string" ? a : JSON.stringify(a)
  if (!name && index === null && !tc?.id && !args) return null
  return { id: tc?.id || tc?.tool_call_id || "", index, name: String(name), arguments: args }
}

// NativeCalls puts together the tool calls Trae streams: a call comes in
// several events under one id (or index), each with the arguments so far
// or only the new piece, so a call is sent on once the answer is whole,
// not from its first event (#799: bash's command cut to `echo "T`)
class NativeCalls {
  constructor() {
    this.calls = []
  }
  push(tc) {
    const c = nativeCall(tc)
    if (!c) return
    let o = this.calls.find((x) => (c.id && x.id === c.id) || (!c.id && c.index !== null && x.index === c.index))
    if (!o && !c.id && c.index === null)
      o = this.calls.findLast((x) => x.name === c.name && (x.arguments === c.arguments || (!done(x.arguments) && c.arguments.startsWith(x.arguments))))
    // a piece with nothing to say whose it is (or an index its call's
    // first event didn't give) belongs to the call still being written
    if (!o && !c.name && !c.id) {
      o = this.calls.findLast((x) => !done(x.arguments))
      if (o && c.index !== null && o.index !== null && o.index !== c.index) o = null
    }
    if (!o) {
      if (!c.name) return
      this.calls.push({ ...c })
      return
    }
    // a name comes as the arguments do: a snapshot that grows. A name that
    // starts with what was read is that snapshot further along, and takes
    // its place — a wrapper cut short at a tag, then the whole call again.
    // A name that doesn't start with it is a piece of the name's own, or
    // one no snapshot explains, and the first is kept as it was
    if (!o.name) o.name = c.name
    else if (c.name && c.name.startsWith(o.name) && c.name !== o.name) o.name = c.name
    if (c.index !== null && o.index === null) o.index = c.index
    const prev = o.arguments
    const next = c.arguments
    if (!next || prev.startsWith(next)) return // nothing new
    if (next.startsWith(prev) || done(prev)) o.arguments = next // the arguments so far
    else if (resent(prev, next)) o.arguments = next // the whole call again, written apart (plugins#24)
    else o.arguments = prev + next // a piece
  }
  take(tools = []) {
    return this.calls.filter((c) => c.name).map(({ id, name, arguments: a }) => {
      // a name that holds the whole call, as the client's wrapper or in
      // GLM's template: that call, its arguments the name's when it gave
      // none of its own. The wrapper is read as JSON where it is whole —
      // its nesting is its own — and as the service's handoff where it was
      // left mid-call, a wrapper written with a space (`{ "name"`) whole
      // like any other
      const w = name.trimStart().startsWith("{") ? looseJSON(name) ?? nameCall(name, tools)
        : NAMEHEAD.test(name) ? nameCall(name, tools)
        : name.includes("<arg_key>") ? glmCall(name, tools) : null
      if (w?.name) {
        name = String(w.name)
        // the name's own arguments are the model's; what the name read fills
        // the fields they left (the wrapper's text is the whole call where
        // Trae moved the arguments with it, and the rest where it did not)
        a = nameArgs(a, w)
      }
      const v = a && !done(a) ? looseJSON(a) : null
      return { id: id || callId(), name, arguments: v ? JSON.stringify(v) : a || "{}" }
    })
  }
}

// nameArgs is the arguments of a call a name held: the native call's own
// where it carried them, else the name's, and the two together where each
// has a field the other hasn't — the service moves the arguments it read
// into the native call and leaves the rest in the name. The name's side is
// read the way main reads a whole name (`callArgs`: `arguments`, `input`,
// `parameters`, arguments given as a string, or the flat fields), so what
// main already read keeps reading the same. The two stand together only as
// two sets of fields; a call's own arguments that are not that — text the
// service cut, or a value that isn't a call's fields — go on as they stand,
// which is what main passed on and what the agent can answer.
function nameArgs(native, fromName) {
  const a = typeof native === "string" ? native.trim() : ""
  const named = callArgs(fromName)
  if (!a || a === "{}") return named
  const own = looseJSON(a), side = looseJSON(named)
  if (!own || !side || typeof own !== "object" || typeof side !== "object" || Array.isArray(own) || Array.isArray(side)) return a
  return JSON.stringify({ ...side, ...own })
}

// resent says next is the call's whole arguments sent again after a
// partial snapshot, not a piece of them: Trae resends a snapshot whose
// punctuation isn't the first one's (− for -, ′ for '), so it doesn't
// start with it. A whole object under the same first key as prev's, which
// prev and it joined don't make whole; a piece that is a value of its own
// (12, "ls", {}) doesn't open with prev's first key.
function resent(prev, next) {
  const key = (s) => s.match(/^\s*\{\s*"((?:[^"\\]|\\.)*)"/)?.[1]
  if (!next.trimStart().startsWith("{") || !done(next) || done(prev + next)) return false
  const k = key(prev)
  return k !== undefined && k === key(next)
}

// done says arguments are a whole JSON value already
function done(a) {
  if (!a) return false
  try {
    JSON.parse(a)
    return true
  } catch {
    return false
  }
}

// the events that carry the answer: output and message, and the names
// Trae has put a reply's text under otherwise (delta, or none at all);
// any other is queueing, metadata or timing
const ANSWER = new Set(["", "output", "message", "delta", "content", "text", "answer", "chunk", "output_delta", "message_delta"])

// TRAE_CUT is the reply length Trae stops an enterprise model's chat at
// whatever limit it is asked for: four models of one seat each answered
// exactly 2000 completion tokens, finish_reason "stop", mid-sentence, with
// max_tokens 4096 asked (@liuyuexue2020 on X, 0.2.44)
const TRAE_CUT = 2000

// cutFinish is the finish an answer that came to its limit ends with: Trae
// says "stop" (or nothing) of a reply it cut, so an agent took a half
// answer for a whole one. A reply that used every token it was let have
// (limit, the max_tokens sent; or cut, Trae's own TRAE_CUT for an
// enterprise model, 0 for a preset, which wasn't seen cut) ended for length.
//
// Trae's completion_tokens count the reasoning too, and the reasoning isn't
// held to max_tokens: GLM-5.3 answered "OK" to max_tokens 16 with
// completion_tokens 55, 52 of them reasoning, and Trae's own finish "stop"
// (plugins#1503). So a reply came to its limit when the count is the limit
// exactly, or what it said past its reasoning reached it; a count past the
// limit by reasoning alone is a whole reply.
function cutFinish(finish, usage, limit, cut = 0) {
  if (finish && finish !== "stop") return finish
  const c = Number(usage?.completion_tokens) || 0
  const r = Number(usage?.completion_tokens_details?.reasoning_tokens ?? usage?.reasoning_tokens) || 0
  if (c > 0 && ((limit > 0 && (c === limit || c - r >= limit)) || (cut > 0 && c === cut))) return "length"
  return finish
}

// wholeArgs says a call's arguments are whole JSON, as the agent reads them
function wholeArgs(a) {
  try {
    JSON.parse(a)
    return true
  } catch {
    return false
  }
}

// ending is how a reply with these calls ends: a reply Trae cut (it came
// to its limit, or Trae said length) whose call it cut too goes out
// without that call and ends for length, the text before it kept. Sent as
// a call, the agent ran a call with half its arguments, or stopped on it
// and sent nothing more: an enterprise seat's reply of exactly 2000 tokens,
// one call, tool_calls, and no next request (plugins#1366, 0.2.47). A whole
// call in a cut reply is the model's and goes out as one.
function ending(calls, finish, usage, limit, cut) {
  const ended = cutFinish(finish, usage, limit, cut) || "stop"
  if (ended === "length") {
    const kept = calls.filter((c) => wholeArgs(c.arguments))
    if (kept.length < calls.length) return { calls: kept, finish: "length", dropped: calls.length - kept.length }
  }
  return { calls, finish: calls.length ? "tool_calls" : ended, dropped: 0 }
}

// GO_ON is the turn a reply Trae cut is asked to go on with, after the
// text it had written so far as the assistant's own
const GO_ON = "Continue exactly where your previous message stopped. Do not repeat anything already written and do not add any preface."

// THINK_ON is the turn a reply is asked again with when Trae cut every
// round of it in the model's reasoning, nothing written yet: there is no
// text to go on from, and asked the same, the model reasons the same
// length again (plugins#1366, 0.2.51: AI/GLM-5.3-Flash and
// AI/deekseek-v4.1-flash, round 1 completion_tokens=2000 with
// reasoning_tokens 1983 and 1999, text_chars=0). It names neither magpie
// nor Trae's limit: it goes to the model
const THINK_ON = "Your previous reply ran out of room while you were still reasoning, before you wrote any answer. Do not start your reasoning over: keep what is left of it short, then write the answer or make the tool call directly."

// CUT_ROUNDS bounds the asks one reply takes: 16 of TRAE_CUT is 32000
// tokens, an enterprise model's usual max_tokens
const CUT_ROUNDS = 16

// tune holds the waits tests shorten. keepEvery: how long an enterprise
// model's stream may go with nothing sent before it is sent an SSE
// comment. A reply Trae cut is asked on (continued), and nothing comes
// while the next ask waits for its first word; the agent, or a proxy
// before it, took the quiet for a dead stream and reconnected
// (plugins#1366, 0.2.49, Codex). magpie hears the comment as the plugin
// still answering, and keeps its own agent alive (a Responses agent gets
// response.in_progress, which Codex's idle timeout counts).
const tune = { keepEvery: 2000 }

// THOUGHT_ROUNDS bounds the asks in a row Trae cut in the model's
// reasoning, nothing written: a reasoning model asked to go on reasons
// again first, and a round can go to the cut in it (plugins#1366, 0.2.49:
// round 1 text_chars=1834, round 2 text_chars=0 reasoning_chars=7683,
// both completion_tokens=2000). Its reasoning isn't sent back, so a model
// that never gets past it would spend every round on it. A reply that
// wrote nothing in as many rounds ends as an error saying so (reasoned),
// not as an empty reply cut for length.
const THOUGHT_ROUNDS = 3

// reasoned is the error a reply ends with that went rounds in a row only
// reasoning, every one cut at Trae's round limit, and wrote nothing: the
// gateway would call it an empty reply, which says nothing of why
function reasoned(model, rounds, cut, why = "") {
  const who = model ? `${model} ` : "the model "
  return `${who}wrote no answer: it spent ${rounds} round${rounds === 1 ? "" : "s"} in a row only reasoning, each cut at Trae's ${cut}-token round limit for enterprise models${why ? `, and the next ask ${why}` : ""}. Try a shorter task or another model.`
}

// addUsage is two asks' usage as one: each ask is billed on its own, so
// both its prompt and its reply count
function addUsage(a, b) {
  if (!a) return b
  if (!b) return a
  const out = {
    prompt_tokens: a.prompt_tokens + b.prompt_tokens,
    completion_tokens: a.completion_tokens + b.completion_tokens,
    total_tokens: a.total_tokens + b.total_tokens,
  }
  const cached = (u) => Number(u.prompt_tokens_details?.cached_tokens) || 0
  if (a.prompt_tokens_details || b.prompt_tokens_details) out.prompt_tokens_details = { cached_tokens: cached(a) + cached(b) }
  if (a.magpie_cache_unknown || b.magpie_cache_unknown) out.magpie_cache_unknown = true
  return out
}

// continued is an enterprise model's reply carried past Trae's cut. Trae's
// llm_utils_chat ends an enterprise model's reply at exactly TRAE_CUT
// output tokens whatever max_tokens it is sent (top-level, or under
// enterprise_custom_hyper_params, plugins#1366: 32768 sent, 2000 back).
// Trae's own client never asks it for a long reply: its chat with an
// enterprise model is the agent task (create_agent_task), whose cloud
// swaps in Trae's own system prompt and tools, and its own llm_utils_chat
// asks (titles, commit messages, branch names) carry no output limit at
// all (libharness 3.4.22), so there is no field of Trae's own to send.
// So a round that came to the cut with text written and no whole call is
// asked again (more: the request with that text as the assistant's and
// GO_ON after it), and what it answers is sent on as the same reply,
// until a round ends short of the cut, makes a whole call, the asked
// limit is spent, or CUT_ROUNDS is reached. A round cut in its reasoning or
// in a call, nothing written in it, is asked on too once an earlier round
// wrote text to go on from (up to THOUGHT_ROUNDS in a row). A reply whose
// rounds so far only reasoned, no text and no call, is asked again with
// THINK_ON (up to THOUGHT_ROUNDS too), and one that still wrote nothing
// ends as the error reasoned says (plugins#1366, 0.2.52). A call cut
// mid-arguments is dropped from the round it was cut in: the next round
// writes it whole.
// A later round that fails (an error, a stream broken off, nothing written
// short of the cut) ends the asking: the text written stays, and the reply
// ends for length, not as an error. The usage sent is every round's
// together; a reply still cut at the end ends for length.
async function* continued(answer, limit, cut, more, model = "") {
  let text = ""
  let total = null
  let parts = answer
  let thought = 0 // the rounds in a row that wrote no text
  let onlyThought = 0 // the rounds, from the first, that only reasoned
  let why = "" // how the last ask failed, for reasoned
  for (let round = 1; ; round++) {
    let usage = null
    let finish = ""
    let whole = 0
    let wrote = false
    let failed = false
    const held = []
    try {
      for await (const p of parts) {
        if (p.error) {
          // a later ask that failed leaves the reply as Trae cut it
          if (round === 1) {
            yield p
            return
          }
          failed = true
          why = `failed: ${p.error}`
          break
        }
        if (p.usage) {
          usage = p.usage
          continue
        }
        if (p.finish) {
          finish = p.finish
          continue
        }
        if (p.call && !wholeArgs(p.call.arguments)) {
          held.push(p)
          continue
        }
        if (p.call) whole++
        if (p.text) {
          text += p.text
          wrote = true
        }
        yield p
      }
    } catch (e) {
      // a later ask whose stream broke off leaves the reply as Trae cut
      // it, as one that answered an error does: thrown on, the text
      // written went to the agent as a 502 (plugins#1366, 0.2.50); the
      // first ask's is the reply's own failure
      if (round === 1) throw e
      failed = true
      why = `broke off: ${e?.message ?? e}`
    }
    total = addUsage(total, usage)
    const atCut = cut > 0 && Number(usage?.completion_tokens) === cut && (!finish || finish === "length")
    // a later ask that wrote nothing and made no call, short of the cut
    // (only reasoning ended early, or nothing at all), is no end of the
    // reply either: the text before it is still cut (plugins#1366, 0.2.50)
    const answeredNothing = round > 1 && !wrote && !whole && !held.length && !atCut
    const wasCut = failed || answeredNothing || atCut
    const left = limit > 0 ? limit - (Number(total?.completion_tokens) || 0) : 0
    thought = wrote ? 0 : thought + 1
    // a round that only reasoned to the cut, with no text before it: asked
    // again with THINK_ON (more, text "")
    const thinking = !text && atCut && !whole && !held.length
    if (thinking) onlyThought++
    if (answeredNothing && !text && !why) why = "answered nothing"
    const ask = !failed && !answeredNothing && wasCut && (text || thinking) && thought < THOUGHT_ROUNDS && !whole && round < CUT_ROUNDS && (limit <= 0 || left > 0) && more
    const next = ask ? await more(text, left, round + 1).catch(() => null) : null
    if (next) {
      parts = next
      continue
    }
    if (ask && !text) why = "was not answered"
    // asked again (or about to be) and still nothing written: the reply is
    // an error that says why, not an empty one cut for length
    if (!text && onlyThought && (round > 1 || ask) && !whole && !held.length) {
      if (total) yield { usage: total }
      yield { error: reasoned(model, onlyThought, cut, why), code: "reasoning_only" }
      return
    }
    if (!wasCut || round === 1) yield* held
    if (total) yield { usage: total }
    if (wasCut && round > 1) yield { finish: "length" }
    else if (finish) yield { finish }
    return
  }
}

// finishOf is OpenAI's finish_reason for the one Trae's last event gives,
// "" for none it says or one it has no word for
function finishOf(d) {
  const f = String(d?.finish_reason ?? d?.stop_reason ?? d?.finishReason ?? "").toLowerCase()
  if (["length", "max_tokens", "max_output_tokens", "max_length"].includes(f)) return "length"
  if (f === "content_filter" || f === "sensitive") return "content_filter"
  return ""
}

// Thoughts is the reasoning sent on so far: a piece Trae sends again (the
// same one twice in a row, or the reasoning so far, again or with more
// after it) sends only what is new
class Thoughts {
  constructor() {
    this.all = ""
    this.last = ""
  }
  add(r) {
    const last = this.last
    this.last = r
    if (r === last && r.length >= 8) return ""
    if (this.all.length >= 16 && r.length >= 16 && this.all.endsWith(r)) return ""
    if (this.all.length >= 16 && r.startsWith(this.all)) r = r.slice(this.all.length)
    this.all += r
    return r
  }
}

// parts turns Trae's events into what the answer is made of: text,
// reasoning, tool calls, the token counts, the finish, or an error. tools
// are the request's, a call to one named otherwise going on under its name.
async function* parts(events, tools = []) {
  const tt = new TextTools(tools)
  const nc = new NativeCalls()
  const th = new Thoughts()
  const call = (c) => {
    const name = toolNamed(c.name, tools)
    return { call: { ...c, name, arguments: unwrapped(c.arguments, name, tools) } }
  }
  let finish = ""
  // with MAGPIE_TRAE_DEBUG, what Trae sent that nothing here reads: the
  // events of other names, and the string fields of the answer's events
  // past the ones read (plugins#1366, 0.2.51: reasoning_tokens 1983 with
  // reasoning_chars=0 — was the reasoning sent under another name?)
  const unread = traeDebug() ? new Map() : null
  const note = (k, n) => unread && unread.set(k, (unread.get(k) ?? 0) + n)
  try {
    for await (const { event, data } of events) {
      const name = eventName(event)
      const d = data && typeof data === "object" ? data : {}
      if (data === "[DONE]") break
      if (unread) {
        if (!ANSWER.has(name) && !["error", "token_usage", "done", "response_done", "stream_done"].includes(name)) note(`event:${name}`, JSON.stringify(data ?? "").length)
        else if (ANSWER.has(name)) {
          const read = new Set(["reasoning_content", "reasoning", "response", "content", "delta", "finish_reason", "stop_reason", "finishReason"])
          for (const [k, v] of Object.entries(d)) if (!read.has(k) && typeof v === "string" && v) note(`${name || "data"}.${k}`, v.length)
          const dl = d.delta && typeof d.delta === "object" ? d.delta : {}
          for (const [k, v] of Object.entries(dl)) if (!read.has(k) && typeof v === "string" && v) note(`${name || "data"}.delta.${k}`, v.length)
        }
      }
      if (name === "error" || (name !== "output" && d.code && d.message && !d.response && !d.content)) {
        const e = errorOf(d)
        // the realm answering is named by the caller, which knows it; a bare
        // word here reads as neither realm's
        yield { error: e.message || "Trae returned an error", code: e.code, extra: d.extra ?? null, plan: planOf(d) }
        return
      }
      if (name === "token_usage") {
        const u = tokensOf(d.usage ?? d)
        if (u) yield { usage: u }
        continue
      }
      if (name === "done" || name === "response_done" || name === "stream_done") {
        const u = tokensOf(d.usage)
        if (u) yield { usage: u }
        finish = finishOf(d) || finish
        break
      }
      if (!ANSWER.has(name)) continue
      const delta = d.delta && typeof d.delta === "object" ? d.delta : {}
      // the reasoning's own fields, in the order Trae has put it under: an
      // empty one is no answer, so the next is asked (an event carrying both
      // reasoning_content: "" and reasoning: "…" says the thought in the second)
      const said = [d.reasoning_content, d.reasoning, delta.reasoning_content, delta.reasoning].find((v) => typeof v === "string" && v) ?? ""
      if (said) {
        const r = th.add(said)
        if (r) yield { reasoning: r }
      }
      let text = typeof d.response === "string" ? d.response : typeof d.content === "string" ? d.content : typeof delta.content === "string" ? delta.content : typeof d.delta === "string" ? d.delta : ""
      // the IDE's own progress notes, not the model's
      if (/^(Building prompt:|Completed building prompt)/.test(text)) text = ""
      if (text) {
        const r = tt.push(text)
        const t = r.reasoning && th.add(r.reasoning)
        if (t) yield { reasoning: t }
        if (r.text) yield { text: r.text }
        for (const c of r.calls) yield call({ ...c, id: callId() })
        if (r.error) {
          yield { error: r.error, code: null }
          return
        }
      }
      for (const tc of Array.isArray(d.tool_calls) ? d.tool_calls : []) nc.push(tc)
      const u = tokensOf(d.usage)
      if (u) yield { usage: u }
      finish = finishOf(d) || finish
    }
    const r = tt.push("", true)
    const t = r.reasoning && th.add(r.reasoning)
    if (t) yield { reasoning: t }
    if (r.text) yield { text: r.text }
    for (const c of r.calls) yield call({ ...c, id: callId() })
    if (r.error) {
      yield { error: r.error, code: null }
      return
    }
    for (const c of nc.take(tools)) yield call(c)
    if (finish) yield { finish }
  } finally {
    if (unread?.size) console.error(`trae debug: unread ${JSON.stringify(Object.fromEntries(unread))} (chars)`)
  }
}

// first reads events up to the first that is the answer's, so an answer
// that is only an error (signed out, out of credit, a model this account
// lacks) is known before anything is sent on
async function first(it) {
  const held = []
  for (;;) {
    const n = await it.next()
    if (n.done) return { held, done: true }
    held.push(n.value)
    if (!n.value.usage) return { held, done: false }
  }
}

async function* chain(held, it) {
  yield* held
  for (;;) {
    const n = await it.next()
    if (n.done) return
    yield n.value
  }
}

// failure is the response for an error Trae answered with
// ctx, when given, says what was asked: an error that isn't a lapse or a
// quota names it, so a 502 says which model, where and through what
function failure(site, status, code, message, ctx = "") {
  message = message || statusLine(status)
  if (status === 401 || lapsedCode(code, site) || (status === 403 && lapsedWords.test(message))) {
    return errorResponse(401, `${site.realm}'s sign-in has expired (${message}); sign in again`, "expired")
  }
  if (status === 429 || quotaCode(code, site) || (status === 403 && quotaWords.test(message))) return errorResponse(429, `${site.realm}: ${message}`)
  return errorResponse(status >= 400 ? status : 502, `${site.realm}: ${message}${code ? ` (code ${code})` : ""}${ctx ? `; ${ctx}` : ""}`)
}

// the settled turn record fills the two readings token_usage leaves out: the
// credits the turn spent and the cache it really read. A cache the stream
// named wins; the commercial count is only used when the stream gave none.
function withBilling(usage, bill) {
  if (!usage || !bill) return usage
  // magpie's ledger reads the settled charge as `credit` (singular) on the
  // usage object (yetone/magpie#4328, as kiro reports it). Keep `credits`
  // beside it for clients that name it that way.
  if (bill.credits != null) {
    usage.credit = bill.credits
    usage.credits = bill.credits
  }
  if (bill.cacheRead != null && !usage.prompt_tokens_details?.cached_tokens && !usage.cache_read_input_tokens) {
    usage.prompt_tokens_details = { ...(usage.prompt_tokens_details ?? {}), cached_tokens: bill.cacheRead }
    delete usage.magpie_cache_unknown
  }
  return usage
}

// openai is the answer as an OpenAI chat completion: a stream, or one body
// abort, when given, lets the answer's reader close Trae's connection the
// moment the agent goes away (a tool call made, a request cancelled): a
// generator's return can't break a read that is already waiting, so the
// fetch itself is what has to be stopped
async function openai(req, it, abort, site, limit = 0, cut = 0, billing = null) {
  const id = "chatcmpl-" + randomBytes(12).toString("hex")
  const created = Math.floor(Date.now() / 1000)
  const model = req.model
  if (!req.stream) {
    let text = ""
    let reasoning = ""
    const calls = []
    let usage = null
    let finish = ""
    for await (const p of it) {
      if (p.error) return failure(site, 502, p.code, p.error)
      if (p.text) text += p.text
      if (p.reasoning) reasoning += p.reasoning
      if (p.call) calls.push(p.call)
      if (p.usage) usage = p.usage
      if (p.finish) finish = p.finish
    }
    const end = ending(calls, finish, usage, limit, cut)
    if (usage && billing) withBilling(usage, await billing(usage))
    const message = { role: "assistant", content: text || (end.calls.length ? null : "") }
    if (reasoning) message.reasoning_content = reasoning
    if (end.calls.length) message.tool_calls = end.calls.map((c) => ({ id: c.id, type: "function", function: { name: c.name, arguments: c.arguments } }))
    const body = { id, object: "chat.completion", created, model, choices: [{ index: 0, message, finish_reason: end.finish }] }
    if (usage) body.usage = usage
    return new Response(JSON.stringify(body), { status: 200, headers: { "content-type": "application/json" } })
  }
  const enc = new TextEncoder()
  const chunk = (delta, finish = null, extra = {}) => enc.encode(`data: ${JSON.stringify({ id, object: "chat.completion.chunk", created, model, choices: [{ index: 0, delta, finish_reason: finish }], ...extra })}\n\n`)
  // a reply that failed (an error event, or Trae's stream breaking off)
  // ends with the error and [DONE], not a finish that says it stopped; the
  // stream is closed whatever happens, and an agent that goes away stops
  // the reading of Trae's. The realm answering names itself, so a Global
  // account's failure reads as Trae Global's
  const error = (message, code = null) => enc.encode(`data: ${JSON.stringify({ error: { message: `${site.realm}: ${message}`, type: "api_error", code } })}\n\n`)
  let gone = false
  let keep = null
  const stream = new ReadableStream({
    async start(ctl) {
      let calls = 0
      const sent = []
      // a call whose arguments aren't whole JSON is held to the end: only
      // then is it known whether Trae cut the reply in it (ending)
      const held = []
      let usage = null
      let finish = ""
      let failed = false
      let quietFrom = Date.now()
      const put = (b) => {
        quietFrom = Date.now()
        if (!gone) ctl.enqueue(b)
      }
      // an enterprise model's reply may be asked on (continued): the
      // stream is kept alive while the next ask waits (tune.keepEvery)
      keep = cut > 0 ? setInterval(() => {
        if (!gone && Date.now() - quietFrom >= tune.keepEvery) put(enc.encode(": keepalive\n\n"))
      }, tune.keepEvery) : null
      const putCall = (c) => {
        sent.push(c)
        put(chunk({ tool_calls: [{ index: calls++, id: c.id, type: "function", function: { name: c.name, arguments: c.arguments } }] }))
      }
      try {
        put(chunk({ role: "assistant", content: "" }))
        for await (const p of it) {
          if (gone) break
          if (p.error) {
            put(error(p.error, p.code ?? null))
            failed = true
            break
          }
          if (p.text) put(chunk({ content: p.text }))
          if (p.reasoning) put(chunk({ reasoning_content: p.reasoning }))
          if (p.call) {
            if (wholeArgs(p.call.arguments)) putCall(p.call)
            else held.push(p.call)
          }
          if (p.usage) usage = p.usage
          if (p.finish) finish = p.finish
        }
        if (!failed) {
          const end = ending([...sent, ...held], finish, usage, limit, cut)
          if (!end.dropped) for (const c of held) putCall(c)
          put(chunk({}, end.finish))
          // the settled charge is read after the finish, so a bill Trae
          // settles a moment later doesn't hold the answer's end back
          if (usage && billing) withBilling(usage, await billing(usage))
          if (usage) put(enc.encode(`data: ${JSON.stringify({ id, object: "chat.completion.chunk", created, model, choices: [], usage })}\n\n`))
        }
      } catch (e) {
        try {
          put(error(e?.message ?? e))
        } catch {}
      }
      clearInterval(keep)
      try {
        put(enc.encode("data: [DONE]\n\n"))
        if (!gone) ctl.close()
      } catch {}
    },
    cancel() {
      gone = true
      clearInterval(keep)
      abort?.()
      it.return?.()
    },
  })
  return new Response(stream, { status: 200, headers: { "content-type": "text/event-stream", "cache-control": "no-cache" } })
}

// a model or function this account's chat_v3 doesn't take: another may
const wrongFunction = (code) => ["4001", "4023", "1005"].includes(String(code))

// planOf is the plan a refusal names in its extra: Trae CN answers a model
// the account's plan doesn't offer with 1005 and {"plan":2}, though its list
// names the model (plugins#1501: glm-5.4 for a Credits account whose
// glm-5.3 answers). That is the model's refusal, not the account's: it
// goes out as a 403 that says the model isn't available, which magpie
// rests that model alone for, never the account. null when it names none.
function planOf(d) {
  let x = d?.extra
  if (typeof x === "string") {
    try {
      x = JSON.parse(x)
    } catch {
      return null
    }
  }
  return x && typeof x === "object" && x.plan != null ? x.plan : null
}
const planOfText = (text) => {
  try {
    const v = JSON.parse(text)
    return planOf(v?.error && typeof v.error === "object" ? v.error : v)
  } catch {
    return null
  }
}

// keptRefusal is the refusal a request that no function answered ends
// with: a plan's refusal one function gave outlives another's generic one,
// so 1005 {"plan":2} isn't lost behind the last function's 4001
// (plugins#1501). A 1005 naming no plan is kept no longer than before: a
// function may give it for a model it doesn't serve.
const keptRefusal = (why, next) => (why?.plan != null && next.plan == null ? why : next)

// ---- the model lists ------------------------------------------------------------

// chatModel: an entry of a function's list that is a model to chat with.
// The lists also hold the IDE's own helpers (summary, fast_apply, title
// generation: usage other than chat_completion), configs switched off, and
// the slots of custom models, which need a provider bound in the IDE.
//
// An enterprise's own built-in models are the exception: Trae CN's client
// (3.4.20, ai-modules-chat ModelConfigSource) marks each entry's
// config_source Trae 1, Enterprise 2 or Personal 3, and shows the
// Enterprise ones as "Enterprise-builtin" for every seat of the tenant —
// served by Trae with the tenant's provider, so a seat picks them like its
// own. Not being Trae's presets (is_preset false), they come out as custom
// models (is_custom_model) and were dropped with the personal ones, whose
// provider key lives in the user's IDE only (plugins#1258, 0.2.41).
// One the admin switched off (status false) stays out, as in the IDE.
const ENTERPRISE = 2
const enterpriseModel = (m) => Number(m?.config_source) === ENTERPRISE
// enterpriseDetail is the model detail an enterprise model is asked by: its
// __dev one when it names one, else the first that names a model
const enterpriseDetail = (m) => devModel(m) ?? (Array.isArray(m?.model_detail_list) ? m.model_detail_list : []).find((d) => d?.model_name)
// twinId is the id an enterprise model is listed under when a Trae preset
// has its config_name too: its provider, TWIN, then the name, as the
// enterprise console writes it (aliyuncs//kimi-k3.1-pro). Trae CN's lists
// can give one config_name twice, a preset (config_source 1) and the
// tenant's own model (config_source 2) with a provider of its own, and
// Trae's client tells them apart by config_source; keyed by the name alone,
// the preset's __dev entry won the tie and the enterprise one could not be
// asked at all (plugins#1605, shex816: kimi-k3.1-pro, the preset 4222 on
// that seat and its aliyuncs twin served in Trae's client). Only a twin is
// renamed: an enterprise model no preset shares a name with keeps its
// config_name as its id (AI/deekseek-v4.1-flash, #1258), and the preset
// keeps the bare name, which is what a request for it asked before.
const TWIN = "//"
const twinId = (m) => (String(m?.provider || enterpriseDetail(m)?.provider || "").trim() || "enterprise") + TWIN + String(m?.config_name ?? "")
function chatModel(m, site) {
  const id = String(m?.config_name ?? "")
  if (!id) return false
  if (m.usage && m.usage !== "chat_completion") return false
  if (m.config_switch === false) return false
  if (enterpriseModel(m)) return m.status !== false && !(site?.hidesInvisible && m.is_invisible_to_user === true)
  if (/^custom_model/i.test(id)) return false
  if (m.is_custom_model === true || m.display_config?.is_custom_model === true) return false
  // the IDE's own picker hides these: Auto-mode routing channels and
  // pay-as-you-go twins of another entry (gemini-3.1-pro vs -paygo/-auto,
  // the search_agent family), not entries to pick by hand
  if (site?.hidesInvisible && m.is_invisible_to_user === true) return false
  return true
}

// seesOf is whether a list's entry says its model takes images: Trae's
// lists mark each one multimodal true or false (Doubao-Seed, Kimi K3,
// Qwen 3.7 Plus take them; GLM-5 and DeepSeek V4 don't). null when the
// entry doesn't say.
const seesOf = (m) => (typeof m?.multimodal === "boolean" ? m.multimodal : typeof m?.display_config?.multimodal === "boolean" ? m.display_config.multimodal : null)

// devModel is the model an entry serves requests with: its __dev one
const devModel = (m) => (Array.isArray(m?.model_detail_list) ? m.model_detail_list : []).find((d) => /__dev$/.test(String(d?.model_name ?? "")))

// maxModel is a model's Max mode, from the entries its lists give it (the
// one it is asked through first): the first __max model one names, and the
// window context_window_tokens.max gives it, when that is bigger than dev's.
// The lists needn't agree: chat_v3 can name the __max model while the SOLO
// list the model is asked through names only __dev, and the window can be
// another entry's again. A model with no __max, or no bigger window, has no
// Max.
const maxModel = (...ms) => {
  const details = (m) => (Array.isArray(m?.model_detail_list) ? m.model_detail_list : [])
  const at = ms.find((m) => details(m).some((d) => /__max$/.test(String(d?.model_name ?? ""))))
  if (!at) return null
  const d = details(at).find((d) => /__max$/.test(String(d?.model_name ?? "")))
  const first = (k) => [at, ...ms].map((m) => Number(m?.context_window_tokens?.[k]) || 0).find((n) => n > 0) || 0
  const window = first("max")
  return window > first("dev") ? { name: String(d.model_name), most: Number(d.max_tokens) || 0, window, entry: at } : null
}

// MAX is the suffix of a model's Max: deepseek-v4.1-flash-max is
// deepseek-v4.1-flash in Max mode
const MAX = "-max"

// WIDENED is, per site, the models whose base entry was measured serving a
// prompt past its dev budget: only these advertise the Max window on the base
// entry (yetone/magpie#5809). A model without that evidence keeps its dev
// budget, which can only make an agent compact early. Every measurement was
// on Trae CN; Trae Global is its own deployment and none of its models was
// measured, so it keeps dev. Extend it as models are tested.
const WIDENED = { "trae-cn": new Set([
  "deepseek-v4.1-flash",
  "deepseek-v4-flash",
  "glm-5.4",
  "glm-5.3",
  "glm-5.3-flash",
  "glm-5.3-flashx",
  "glm-5.2",
  "doubao-seed-2.1-pro",
  "doubao-seed-evolving",
]) }

  // traeRateOf is a model's consumption multiplier, from the account's list:
  // display_contact_config is a JSON string naming the rate now and the full
  // price, and an activity's off-peak windows, which are computed here rather
  // than trusted from the snapshot the list was read at (a list fetched in
  // the morning would otherwise say the day price all evening).
  const traeRateOf = (m, now = Date.now()) => {
    // A field written badly (an unknown time_zone throws in Intl) must cost
    // this model its rate alone: this runs inside modelOf, whose caller falls
    // back to the static list on a throw, losing every model of the list.
    const read = (raw) => {
      if (!raw) return {}
      let cfg
      try { cfg = typeof raw === "string" ? JSON.parse(raw) : raw } catch { return {} }
      if (!cfg || typeof cfg !== "object") return {}
      const num = (x) => (x === null || x === "" || x === undefined ? undefined : Number.isFinite(Number(x)) ? Number(x) : undefined)
      const activity = cfg.activity_discount
      const offPeak = activity?.data?.off_peak
      const windows = Array.isArray(offPeak?.time_windows) ? offPeak.time_windows : []
      // enable: false says the rate is not in force; the list may keep a
      // stale data.rate there, so it is not shown.
      let rate = cfg.consumption_rate?.enable === false ? undefined : num(cfg.consumption_rate?.data?.rate)
      // A member discount runs alongside consumption_rate, which keeps the
      // price before it (0.78 while discount.data.consumption_rate is 0.58):
      // the discounted price is the one to show.
      const discount = cfg.discount
      if (discount?.enable) {
        const after = num(discount?.data?.consumption_rate)
        if (after !== undefined) rate = after
      }
      const was = num(activity?.data?.current?.before_consumption_rate)
        ?? num(offPeak?.before_consumption_rate)
        ?? num(discount?.data?.original_consumption_rate)
      if (activity?.enable && windows.length) {
        const zone = typeof offPeak?.time_zone === "string" && offPeak.time_zone ? offPeak.time_zone : "Asia/Shanghai"
        rate = inWindows(windows, zone, now)
          ? num(offPeak?.after_consumption_rate) ?? rate
          : num(offPeak?.before_consumption_rate) ?? rate
      }
      return {
        ...(rate !== undefined ? { rate } : {}),
        ...(rate !== undefined && was !== undefined && was > rate ? { rateWas: was } : {}),
      }
    }
    try {
      return read(m?.display_contact_config)
    } catch {
      // a bad window costs the rate only; give back what the plain field says
      try {
        const cfg = typeof m?.display_contact_config === "string" ? JSON.parse(m.display_contact_config) : m?.display_contact_config
        const plain = cfg?.consumption_rate?.enable === false ? undefined : Number(cfg?.consumption_rate?.data?.rate)
        return Number.isFinite(plain) ? { rate: plain } : {}
      } catch { return {} }
    }
  }

  // inWindows says whether now falls in one of the windows, as the list
  // spells them: weekdays 1–7 (Monday first), minutes from midnight, and
  // the window's own time zone.
  const inWindows = (windows, timeZone, now) => {
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone, weekday: "short", hour: "2-digit", minute: "2-digit", hourCycle: "h23",
    }).formatToParts(new Date(now))
    const get = (t) => parts.find((p) => p.type === t)?.value
    const weekday = { Sun: 7, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }[get("weekday")]
    const hour = Number(get("hour"))
    const minute = Number(get("minute"))
    if (!Number.isFinite(weekday) || !Number.isFinite(hour) || !Number.isFinite(minute)) return false
    const mins = hour * 60 + minute
    return windows.some((w) => Array.isArray(w?.weekdays) && w.weekdays.includes(weekday)
      && Number.isFinite(w.start_minute) && Number.isFinite(w.end_minute)
      && mins >= w.start_minute && mins < w.end_minute)
  }


// ---- reasoning levels --------------------------------------------------------------
//
// A list entry carries a reasoning_effort_config: the levels its model takes
// (light, high, extra_high) and the one it defaults to. The request takes the
// same names, as reasoning_effort, so a level an agent picks is sent as Trae
// spells it. OpenCode knows the three as low/high/xhigh, so the map goes both
// ways. Trae's client names two more, medium and max (its bundle's
// reasoning_effort.{low,medium,high,extra_high,max}), handed out per model,
// so they are spelled here too, and offered only for a model whose entry
// names them. No list seen yet names either: TRAE CN's app offers DeepSeek
// V4.1 Flash 轻/高/极高 (light/high/extra_high) alone, and its "Max" is the
// 更大上下文 (Max) 1M-window switch, which is the model id + MAX below, not a
// level (#434's screenshot).
//
// TRAE CN's 极高 (extra_high) is the top of a model that names no max of its
// own — DeepSeek-V4.1-Flash, GLM-5.3 and Kimi-K3 offer 轻/高/极高 — so it is
// that model's max too (@avalongarden6 on X, 11-09). Offered as xhigh alone,
// such a member ranged 低–很高 beside WorkBuddy's and Qoder's …–最高 in a
// routing group, and the group, which offers the levels its members share,
// lost max for every member. So such a model is offered max as well, and max
// is sent as extra_high (topsAtXhigh). An entry that names Trae's own max
// keeps it: max is max and extra_high is xhigh.
//
// An entry without the config takes no level: Trae serves it at its own
// default and nothing is sent. The plugin used to send none for every model,
// which read as "Trae takes no level" — it takes them, per model, and an
// entry that names none is the exception rather than the rule.
const LEVELS = { light: "low", medium: "medium", high: "high", extra_high: "xhigh", max: "max" }

// levelsOf is an entry's levels in OpenCode's names, in Trae's order: [] when
// the entry names none, null when it names ones this map can't spell (so a
// caller can tell "takes no level" from "takes a level we can't name").
const levelsOf = (m) => {
  const cfg = m?.reasoning_effort_config
  if (!cfg || typeof cfg !== "object") return []
  const options = Array.isArray(cfg.options) ? cfg.options : []
  const known = options.filter((o) => typeof o === "string" && LEVELS[o])
  return known.length ? known.map((o) => LEVELS[o]) : options.length ? null : []
}

// variantsOf is a model's levels as OpenCode's variants. The value is the
// effort OpenCode puts in the request body, so it names the level the way this
// plugin's levels do: an agent in OpenCode writes `reasoning_effort` straight
// from it, and effortOf below turns that name into Trae's. Naming Trae's
// spelling here would make the body say "light", which is not one of the
// levels this plugin offers, and the field would then be dropped. {} when the
// model takes none.
const variantsOf = (levels) => Object.fromEntries(offered(levels).map((level) => [level, { reasoningEffort: level }]))

// topsAtXhigh: the entry's top level is extra_high, with no max of its own
const topsAtXhigh = (levels) => Array.isArray(levels) && levels.includes("xhigh") && !levels.includes("max")

// offered is the levels agents are offered for a model: its own, and max
// beside an extra_high that is its top (sent as extra_high, effortOf)
const offered = (levels) => (topsAtXhigh(levels) ? [...levels, "max"] : levels ?? [])

// effortOf is the name to send Trae for an effort the request carries, or
// undefined when the model doesn't take that one: a level Trae has no entry for
// is rejected, so nothing is sent instead. The effort arrives in either
// spelling — this plugin's own (low/high/xhigh) from its variants, or Trae's
// (light/extra_high) from a client that read them off the list — and both name
// the same level. max is sent as extra_high to a model whose top that is.
const effortOf = (levels, effort) => {
  if (typeof effort !== "string" || !levels) return undefined
  const mine = Object.values(LEVELS).includes(effort) ? effort
    : Object.prototype.hasOwnProperty.call(LEVELS, effort) ? LEVELS[effort]
    : undefined
  if (mine === "max" && topsAtXhigh(levels)) return "extra_high"
  if (mine === undefined || !levels.includes(mine)) return undefined
  return Object.keys(LEVELS).find((k) => LEVELS[k] === mine)
}

// ---- usage ------------------------------------------------------------------------

// credits adds up the account's entitlement packs as the IDE shows them:
// each pack with a credit limit (-1 unlimited) and what it used. until is
// the soonest end of a pack that still has credits left and has not ended:
// a spent daily pack or one already past its end changes nothing on the
// account, so it does not name the date the credits turn over (#718, #1157).
function credits(v, now = Date.now()) {
  let limit = 0
  let used = 0
  let unlimited = false
  let soonest = 0
  let lapsing = 0
  for (const p of v?.user_entitlement_pack_list ?? []) {
    const bi = p?.entitlement_base_info ?? {}
    const l = Number(bi?.quota?.credits_limit)
    if (!Number.isFinite(l)) continue
    const u = Number(p?.usage?.credits_amount) || 0
    if (l === -1) unlimited = true
    else if (l >= 0) limit += l
    if (u > 0) used += u
    const end = whenOf(bi.end_time ?? bi.expire_time ?? p.end_time)
    const left = l === -1 || (l > 0 && u < l)
    if (!(end && end > now && left)) continue
    // what a finite pack has left is lost at its end, whether or not a
    // new pack follows: lapsing is the credits that go at the soonest end
    // (#718: a TraeCode CN account's sign-in rewards are 31-day packs of
    // 100, one a day)
    const rest = l === -1 ? 0 : Math.max(0, l - Math.max(0, u))
    if (!soonest || end < soonest) (soonest = end), (lapsing = rest)
    else if (end === soonest) lapsing += rest
  }
  return { limit, used, unlimited, until: soonest, lapsing }
}

const round = (n) => Math.round(n * 100) / 100

// yuan is money as Trae CN's console counts it, in yuan. The consumer
// window's unit is a bare word ("credits"); a currency the card can't name
// in a unit goes in display, as Cursor's and JoyCode's do.
const yuan = (n) => "¥" + Number(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })

// dollars is the same money as the international console counts it. The
// console's own build picks the symbol by deployment (volcengine ¥,
// byteplus $), so each realm's console is asked with its own.
const DOLLARS = (n) => "$" + Number(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })

// seatUsageWindow is the seat pool's window, which both realms' consoles
// name the same way: the pool as the limit and the models' own cost as what
// was spent, in the realm's money, resetting when the console's period does.
// The count rides on the window (amount of limit), as the consumer window's
// does, so magpie says it in the window's row; display carries the currency
// the card's own row can't name (yetone/magpie#694).
//
// A spend the console did not answer (used === null) is not a spend of
// nothing: the window says no percent and no amount, and its display names
// the pool with a question mark, so magpie reads the account as unknown
// rather than as one that has spent none of its allowance.
function seatUsageWindow(pool, used, until, money, unit) {
  const w = {
    name: "Seat Usage",
    display: used === null ? `? / ${money(pool.limit)}` : `${money(used)} / ${money(pool.limit)}`,
    limit: round(pool.limit),
    unit,
  }
  if (used === null) w.used = null
  else {
    w.used = Math.round(Math.max(0, Math.min(100, (used / pool.limit) * 100)) * 100) / 100
    w.amount = round(used)
  }
  if (until) w.resetsAt = until
  return w
}

// PAYGO_UNLIMITED is the console's "no limit": a pay-as-you-go pool is
// handed this instead of a real one (9999999999), which is not a limit a
// card should show. The seat pool is the limit that matters.
const PAYGO_UNLIMITED = 1e9

// seatPoolOf reads an enterprise account's allowance as its console has it:
// the seat pool, in the realm's money (seat_pool_currency_quota). A pool the
// console hands PAYGO_UNLIMITED is no limit at all, as the consumer page's
// -1 is. A pool the console names as null or "" is no pool either: Number()
// would read both as 0, which would draw an allowance of nothing rather than
// say the console named none.
function seatPoolOf(v) {
  const q = v?.user_model_quota
  if (!q) return null
  const raw = q.seat_pool_currency_quota
  if (raw === null || raw === undefined || raw === "") return null
  const limit = Number(raw)
  if (!Number.isFinite(limit)) return null
  if (limit < 0 || limit >= PAYGO_UNLIMITED) return { limit: 0, unlimited: true }
  return { limit, unlimited: false }
}

// seatSpentOf adds up what an enterprise account's models cost, in the
// realm's money: each model's total_cost_currency in the seat's usage
// detail. The console gives no total of its own
// (seat_total_cost_currency is null), so this is the sum, and a model the
// answer leaves out costs nothing.
//
// Only the account's own seat is counted. The console answers an
// administrator with every seat in the tenant, and adding those up would
// show one person's card the whole tenant's spend; the account's own seat is
// the one the quota names (user_model_quota.user_id), which a real console
// sends. A seat the account's cannot be told apart — several seats and no id
// to pick by — is not guessed at.
//
// null when there is nothing to add up honestly: no usage list at all (the
// read failed, and a failed read is not a spend of zero), or several seats
// with no way to say which is the account's.
function seatSpentOf(v, uid) {
  const list = v?.user_usage_list
  if (!Array.isArray(list)) return null
  const me = uid === undefined || uid === null || uid === "" ? null : String(uid)
  const ids = new Set(list.map((u) => (u?.user_id === undefined || u?.user_id === null ? "" : String(u.user_id))).filter((s) => s !== ""))
  let seats = list
  if (ids.size > 0) {
    // the seats carry ids: take the account's own. With no id from the quota,
    // a single seat's answer is that seat; several seats' is not knowable.
    const want = me ?? (ids.size === 1 ? [...ids][0] : null)
    if (want === null) return null
    seats = list.filter((u) => String(u?.user_id ?? "") === want)
    if (seats.length === 0) return null
  }
  let used = 0
  for (const u of seats) {
    for (const m of u?.in_seat_detail?.chat_usage_details ?? []) {
      const c = Number(m?.total_cost_currency)
      if (Number.isFinite(c) && c > 0) used += c
    }
  }
  return used
}

// entResetOf is when an enterprise account's seat pool refills, as an ISO
// string: the console's ResetTime. The usage page reads the same field for
// its "席位额度将于 <date> 重置" line, so the card and the page name one
// date. whenOf reads it, which takes the milliseconds the console sends and
// the seconds a stand-in may. Absent when the console gives none.
function entResetOf(v) {
  const t = whenOf(v?.Data?.ResetTime)
  return t > 0 ? new Date(t).toISOString() : null
}

// isEnterprise: the sign-in named the realm's enterprise console as the
// account's host, which is what an enterprise (SaaS) sign-in does — the
// console serves that account's models and holds its usage. A personal
// account names the consumer hosts, or none.
function isEnterprise(a, site) {
  const named = String(site?.consoleHost ?? "").toLowerCase()
  if (!named || !a?.host) return false
  try {
    return new URL(String(a.host)).hostname.toLowerCase() === named
  } catch {
    return false
  }
}

// dollarUsageOf reads an account's entitlement pack as the dollar billing
// has it (the international deployment): the period's allowance in dollars
// (basic_usage_limit plus bonus_usage_limit) and what was used of each
// (basic_usage_amount, bonus_usage_amount). null when the answer carries no
// pack.
function dollarUsageOf(v) {
  const pack = (v?.user_entitlement_pack_list ?? []).find((p) => p?.usage || p?.entitlement_base_info?.quota)
  const quota = pack?.entitlement_base_info?.quota
  if (!pack || !quota) return null
  const basic = Number(quota.basic_usage_limit) || 0
  const bonus = Number(quota.bonus_usage_limit) || 0
  const used = Number(pack.usage?.basic_usage_amount) || 0
  const usedBonus = Number(pack.usage?.bonus_usage_amount) || 0
  const end = whenOf(pack.entitlement_base_info.end_time)
  return { plan: String(pack.display_desc ?? ""), basic, bonus, used, usedBonus, end }
}

// ---- the plugin ---------------------------------------------------------------------

const makePlugin = (site) => async ({ client }) => {
  // renewals under way, one to a refresh token (Trae spends it once), and
  // the last each account got here, so a sign-in from before it is given
  // that one rather than spending the token again
  const renewing = new Map()
  const renewed = new Map()
  // the chat function that served each account last
  const fnOf = new Map()
  // the chat function whose model list has each model, and the __dev
  // model it names there
  const listedBy = new Map()
  const modelNames = new Map()
  // the Max each model the list last read has (null: none)
  const maxes = new Map()
  // whether each model the list last read takes images (its multimodal)
  const sight = new Map()
  // the entry the lists last gave each model, for what only the entry says:
  // the reasoning levels it takes (reasoning_effort_config)
  const liveEntry = new Map()
  const liveEntryOf = (id) => liveEntry.get(String(id)) ?? site.models?.[String(id)]?.entry ?? null
  // the id each entry of the last read is listed under (idOf): its
  // config_name, or an enterprise twin's twinId; and each preset that has
  // an enterprise twin, by its id, so a refusal of the preset names the twin
  const listedAs = new WeakMap()
  const idOf = (m) => listedAs.get(m) ?? String(m.config_name)
  const twins = new Map()
  // when each account's list was last read, and what that read returned:
  // {at, p, done, expired}. A read that answered, failed or hung all leave
  // their stamp, so a list that fails or leaves the model out costs one read
  // per REREAD_MS rather than one per request. The promise is kept beside the
  // stamp because a caller that arrives while a read is in flight must ride
  // THAT read, not start a second and not skip the answer it was about to
  // learn: agents send parallel requests at a session's start (a title request
  // beside the first turn, subagents), and a caller that skipped the entry a
  // read just produced would send a Max out under the agent's own id, which
  // Trae's list doesn't name.
  //
  // The record is the thing the promise resolves to, so a joiner sees the same
  // outcome the read settled on — including an expiry it hit — rather than the
  // bare `null` a failed read answers. One account per key; a read is that
  // account's.
  const readAt = new Map()
  // runRead starts the one read behind readList and answers its record. `p`
  // resolves to that record — not to the models — so a caller that joins a
  // read in flight sees the same outcome the read settled on, an expiry
  // included, rather than the bare null a failed read answers.
  const runRead = (a, who) => {
    const rec = { at: Date.now(), p: null, done: undefined, expired: null }
    // the record goes in BEFORE the read starts, so a caller arriving during it
    // finds `rec.p` and joins; `p` resolves to this same record
    readAt.set(who, rec)
    const body = (async () => {
      try {
        return await liveModels(a)
      } catch (e) {
        // a request's read swallows this (the chat can still answer); a caller
        // that must hear it reads `expired` off the record. Recorded on the
        // record, so a joiner hears it too.
        if (e instanceof Expired) rec.expired = e
        return null
      }
    })()
    // every rejection is claimed here, at creation: a read nobody awaits (the
    // host's refresh ending early, a caller that walked away) must not surface
    // as an unhandled rejection. `p` itself never rejects — the expiry rides on
    // the record instead.
    body.catch(() => {})
    rec.p = body.then((models) => {
      // only this read settles its own record: a later read may have replaced it
      if (readAt.get(who) === rec) {
        rec.at = Date.now()
        rec.done = models ?? []
        rec.p = null
      }
      return rec
    })
    rec.p.catch(() => {})
    return rec.p
  }
  // readList answers the models of the read this caller rode on (its own, or
  // the one in flight, whose record it waits for and then reads), and whether
  // that read found the account lapsed. The record is the account's, not the
  // token's: a re-sign-in is the same account's list, and the host's refresh is
  // strict, so it reads again rather than serving a cached lapse. A request
  // path only reaches here for a model it has no entry for, and that read is
  // the one that fills the entry in.
  //
  // The lapse is answered, not thrown: several callers can ride one read, and a
  // throw out of a shared promise surfaces once as an unhandled rejection for
  // the callers that did not expect it. Each caller decides — provider.models
  // raises it, a request path keeps going. `strict` only says whether a cached
  // lapse is worth reading again for (the host wants the truth; a request does
  // not pay a round trip to learn it).
  const readList = async (a, { strict = false } = {}) => {
    const who = a.uid || a.name || String(site.id)
    const was = readAt.get(who)
    let rec
    if (was === undefined) rec = await runRead(a, who)
    else if (was.p) rec = await was.p
    else if (was.done === undefined || Date.now() - was.at >= REREAD_MS) rec = await runRead(a, who)
    else if (strict && was.expired) rec = await runRead(a, who)
    else rec = was
    return { models: rec.done, expired: rec.expired }
  }

  // the enterprise seats whose console turned a chat away (4245) in this
  // run, by account: the mark is kept with the sign-in too, and this holds
  // it when that save fails
  const consoleRefused = new Set()
  // hostOf is the account's model host, with that mark applied
  const hostOf = (a) => {
    const h = apiOf(a, site)
    if (site.hosts.console && h === site.hosts.console && consoleRefused.has(a.uid || a.name)) return site.hosts.api
    return h
  }
  // onConsole: the host is the enterprise console, where a 4245 is the
  // seat's console refusing chats rather than this model or function
  const onConsole = (host) => !!site.hosts.console && host === site.hosts.console && host !== site.hosts.api
  const consoleRefuses = (code) => String(code) === "4245"

  // askedOf says what a refused chat asked for: the model, the functions
  // tried and the host, and whether the account's list has the model at all.
  // A model typed in by hand that the list doesn't name is the likeliest
  // cause of a refusal, and the list is read for it (once per REREAD_MS)
  // only on this failing path.
  const askedOf = async (a, id, entry, fns, host) => {
    let listed = !!entry && liveEntry.has(id)
    if (!listed) {
      await readList(a).catch(() => {})
      entry = liveEntry.get(id) ?? null
      listed = !!entry
    }
    const kind = enterpriseModel(entry) ? "enterprise built-in model" : "model"
    let out = `${kind} ${id} asked through ${fns.join(", ")} on ${host.replace(/^https?:\/\//, "")}`
    if (!listed && liveEntry.size) out += `; this account's model list doesn't have ${id}, so Trae may not serve it under that id`
    else if (!enterpriseModel(entry) && twins.has(id)) out += `; this account's enterprise has a model of its own named ${id}, listed as ${twins.get(id)}`
    return out
  }

  const save = async (auth) => {
    try {
      await client?.auth?.set?.({ path: { id: site.id }, body: auth })
    } catch {}
  }

  const renew = (a, keep) => {
    const key = a.refresh
    let r = renewing.get(key)
    if (!r) {
      r = (async () => {
        const x = await renewal(a, site)
        const got = { ...a, token: x.token, refresh: x.refresh, expires: x.expires || jwtExp(x.token) || Date.now() + DAY, clientId: x.clientId || a.clientId, renewed: true }
        if (x.devicePrivateKey) Object.assign(got, { devicePublicKey: x.devicePublicKey, devicePrivateKey: x.devicePrivateKey })
        renewed.set(a.uid || a.name, { was: a.refresh, got })
        if (keep) await save(toAuth(got, site))
        return got
      })().finally(() => renewing.delete(key))
      renewing.set(key, r)
    }
    return r
  }

  // fresh is the account with a token that has a while to go, renewed
  // when it hasn't
  const fresh = async (getAuth) => {
    let a = fromAuth(await getAuth(), site)
    if (!a) throw new Expired(`${site.realm}: not signed in`)
    // a renewal the sign-in doesn't hold yet. A device-bound one keeps the
    // refresh token, so the token tells it, and it is renewed in its turn
    if (newerHere(a)) a = { ...renewed.get(a.uid || a.name).got, renewed: false }
    if (!a.expires || a.expires - Date.now() > EARLY_MS || !a.refresh) return a
    try {
      return await renew(a, true)
    } catch (e) {
      // a hiccup: the token in hand may still do
      if (!(e instanceof Expired) && a.expires > Date.now()) return a
      throw e
    }
  }

  // refresh is magpie's auth.refresh: the token renewed LEAD_MS before its
  // end, as the fields that changed
  const refresh = async (auth) => {
    const a = fromAuth(auth, site)
    if (!a || !a.refresh) return undefined
    const last = renewed.get(a.uid || a.name)
    // a device key made for the account is kept with the sign-in
    const out = (s) => ({
      access: s.token,
      refresh: s.refresh,
      expires: s.expires,
      ...(s.devicePrivateKey && s.devicePrivateKey !== a.devicePrivateKey ? { devicePublicKey: s.devicePublicKey, devicePrivateKey: s.devicePrivateKey } : {}),
    })
    if (newerHere(a)) return out(last.got)
    return out(await renew(a, false))
  }

  // newerHere: this account was renewed here since the sign-in a was read
  // from, to a token that runs longer
  const newerHere = (a) => {
    const last = renewed.get(a.uid || a.name)
    return !!last && last.was === a.refresh && last.got.token !== a.token && (last.got.expires || 0) > (a.expires || 0)
  }

  // post asks one of Trae's JSON pages with the account
  const post = async (a, url, body) => {
    const res = await fetch(url, { method: "POST", headers: ideHeaders(a, site, { Accept: "application/json" }), body: JSON.stringify(body), signal: AbortSignal.timeout(20_000) })
    const text = await res.text()
    return { status: res.status, text, v: parseJSON(text) }
  }

  // ownRequest sends a request for one of Trae CN's own JSON pages as the
  // account, as its IDE does: magpie asks the daily check-in
  // (/trae/api/v2/ug/checkin_credits/status, then /claim) through the
  // account's fetch, as it does WorkBuddy's. Trae's answer comes back as it
  // is; a token it turned away (401, or code 1001 in a 200) marks the
  // sign-in, as usage does.
  const ownRequest = async (getAuth, a0, url, method, body, signal) => {
    let a
    try {
      a = await fresh(getAuth)
    } catch (e) {
      if (e instanceof Expired) return errorResponse(401, `${a0.name || a0.uid}: ${e.message}`, "expired")
      throw e
    }
    // a growth page (the check-in) goes as the IDE sends it: its headers,
    // a client's User-Agent, and {req_source: 1} for an empty body. Every
    // check-in sent with Bun's User-Agent came back 9074, with the chat's
    // headers and {} (0.1.6, 0.1.9) as with the IDE's (0.1.7)
    // (yetone/magpie#808). Other pages go with the chat's headers.
    const ug = ugPage(url)
    let sent = method === "GET" || method === "HEAD" ? undefined : typeof body === "string" ? body : "{}"
    if (ug && sent !== undefined && /^\s*(\{\s*\})?\s*$/.test(sent)) sent = JSON.stringify({ req_source: 1 })
    // the account this machine's own Trae CN client is signed in as checks
    // in on the client's device, the one Trae registered: on one account
    // the client's own claim went through while the plugin's, on a device
    // it had made up, came back 9074 (yetone/magpie#808, #1920). Every
    // other account keeps its own device; none is given the client's.
    const deviceId = ug && site.id === "trae-cn" ? await clientDevice(a.uid) : undefined
    const own = deviceId ? { deviceId, ...thisMachine() } : undefined
    // every other Trae CN account checks in on its own device, in the
    // 15-digit shape Trae CN takes (ugDevice, #194, plugins#709)
    if (ug && site.id === "trae-cn" && !own) a = { ...a, deviceId: ugDevice(a) }
    const res = await fetch(url, {
      method,
      headers: ug ? ugHeaders(a, site, { Accept: "application/json" }, own) : ideHeaders(a, site, { Accept: "application/json" }),
      body: sent,
      signal: signal ?? AbortSignal.timeout(20_000),
    })
    const text = await res.text()
    const lapsed = res.status === 401 || lapsedCode(errorOf(text).code, site)
    const headers = { "content-type": res.headers.get("content-type") ?? "application/json", "X-Magpie-Sign-In": lapsed ? "expired" : a.renewed ? "renewed" : "kept" }
    return new Response(text, { status: res.status, headers })
  }

  // checkinStatus reads the check-in's status page: its body, or an outcome
  // to give back as it is (a turned-away sign-in, Trae's own error, a reply
  // that isn't one). checkin reads it before the claim, and again after it.
  const checkinStatus = async (getAuth, a0) => {
    const res = await ownRequest(getAuth, a0, site.hosts.auth + site.checkin.status.path, "POST", "{}")
    const text = await res.text()
    let body
    try { body = JSON.parse(text) } catch {}
    if (!body || typeof body !== "object" || Array.isArray(body)) return { outcome: { outcome: "failed", message: `check-in status: unreadable reply ${text.trim().slice(0, 120) || "(empty)"}` } }
    const e = errorOf(body)
    if (res.status === 401 || lapsedCode(e.code, site)) return { outcome: { outcome: "failed", message: e.message || `${a0.name || a0.uid}: Trae's sign-in has expired` } }
    if (res.status !== 200 || (e.code && String(e.code) !== "0")) return { outcome: { outcome: "failed", message: e.message || statusLine(res.status) } }
    return { body }
  }

  const checkin = async (getAuth) => {
    if (!site.checkin) return { outcome: "inactive", message: `${site.realm} has no daily check-in` }
    const a0 = fromAuth(await getAuth(), site)
    if (!a0) return { outcome: "failed", message: "not signed in" }
    const first = await checkinStatus(getAuth, a0)
    if (first.outcome) return first.outcome
    const body = first.body
    if (body.checked_in) return { outcome: "done", ...(Number(body.credits) > 0 ? { credit: Number(body.credits) } : {}) }
    if (!body.enable) return { outcome: "inactive" }
    const read = async (res) => {
      const text = await res.text()
      let v
      try { v = JSON.parse(text) } catch {}
      return { claim: res, claimText: text, answer: v, ce: errorOf(v) }
    }
    let { claim, claimText, answer, ce } = await read(await ownRequest(getAuth, a0, site.hosts.auth + site.checkin.claim.path, "POST", "{}"))
    // A 9074 on an account no Trae CN client here is signed in as is
    // claimed once more, at once, as the tools that check such accounts in
    // send it (clientShape, plugins#709, #722) — once, never on another
    // code, and never for an account that rode its own client's device. A
    // 9074 means Trae took nothing, so the second claim can't take the day
    // twice; what it answers is the day's answer, read the same way.
    let again = ""
    if (String(ce.code) === "9074" && site.id === "trae-cn" && a0.uid && !(await clientDevice(a0.uid))) {
      let a
      try {
        a = await fresh(getAuth)
      } catch (e) {
        if (!(e instanceof Expired)) throw e
      }
      if (a) {
        ;({ claim, claimText, answer, ce } = await read(await fetch(site.hosts.auth + site.checkin.claim.path, { method: "POST", headers: clientShapeHeaders(a), body: "{}", signal: AbortSignal.timeout(20_000) })))
        again = "; claimed again in the request Trae CN's client-less check-in tools send"
      }
    }
    if (claim.status === 401 || lapsedCode(ce.code, site)) return { outcome: "failed", message: ce.message || `${a0.name || a0.uid}: Trae's sign-in has expired` }
    // 9095: this device is in for today, whoever took it — the day's answer
    if (String(ce.code) === "9095") return { outcome: "ineligible", message: `${ce.message || "this device has checked in today"} (${await deviceNote(a0.uid)}${again})` }
    // 9074: Trae did not take this claim for this account's device. Its own
    // words say the pool is busy, which measurements do not bear out: the
    // same account, token and headers were taken on a 16-digit id where a
    // 19-digit one got 9074 (plugins#194), on 2026-10-23 the same
    // account and headers were taken on a device id Trae had never seen
    // while this account's own id answered 9074, and on 2026-11-05 a
    // 16-digit id got 9074 where 15 digits were taken (plugins#709, so the
    // claim goes on 15 now: ugDevice). So the message says what
    // Trae said and that the device is what it refused, rather than
    // sending people to check in in Trae CN's app, which is not where the
    // problem is. Its own device is never rotated: an account with no
    // client here gets one more claim in the client-less tools' request,
    // on the one id they make from its uid (above), and nothing after
    // that. Nothing is said of signing a client in: on a claim that
    // already rode a client's device it is what the user did — the
    // advice would only send them back to do it again. What it
    // does say, after both 9074 and 9095, is which device the claim went
    // on and why (deviceNote): moxuanchen (plugins#436) had to run
    // clientDevice by hand to learn that the account Trae CN took (A, 100
    // credits) rode the client's device and the one it refused 9074 (B)
    // rode magpie's own, since both of that machine's profiles were A's.
    if (String(ce.code) === "9074") return { outcome: "ineligible", message: `${ce.message} (9074) — Trae CN did not take this check-in for this account's device (${await deviceNote(a0.uid)}${again})` }
    if (claim.status !== 200 || (ce.code && String(ce.code) !== "0")) return { outcome: "failed", message: ce.message || statusLine(claim.status) }
    if (!answer || typeof answer !== "object" || Array.isArray(answer)) return { outcome: "failed", message: `check-in claim: unreadable reply ${claimText.trim().slice(0, 120) || "(empty)"}` }
    // a claim's own code 0 is not proof the day is in: Trae answers it for
    // a claim that registered nothing, which cli2api works around by asking
    // the status again (internal/providers/trae/checkin.go). So success is
    // what the status page says after the claim, and one that didn't land
    // is never reported as claimed.
    //
    // Nor is it a `failed`. magpie retries a failed check-in with backoff
    // for the rest of the day, up to every 30 minutes, and each retry is
    // another claim: a claim answered code 0 while the status still says
    // the day is out is the very case that would multiply, since code 0
    // for a claim that registered nothing is this plugin's own premise —
    // an account that claimed once a day would claim many times. A status
    // that lags a claim that did land reads as not in once, which is a
    // false failure and a second claim. So once a claim has been sent,
    // what the read-back says is the day's answer and nothing is claimed
    // again: `ineligible`, as a 9095 is. A read-back that itself comes to
    // nothing — the network, an answer that isn't one — is the same: the
    // claim was made, and whether the day is in is not known, so it is
    // read again on the next press rather than claimed again.
    const noMore = (o) => (o.outcome === "failed" ? { outcome: "ineligible", message: `${o.message} — nothing is claimed again today` } : o)
    const back = await checkinStatus(getAuth, a0)
    if (back.outcome) return noMore(back.outcome)
    if (!back.body.checked_in) return { outcome: "ineligible", message: `${site.realm}: the claim answered success, but the day's check-in is not in — nothing is claimed again today` }
    // The credit is the day's credits, never credits plus extra_credits.
    // Trae CN's real claim answers {"code":0,"message":"success"}, with no
    // credit at all (plugins#194), so the status's credits stand in. Its
    // status carries extra_credits beside credits, at the same 100 on a
    // real account (yetone/magpie#808: credits 100, extra_credits 100),
    // while the account gets 100: adding the two showed 200 (zhujiu on
    // magpie's Discord, 10-25). A claim that names its own credit is
    // taken first; one naming extra_credits alone is that (#260). Either
    // may be absent, and Number(undefined) is NaN, which reads as none.
    const n = (v) => (Number.isFinite(Number(v)) ? Number(v) : 0)
    const credit = n(answer.credits) || n(answer.extra_credits) || n(back.body.credits)
    return { outcome: "claimed", ...(credit > 0 ? { credit } : {}) }
  }

  // enterpriseUsage reads an enterprise (SaaS) account's usage: the seat
  // pool and what the account's models cost (get_personal_quota and
  // get_user_model_usage on the realm's console, in the realm's money). On
  // Trae CN the consumer credits page is read beside them for the card's
  // second row — that realm's console is what such an account bills on, and
  // the credits page answers it too with an allowance real calls have been
  // measured not to touch. The international realm has no such page.
  const enterpriseUsage = async (a, signIn) => {
    const ent = site.usage.ent
    const ask = async (path) => {
      const r = await post(a, site.hosts.console + path, {})
      const e = errorOf(r.v)
      // A console known to take the IDE's own token answers a lapsed sign-in
      // with 401 or the realm's lapsed code, and that is the sign-in's
      // trouble. A console that is not known to (the international one, which
      // no such account could be found to ask) is not allowed to say so: its
      // refusal is reported as the read's error and the sign-in stands,
      // because a console that wants its own session would otherwise mark
      // every one of that realm's enterprise accounts expired, and signing in
      // again would not clear it.
      if (r.status === 401 || lapsedCode(e.code, site)) {
        return site.consoleTakesIdeToken ? { gone: true } : { error: e.message || statusLine(r.status) }
      }
      if (r.status !== 200 || (e.code && String(e.code) !== "0")) return { error: e.message || statusLine(r.status) }
      return { v: r.v }
    }
    let quota
    try {
      quota = await ask(ent.quota.path)
    } catch (e) {
      return { error: `${site.realm} usage: ` + (e?.message ?? e), signIn }
    }
    if (quota.gone) return { error: `${a.name || a.uid}: ${site.realm}'s sign-in has expired — sign in again`, signIn: "expired" }
    if (quota.error) return { error: `${site.realm} usage: ${quota.error}`, signIn, user: a.name }
    // the spend page is the second half of the count: when it fails, the
    // allowance is still worth showing but the spend is unknown, and the
    // window says so (used: null) rather than reading as nothing spent — a
    // failed read is not a spend of zero
    let spent = { v: {} }
    try {
      const got = await ask(ent.spent.path)
      if (!got.gone && !got.error) spent = got
    } catch {}
    // the console's own period, for the date the pool refills: a failure
    // there costs the card its reset date and nothing else
    let core = { v: {} }
    try {
      const got = await ask(ent.core.path)
      if (!got.gone && !got.error) core = got
    } catch {}
    // the credits page is the card's second row, never the count: a failure
    // there leaves the seat pool standing. Trae Global has no such page —
    // its own usage page is the dollar billing's, read above as the pool.
    let page = null
    if (site.usage.kind === "credits") {
      try {
        const r = await post(a, site.usage.host(site, a) + site.usage.path, site.usage.body)
        const e = errorOf(r.v)
        if (r.status === 200 && (!e.code || String(e.code) === "0")) page = r.v
      } catch {}
    }
    return ent.read({ quota: quota.v, spent: spent.v, core: core.v, credits: page }, a, signIn, { credits, round })
  }

  const usage = async (getAuth) => {
    let a
    try {
      a = await fresh(getAuth)
    } catch (e) {
      return { error: e.message, signIn: e instanceof Expired ? "expired" : "kept" }
    }
    const signIn = a.renewed ? "renewed" : "kept"
    // an enterprise (SaaS) account bills on the realm's own console, not on
    // the page its realm otherwise bills on
    if (site.usage.ent && isEnterprise(a, site)) return enterpriseUsage(a, signIn)
    let r
    try {
      r = await post(a, site.usage.host(site, a) + site.usage.path, site.usage.body)
    } catch (e) {
      return { error: `${site.realm} ${site.usage.label}: ` + (e?.message ?? e), signIn }
    }
    const e = errorOf(r.v)
    if (r.status === 401 || lapsedCode(e.code, site)) return { error: `${a.name || a.uid}: ${site.realm}'s sign-in has expired — sign in again`, signIn: "expired" }
    if (r.status !== 200 || (e.code && String(e.code) !== "0")) return { error: `${site.realm} ${site.usage.label}: ${e.message || statusLine(r.status)}`, signIn, user: a.name }
    return site.usage.read(r.v, a, signIn, { credits, round, statusLine })
  }

  // batchLists is every chat function's model list in one ask, as TRAE
  // SOLO CN's ai-agent asks (batch_get_detail_param): {function: entries}.
  // null when Trae answers it with no lists.
  const batchLists = async (a) => {
    const r = await post(a, hostOf(a) + "/api/ide/v1/batch_get_detail_param", {
      functions: site.functions, agent_type: "", current_config_info: { config_name: "", is_custom_model: false },
      mode_type: 0, access_type: 0, ab_force_vids: "", ab_autotest_advanced_mode: 0, show_custom_model: true,
    })
    if (r.status === 401 || lapsedCode(errorOf(r.v).code, site)) throw new Expired(`${site.realm}'s sign-in has expired; sign in again`)
    if (r.status !== 200) throw new Error(`${site.realm} models: ${statusLine(r.status)}`)
    const groups = r.v.function_configs ?? r.v.data?.function_configs
    if (!Array.isArray(groups)) return null
    const out = {}
    for (const g of groups) {
      const fn = String(g?.function ?? "")
      if (!site.functions.includes(fn) || !Array.isArray(g.config_info_list)) continue
      out[fn] = [...(out[fn] ?? []), ...g.config_info_list.filter((m) => m?.config_name)]
    }
    return Object.keys(out).length ? out : null
  }

  // listOf is one function's model list, as the IDE asks for it
  const listOf = async (a, fn) => {
    const r = await post(a, hostOf(a) + "/api/ide/v1/get_detail_param", {
      function: fn, config_names: null, need_prompt: false, current_config_info: null, poly_prompt: true, mode_type: null, agent_type: null,
    })
    if (r.status === 401 || lapsedCode(errorOf(r.v).code, site)) throw new Expired(`${site.realm}'s sign-in has expired; sign in again`)
    if (r.status !== 200) throw new Error(`${site.realm} models: ${statusLine(r.status)}`)
    const list = r.v.config_info_list ?? r.v.data?.config_info_list ?? []
    return list.filter((m) => m?.config_name)
  }

  // liveModels is the account's model list: every chat function's, since
  // SOLO lists models the classic IDE's chat_v3 doesn't (deepseek-v4.1-flash
  // came to the TRAE agent's first, yetone/magpie#681); a model listed by one function
  // only is asked through that one. One function's list failing leaves the
  // others'; all failing is the error.
  //
  // The lists come from batch_get_detail_param, as TRAE SOLO CN asks them;
  // when that gives none, from get_detail_param, one function at a time.
  // A model several functions list is asked through the first whose entry
  // names a __dev model (one Trae serves) and isn't misnamed, else the
  // first that names one, else the first.
  const liveModels = async (a) => {
    let lists = null
    try {
      lists = await batchLists(a)
    } catch (e) {
      if (e instanceof Expired) throw e
    }
    if (!lists) {
      const got = await Promise.allSettled(site.functions.map((fn) => listOf(a, fn)))
      const expired = got.find((g) => g.status === "rejected" && g.reason instanceof Expired)
      if (expired) throw expired.reason
      if (got.every((g) => g.status === "rejected")) throw got[0].reason
      lists = {}
      got.forEach((g, i) => {
        if (g.status === "fulfilled") lists[site.functions[i]] = g.value
      })
    }
    // a function can give a model another's name: chat_v3 calls
    // deepseek-v4.1-flash "DeepSeek-V4-Flash 正式版", as it does
    // DeepSeek-V4-Flash-Official, where SOLO's lists call it
    // DeepSeek-V4.1-Flash (yetone/magpie#681) — Trae's usage page then books
    // a request under the name of the list it was served through. Such an
    // entry is misnamed: its name is another model's in the same list, and
    // other lists name it otherwise.
    const nameOf = (m) => String(m.display_config?.display_name || m.display_name || m.display_model_name || m.config_name)
    // an enterprise model a preset shares its config_name with is its twin,
    // listed under twinId; every other entry under its config_name
    const presets = new Set()
    for (const fn of site.functions) for (const m of lists[fn] ?? []) if (chatModel(m, site) && !enterpriseModel(m)) presets.add(String(m.config_name))
    const keyOf = (m) => (enterpriseModel(m) && presets.has(String(m.config_name)) ? twinId(m) : String(m.config_name))
    const names = new Map() // id → the names its lists give it, and how many give each
    for (const fn of site.functions) {
      for (const m of lists[fn] ?? []) {
        if (!chatModel(m, site)) continue
        const id = keyOf(m), name = nameOf(m)
        const by = names.get(id) ?? new Map()
        by.set(name, (by.get(name) ?? 0) + 1)
        names.set(id, by)
      }
    }
    // the name most of a model's lists give it: the one Trae's own client is
    // served under, and so the one its usage page books it as. Trae renames
    // entries when it likes, and its 2026-10-09 rename of
    // DeepSeek-V4-Flash-Official left chat_v3 the only list still calling
    // deepseek-v4.1-flash by another's name — which neither signal above
    // catches. A tie leaves the name to its entry.
    const agreed = new Map() // id → that name, "" when the lists tie
    for (const [id, by] of names) {
      const top = Math.max(...by.values())
      const most = [...by].filter(([, n]) => n === top)
      agreed.set(id, most.length === 1 ? most[0][0] : "")
    }
    const misnamed = (fn, m) => {
      const id = keyOf(m), name = nameOf(m)
      return names.get(id).size > 1 && (lists[fn] ?? []).some((o) => chatModel(o, site) && keyOf(o) !== id && nameOf(o) === name)
    }
    // a function's entry is worth more when it names a __dev model, then
    // when it isn't misnamed, then when it carries the name its lists agree
    // on; the first of the best is taken. Those three decide first, so the
    // entry kept is the one Trae's own client asks through.
    //
    // Last among equals comes whether the entry names reasoning levels: the
    // entry kept is the one the request is asked through, and so the one
    // whose reasoning_effort_config the request is held to (liveEntryOf). An
    // entry that names none while a sibling names some would leave the model
    // with no level to pick although Trae serves it with levels — doubling
    // the three keeps them decisive and lets this only break a tie.
    const worth = (fn, m) => ((devModel(m) ? 2 : 0) + (misnamed(fn, m) ? 0 : 1) + (nameOf(m) === agreed.get(keyOf(m)) ? 1 : 0)) * 2 + (levelsOf(m)?.length ? 1 : 0)
    const out = new Map()
    for (const fn of site.functions) {
      for (const m of lists[fn] ?? []) {
        if (!chatModel(m, site)) continue
        const id = keyOf(m)
        const was = out.get(id)
        if (!was || worth(fn, m) > was.worth) out.set(id, { m, fn, worth: worth(fn, m) })
      }
    }
    twins.clear()
    for (const [id, { m, fn }] of out) {
      listedAs.set(m, id)
      if (id !== String(m.config_name)) twins.set(String(m.config_name), id)
      listedBy.set(id, fn)
      liveEntry.set(id, m)
      const sees = seesOf(m)
      if (sees === null) sight.delete(id)
      else sight.set(id, sees)
      const dev = devModel(m)
      if (dev) modelNames.set(id, { fn, name: dev.model_name, most: Number(dev.max_tokens) || 0 })
      else modelNames.delete(id)
      if (out.has(id + MAX)) continue
      // its Max is asked through the function whose entry names the __max
      // model, the entries carrying the agreed name first: Trae books the
      // Max under that name too
      const plain = (e) => (nameOf(e.m) === agreed.get(id) ? 0 : 1)
      const entries = [{ m, fn }, ...site.functions.flatMap((f) => (lists[f] ?? []).filter((o) => o !== m && chatModel(o, site) && keyOf(o) === id).map((o) => ({ m: o, fn: f })))].sort((a, b) => plain(a) - plain(b))
      const max = maxModel(...entries.map((e) => e.m))
      maxes.set(id, max)
      if (max) {
        const by = entries.find((e) => e.m === max.entry).fn
        listedBy.set(id + MAX, by)
        modelNames.set(id + MAX, { fn: by, name: max.name, most: max.most, max: { base: id, window: max.window } })
      } else {
        listedBy.delete(id + MAX)
        modelNames.delete(id + MAX)
      }
    }
    // an enterprise model listed under its config_name answers to its twin id
    // as well, so an id saved while a preset shared its name keeps reaching it
    // once Trae lists the preset no more
    for (const [id, { m }] of out) {
      if (!enterpriseModel(m)) continue
      const alias = twinId(m)
      if (alias === id || out.has(alias)) continue
      for (const [map, from, to] of [[listedBy, id, alias], [liveEntry, id, alias], [sight, id, alias], [modelNames, id, alias], [listedBy, id + MAX, alias + MAX], [modelNames, id + MAX, alias + MAX]]) {
        if (map.has(from)) map.set(to, map.get(from))
        else map.delete(to)
      }
    }
    // this account's list has just answered: recorded, so a request that wants
    // levels for a model the list doesn't name waits REREAD_MS before reading
    // again, and a request arriving meanwhile joins this read instead of
    // asking — the catalog read a host makes counts as that read too
    const models = [...out.values()].map((x) => x.m)
    const who = a.uid || a.name || String(site.id)
    const at = readAt.get(who)
    // a readList run records itself; a read nobody recorded (a caller reaching
    // liveModels directly) is recorded here, unless a read is in flight
    if (at === undefined || !at.p) readAt.set(who, { at: Date.now(), p: null, done: models, expired: null })
    return models
  }

  // modelOf is a model of the account's list as OpenCode's provider
  // carries one. A model of the site's fallback list has capabilities
  // already (magpie's host spreads the config's into them); one the list
  // doesn't have gets them from MODEL's flat fields, so that magpie reads
  // it as a model that reasons rather than one that doesn't (its host
  // reads capabilities.reasoning alone, host.js). The fallback list stays
  // the authority where it has an entry.
  const modelOf = (provider, m) => {
    const id = idOf(m)
    const was = provider.models?.[id] ?? {}
    // context_window_tokens: dev is the budget Trae's own agent asks with;
    // the model's window is its Max one, put on the entry by provider.models
    // below (yetone/magpie#5809)
    const ctx = Number(m.context_window_tokens?.dev ?? m.context_window_size?.max?.[0] ?? m.context_window_size?.max ?? m.context_window_tokens?.max ?? m.prompt_max_tokens) || was.limit?.context || MODEL.limit.context
    // output: the detail requests are served by (an enterprise model's own
    // when it has no __dev one)
    const out = Number((enterpriseModel(m) ? enterpriseDetail(m) : devModel(m))?.max_tokens) || was.limit?.output || 0
    const name = m.display_config?.display_name || m.display_name || m.display_model_name || was.name || id
    const input = (k) => (MODEL.modalities?.input ?? []).includes(k)
    // the list's multimodal says whether the model takes images, over the
    // fallback list's word and MODEL's
    const sees = seesOf(m)
    const inputs = was.capabilities?.input ?? { text: true, image: input("image"), audio: input("audio"), video: input("video"), pdf: input("pdf") }
    const sight = sees === null ? {} : {
      modalities: { input: [...new Set([...((was.modalities ?? MODEL.modalities).input ?? ["text"]).filter((k) => k !== "image"), ...(sees ? ["image"] : [])])], output: (was.modalities ?? MODEL.modalities).output ?? ["text"] },
      attachment: sees,
    }
    return {
      ...MODEL, ...was, ...sight, id, providerID: site.id, name: String(name), limit: { context: ctx, output: out },
      api: was.api ?? { id, url: site.hosts.api, npm: "@ai-sdk/openai-compatible" },
      capabilities: {
        ...(was.capabilities ?? {}),
        reasoning: was.capabilities?.reasoning ?? MODEL.reasoning,
        temperature: was.capabilities?.temperature ?? MODEL.temperature,
        attachment: sees ?? was.capabilities?.attachment ?? MODEL.attachment,
        toolcall: was.capabilities?.toolcall ?? MODEL.tool_call,
        input: sees === null ? inputs : { ...inputs, image: sees },
        output: was.capabilities?.output ?? { text: true, image: false, audio: false, video: false, pdf: false },
      },
      // the levels this entry takes, as OpenCode's variants: Trae's own
      // reasoning_effort_config, which a model without one doesn't carry (it
      // is then served at Trae's default, with no level to pick). A config
      // model with an empty variants says nothing — magpie's host fills one in
      // for every model it hands over — so only a non-empty one is kept, or a
      // model in the fallback table would lose the levels its entry names.
      variants: Object.keys(was.variants ?? {}).length ? was.variants : variantsOf(levelsOf(m)),
      ...traeRateOf(m),
    }
  }

  return {
    config: async (config) => {
      config.provider ??= {}
      const was = config.provider[site.id] ?? {}
      config.provider[site.id] = {
        name: site.name,
        npm: "@ai-sdk/openai-compatible",
        api: site.hosts.api + "/v1",
        ...was,
        models: { ...site.models, ...(was.models ?? {}) },
      }
    },
    // the conversation's id, which the requests below carry as their
    // session_id: magpie's (or OpenCode's) session for this request, when it
    // names one
    "chat.headers": async (input, output) => {
      const id = input?.model?.providerID ?? input?.provider?.info?.id
      if (id !== site.id || !input?.sessionID) return
      output.headers[SESSION] = String(input.sessionID).slice(0, 128)
    },
    provider: {
      id: site.id,
      // the account's own list, when Trae answers; else the list above.
      // A refresh rides readList's one read per REREAD_MS, so a request that
      // wants levels while the host is refreshing joins that read instead of
      // asking for the list a second time (and vice versa).
      async models(provider, { auth }) {
        if (auth?.type !== "oauth" || !auth.access) return provider.models
        try {
          const { models: ms, expired } = await readList(await fresh(async () => auth), { strict: true })
          // a lapse must reach the host here, so the account is marked: a
          // request path deliberately lets it pass instead. A fresh instance:
          // the recorded one already served as a rejection inside the read, and
          // re-throwing that same object carries its unhandled state with it
          if (expired) throw new Expired(expired.message)
          if (!ms.length) return provider.models
          const ids = new Set(ms.map(idOf))
          return Object.fromEntries(ms.flatMap((m) => {
            const id = idOf(m)
            const own = modelOf(provider, m)
            const max = maxes.get(id)
            // the window the model takes, not the budget Trae's own agent asks
            // with: dev is what the IDE compacts to, and a request past it is
            // served, not refused — but only where that was measured
            // (yetone/magpie#5809)
            if (max && WIDENED[site.id]?.has(id.toLowerCase())) own.limit = { ...own.limit, context: Math.max(own.limit.context, max.window) }
            if (!max || ids.has(id + MAX)) return [[id, own]]
            // its Max, a model of its own: the window and output Max mode gives
            const was = provider.models?.[id + MAX] ?? {}
            return [[id, own], [id + MAX, { ...own, ...was, id: id + MAX, name: own.name + " (Max)", limit: { context: max.window, output: max.most || own.limit.output }, api: { ...own.api, id: id + MAX } }]]
          }))
        } catch (e) {
          if (e instanceof Expired) throw e
          return provider.models
        }
      },
    },
    auth: {
      provider: site.id,
      usage,
      checkin,
      // magpie renews the token LEAD_MS before its end, once, before its
      // requests, models and usage ask; the check before each request
      // stays for OpenCode, which doesn't call this
      refreshLead: LEAD_MS,
      refresh,
      loader: async (getAuth) => {
        const a0 = fromAuth(await getAuth(), site)
        if (!a0) return {}
        return {
          baseURL: hostOf(a0) + "/v1",
          apiKey: "trae", // the engine's placeholder; the request carries the JWT
          async fetch(input, init = {}) {
            const r0 = input instanceof Request ? input : null
            let body = init.body ?? (r0 ? await r0.text() : undefined)
            if (body instanceof ArrayBuffer) body = new TextDecoder().decode(body)
            else if (ArrayBuffer.isView(body)) body = new TextDecoder().decode(new Uint8Array(body.buffer, body.byteOffset, body.byteLength))
            const url = r0 ? r0.url : input instanceof URL ? input.href : String(input)
            if (ownPage(url, site)) return ownRequest(getAuth, a0, url, init.method ?? r0?.method ?? "POST", body, init.signal ?? r0?.signal)
            const req = parseJSON(body)
            if (!Array.isArray(req.messages)) return errorResponse(400, `${site.realm}: only chat completions are served`)
            let a
            try {
              a = await fresh(getAuth)
            } catch (e) {
              if (e instanceof Expired) return errorResponse(401, `${a0.name || a0.uid}: ${e.message}`, "expired")
              throw e
            }
            const signIn = a.renewed ? "renewed" : "kept"
            const who = a.uid || a.name
            // a twin id asked before the list was read here: Trae knows it by
            // no name, so the list is read (once per REREAD_MS) for its entry
            {
              const asked = String(req.model)
              const base = asked.endsWith(MAX) ? asked.slice(0, -MAX.length) : asked
              if (base.includes(TWIN) && !liveEntry.has(base)) await readList(a)
            }
            // the function that lists the model first, then the one that
            // served this account last, then the rest
            const fns = [...new Set([listedBy.get(String(req.model)), fnOf.get(who), ...site.functions].filter(Boolean))]
            let last
            let named = modelNames.get(String(req.model))
            if (!named && String(req.model).endsWith(MAX)) {
              // a Max asked before the list was read here: read it (or ride
              // the read already in flight), once per REREAD_MS — a list that
              // doesn't name this Max is not read for again on every request
              // (the chat can answer without it), and a Max the read does name
              // is asked through its base, not under this unlisted id
              await readList(a)
              named = modelNames.get(String(req.model))
              if (named) fns.unshift(named.fn)
            }
            const max = named?.max ?? null
            // a model the list hasn't said of is sent its images: the agent
            // sends them only to a model it was told takes them
            const base = max?.base ?? String(req.model)
            const sees = sight.get(base) ?? (site.models[base]?.modalities?.input?.includes("image") ?? true)
            // the levels the base model takes, from the entry its lists gave
            // it: what the request's effort is sent as, and left out when the
            // model has no entry for it. An entry naming levels this build
            // can't spell counts as no level here — levelsOf says null for it
            // so a caller can tell the two apart, and this one sends nothing
            // either way.
            //
            // The list is read once per REREAD_MS for a model it hasn't named,
            // and a read already in flight is shared rather than skipped: a
            // parallel request that skipped it would drop its level for that
            // turn. An answer that leaves the model out — a list that failed,
            // or one that simply doesn't name it — is remembered too, instead
            // of being asked for again on every request that carries an effort.
            let levels = levelsOf(liveEntryOf(base)) ?? []
            if (!liveEntry.has(base) && (req.reasoning_effort ?? req.reasoningEffort)) {
              await readList(a)
              levels = levelsOf(liveEntryOf(base)) ?? []
            }
            // the answer's own signal: the caller's abort (a cancelled
            // request) and the stream's cancel both stop Trae's fetch, so
            // no read is left hanging on a connection the agent walked
            // away from
            const ac = new AbortController()
            const outer = init.signal ?? r0?.signal ?? null
            if (outer) {
              if (outer.aborted) ac.abort()
              else outer.addEventListener("abort", () => ac.abort(), { once: true })
            }
            // the conversation this request belongs to, from the chat.headers
            // hook (magpie's session) or the chat's own first user message, as
            // the account answering it, so a failover inside one conversation
            // is not one Trae reads as another's
            const session = conversationID(req, sessionOf(new Headers(init.headers ?? r0?.headers ?? {})), who)
            // an enterprise seat chats on its console, which bills the seat
            // pool. One whose console turns chats away (4245, #1127) is
            // marked, kept with its sign-in, and the same request is asked
            // once more on the consumer gateway; its list is read from there
            // next.
            // what the last refusal was, and where it was asked: the error
            // the agent gets names the model, the functions and the host
            let why = null
            const tried = []
            const entry = liveEntryOf(base)
            // an enterprise model with its own endpoint is asked there, as
            // Trae's client asks it (directOf); one that endpoint doesn't
            // answer goes on through llm_utils_chat below
            const dir = max ? null : directOf(entry)
            if (dir && directRefused.get(base) !== akKey(dir.ak)) {
              const out = await askDirect(req, dir, base, ac, site)
              if (out) {
                out.headers.set("X-Magpie-Sign-In", signIn)
                return out
              }
            }
            for (let round = 0; round < 2; round++) {
              const host = hostOf(a)
              let refused = false
              for (const fn of [...new Set(fns)]) {
                tried.push(fn)
                const sent = chatBody(req, fn, named?.fn === fn || max ? named.name : "", named?.fn === fn || max ? named.most : 0, max, session, sees, levels, entry)
                const rid = randomUUID()
                debugSent(host + "/api/agent/v3/llm_utils_chat", rid, sent)
                const res = await fetch(host + "/api/agent/v3/llm_utils_chat", {
                  method: "POST",
                  headers: ideHeaders(a, site, { Accept: "text/event-stream", "X-Request-ID": rid }),
                  body: JSON.stringify(sent),
                  signal: ac.signal,
                })
                if (traeDebug()) console.error(`trae debug: request ${rid} answered ${res.status} ${res.headers.get("content-type") ?? ""}`)
                if (!res.ok) {
                  const text = await res.text()
                  const e = errorOf(text)
                  if (traeDebug()) console.error(`trae debug: request ${rid} function ${fn} refused ${res.status} code=${e.code} message=${JSON.stringify(e.message)}`)
                  why = keptRefusal(why, { status: res.status, code: e.code, message: e.message || text.trim().slice(0, 300), host, plan: planOfText(text) })
                  last = failure(site, why.status, why.code, why.message)
                  if (onConsole(host) && consoleRefuses(e.code)) { refused = true; break }
                  if (res.status === 400 && wrongFunction(e.code)) continue
                  break
                }
                const ct = res.headers.get("content-type") ?? ""
                if (!ct.includes("event-stream") && ct.includes("json")) {
                  // an answer that isn't a stream is an error in a 200
                  const body = await res.text()
                  const e = errorOf(body)
                  if (traeDebug()) console.error(`trae debug: request ${rid} function ${fn} refused code=${e.code} message=${JSON.stringify(e.message)}`)
                  why = keptRefusal(why, { status: 502, code: e.code, message: e.message, host, plan: planOfText(body) })
                  last = failure(site, why.status, why.code, why.message)
                  if (onConsole(host) && consoleRefuses(e.code)) { refused = true; break }
                  if (wrongFunction(e.code)) continue
                  break
                }
                const it = parts(sse(res.body), Array.isArray(req.tools) ? req.tools : [])[Symbol.asyncIterator]()
                const { held, done } = await first(it)
                const err = held.find((p) => p.error)
                if (err) {
                  if (traeDebug()) console.error(`trae debug: request ${rid} function ${fn} refused in the stream code=${err.code} message=${JSON.stringify(err.error)} extra=${JSON.stringify(err.extra ?? null)}`)
                  why = keptRefusal(why, { status: 502, code: err.code, message: err.error, host, plan: err.plan ?? null })
                  last = failure(site, why.status, why.code, why.message)
                  if (onConsole(host) && consoleRefuses(err.code)) {
                    it.return?.()
                    res.body.cancel?.().catch(() => {})
                    refused = true
                    break
                  }
                  if (wrongFunction(err.code)) {
                    // another function may take it: this answer's read goes
                    // with the function it came from, not left hanging
                    it.return?.()
                    res.body.cancel?.().catch(() => {})
                    continue
                  }
                  break
                }
                fnOf.set(who, fn)
                const cut = enterpriseModel(entry) ? TRAE_CUT : 0
                const answer = done ? held : chain(held, it)
                const got = traeDebug() ? debugEnd(rid, answer, sent.max_tokens || 0, cut) : answer
                // the next ask of a reply Trae cut (continued): the same
                // request, function, host and session, with the text so far
                // as the assistant's, asked for what is left of the limit.
                // null when Trae doesn't answer it with a stream: the reply
                // then ends cut, as one ask's did.
                const more = async (text, left, round) => {
                  const asked = Date.now()
                  const again = {
                    ...req,
                    max_completion_tokens: undefined,
                    max_tokens: left > 0 ? left : undefined,
                    // a reply with no text yet (every round so far only
                    // reasoned) has nothing to go on from: it is asked again
                    // with THINK_ON after the request's own turns
                    messages: [...(Array.isArray(req.messages) ? req.messages : []), ...(text ? [{ role: "assistant", content: text }, { role: "user", content: GO_ON }] : [{ role: "user", content: THINK_ON }])],
                  }
                  const body = chatBody(again, fn, named?.fn === fn || max ? named.name : "", named?.fn === fn || max ? named.most : 0, max, session, sees, levels, entry)
                  const id = randomUUID()
                  debugSent(host + "/api/agent/v3/llm_utils_chat", id, body)
                  const r = await fetch(host + "/api/agent/v3/llm_utils_chat", {
                    method: "POST",
                    headers: ideHeaders(a, site, { Accept: "text/event-stream", "X-Request-ID": id }),
                    body: JSON.stringify(body),
                    signal: ac.signal,
                  })
                  if (traeDebug()) console.error(`trae debug: request ${id} answered ${r.status} ${r.headers.get("content-type") ?? ""} round=${round} wait_ms=${Date.now() - asked}`)
                  if (!r.ok || !(r.headers.get("content-type") ?? "").includes("event-stream")) {
                    r.body?.cancel?.().catch(() => {})
                    return null
                  }
                  const p = parts(sse(r.body), Array.isArray(req.tools) ? req.tools : [])
                  return traeDebug() ? debugEnd(id, p, body.max_tokens || 0, cut) : p
                }
                // this turn's share of the conversation's record, read when the
                // answer ends: a stream waits only a little for it, a body as
                // long as the record may settle
                const bill = (usage) => turnBilling(a, site, sent.session_id, { usage, signal: ac.signal, wait: req.stream ? BILLING_WAIT.stream : BILLING_WAIT.body })
                const out = await openai(req, cut ? continued(got, sent.max_tokens || 0, cut, more, req.model) : got, () => ac.abort(), site, sent.max_tokens || 0, cut, bill)
                out.headers.set("X-Magpie-Sign-In", signIn)
                return out
              }
              if (!refused) break
              consoleRefused.add(who)
              a = { ...a, consoleChat: false }
              await save(toAuth(a, site))
              readAt.delete(who)
            }
            if (why?.plan != null && last.status !== 401) last = errorResponse(403, `${site.realm}: the model is not available to this account's plan (code ${why.code}, plan ${why.plan}); ${await askedOf(a, base, entry, [...new Set(tried)], why.host)}`)
            else if (why && last.status !== 401 && last.status !== 429) last = failure(site, why.status, why.code, why.message, await askedOf(a, base, entry, [...new Set(tried)], why.host))
            if (!last.headers.has("X-Magpie-Sign-In")) last.headers.set("X-Magpie-Sign-In", signIn)
            return last
          },
        }
      },
      methods: [
        { type: "oauth", label: `${site.name} account (browser)`, authorize: () => browserSignIn(site) },
        { type: "oauth", label: `${site.name} enterprise account (browser)`, authorize: () => browserSignIn(site, { enterprise: true }) },
      ],
    },
  }
}

// for tests: the CN realm's table as before, plus both realms' factories
export const TraeCNAuthPlugin = makePlugin(SITES["trae-cn"])
export const TraeGlobalAuthPlugin = makePlugin(SITES["trae-global"])

export const _internal = { chatModel, cutFinish, ending, TRAE_CUT, continued, addUsage, GO_ON, THINK_ON, reasoned, CUT_ROUNDS, THOUGHT_ROUNDS, tune, ownClient, clientStoragePaths, clientDevice, clientProfiles, deviceNote, clientDecode, thisMachine, traeHost, accountOf, HOSTS: SITES["trae-cn"].hosts, MODELS: SITES["trae-cn"].models, TextTools, NativeCalls, looseJSON, glmCall, nameCall, toolNamed, unwrapped, traeMessages, chatBody, nativeTools, moonshotSchema, credits, dollarUsageOf, seatPoolOf, seatSpentOf, entResetOf, isEnterprise, yuan, whenOf, newDevice, ugDevice, proofOf, SITES, SESSION, conversationID, LEVELS, levelsOf, variantsOf, effortOf, offered, traeRateOf, directOf, directBody, directParts, directRefused, turnBilling, twinId }
