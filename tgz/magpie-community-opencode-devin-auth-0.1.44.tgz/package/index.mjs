// Devin subscriptions for OpenCode and magpie: the devin CLI's own sign-in
// (a PKCE round through app.devin.ai to a callback on 127.0.0.1), and each
// chat completion sent whole to the API the CLI talks to, Windsurf's
// GetChatMessage (a Connect RPC in protobuf), its reply streamed back as
// chat completion chunks. Ported from magpie's built-in Devin account
// (internal/provider/devin*.go, internal/gateway/devin.go).

import { Buffer } from "node:buffer"
import { createHash, randomBytes, randomUUID } from "node:crypto"
import { createServer, STATUS_CODES } from "node:http"
import { gunzipSync, gzipSync } from "node:zlib"
import { spawn } from "node:child_process"
import { existsSync, readFileSync, realpathSync, statSync } from "node:fs"
import { mkdir, readFile, writeFile } from "node:fs/promises"
import { homedir } from "node:os"
import { isAbsolute, join, relative, resolve } from "node:path"

const ID = "devin"
const CHAT = "@ai-sdk/openai-compatible"
// Devin's Claude models are asked on Anthropic's Messages API, so the
// client's own blocks and cache marks reach the plugin as it sent them
// (#566); every other model stays on chat completions
const ANTHROPIC = "@ai-sdk/anthropic"
const isClaude = (id) => /claude/i.test(String(id))
const npmOf = (id) => (isClaude(id) ? ANTHROPIC : CHAT)
const variantOf = (id, e) => (isClaude(id) ? { effort: e } : { reasoningEffort: e })

const SERVER = "https://server.codeium.com"
const AUTHORIZE = "https://app.devin.ai/auth/cli/continue"
const EXCHANGE = "/exa.seat_management_pb.SeatManagementService/ExchangeDevinCLIPKCECode"
const CHAT_RPC = "/exa.api_server_pb.ApiServerService/GetChatMessage"
// the CLI the requests say they come from
const CLI_VERSION = "3000.11.3"
// the AI SDK is given a chat completions URL; the loader's fetch answers
// every request itself, so nothing is ever sent here
const BASE = SERVER + "/devin/v1"
const SIGN_IN_TIMEOUT = 10 * 60 * 1000
// how long the CLI's model list is kept, and how long a failed read waits
const FRESH = 5 * 60 * 1000
const RETRY = 60 * 1000

// ---- models ---------------------------------------------------------------------

// Devin's list as `devin models list --format json` gave it (2026-11-05),
// less Adaptive and Fusion, which route between models inside Devin's own
// agent and aren't served by the API: family id, label, aliases, and each
// variant's id, label, context and output. Models gone from that list —
// Inkling, Claude Sonnet 4.5, SWE-1.7 Lightning and the rest at the end —
// stay for the accounts still offered them. The account's own list, from
// Devin (GetCliModelConfigs) or else the CLI, replaces it.
const SNAPSHOT = [
  ["swe-2","SWE-2",["swe"],[["swe-2-high","SWE-2 High",262000,128000],["swe-2-medium","SWE-2 Medium",262000,128000],["swe-2-max","SWE-2 Max",262000,128000]]],
  ["swe-2-flash","SWE-2 Flash",[],[["swe-2-flash-medium","SWE-2 Flash Medium",262144,131072],["swe-2-flash-high","SWE-2 Flash High",262144,131072],["swe-2-flash-max","SWE-2 Flash Max",262144,131072]]],
  ["claude-fable-5-1","Claude Fable 5.1",["fable"],[["claude-fable-5-1-medium","Claude Fable 5.1 Medium",1000000,128000],["claude-fable-5-1-low","Claude Fable 5.1 Low",1000000,128000],["claude-fable-5-1-high","Claude Fable 5.1 High",1000000,128000],["claude-fable-5-1-xhigh","Claude Fable 5.1 XHigh",1000000,128000],["claude-fable-5-1-max","Claude Fable 5.1 Max",1000000,128000]]],
  ["claude-opus-5-5","Claude Opus 5.5",[],[["claude-opus-5-5-medium","Claude Opus 5.5 Medium",1000000,128000],["claude-opus-5-5-low","Claude Opus 5.5 Low",1000000,128000],["claude-opus-5-5-high","Claude Opus 5.5 High",1000000,128000],["claude-opus-5-5-xhigh","Claude Opus 5.5 XHigh",1000000,128000],["claude-opus-5-5-max","Claude Opus 5.5 Max",1000000,128000],["claude-opus-5-5-low-fast","Claude Opus 5.5 Low Fast",1000000,128000],["claude-opus-5-5-medium-fast","Claude Opus 5.5 Medium Fast",1000000,128000],["claude-opus-5-5-high-fast","Claude Opus 5.5 High Fast",1000000,128000],["claude-opus-5-5-xhigh-fast","Claude Opus 5.5 XHigh Fast",1000000,128000],["claude-opus-5-5-max-fast","Claude Opus 5.5 Max Fast",1000000,128000]]],
  ["gpt-6-astra","GPT-6 Astra",[],[["gpt-6-astra-medium","GPT-6 Astra Medium Thinking",1000000,128000],["gpt-6-astra-low","GPT-6 Astra Low Thinking",1000000,128000],["gpt-6-astra-high","GPT-6 Astra High Thinking",1000000,128000],["gpt-6-astra-xhigh","GPT-6 Astra XHigh Thinking",1000000,128000],["gpt-6-astra-max","GPT-6 Astra Max Thinking",1000000,128000],["gpt-6-astra-low-priority","GPT-6 Astra Low Thinking Fast",1000000,128000],["gpt-6-astra-medium-priority","GPT-6 Astra Medium Thinking Fast",1000000,128000],["gpt-6-astra-high-priority","GPT-6 Astra High Thinking Fast",1000000,128000],["gpt-6-astra-xhigh-priority","GPT-6 Astra XHigh Thinking Fast",1000000,128000],["gpt-6-astra-max-priority","GPT-6 Astra Max Thinking Fast",1000000,128000]]],
  ["gpt-6-sol","GPT-6 Sol",[],[["gpt-6-sol-medium","GPT-6 Sol Medium Thinking",1000000,128000],["gpt-6-sol-none","GPT-6 Sol No Thinking",1000000,128000],["gpt-6-sol-low","GPT-6 Sol Low Thinking",1000000,128000],["gpt-6-sol-high","GPT-6 Sol High Thinking",1000000,128000],["gpt-6-sol-xhigh","GPT-6 Sol XHigh Thinking",1000000,128000],["gpt-6-sol-max","GPT-6 Sol Max Thinking",1000000,128000],["gpt-6-sol-none-priority","GPT-6 Sol No Thinking Fast",1000000,128000],["gpt-6-sol-low-priority","GPT-6 Sol Low Thinking Fast",1000000,128000],["gpt-6-sol-medium-priority","GPT-6 Sol Medium Thinking Fast",1000000,128000],["gpt-6-sol-high-priority","GPT-6 Sol High Thinking Fast",1000000,128000],["gpt-6-sol-xhigh-priority","GPT-6 Sol XHigh Thinking Fast",1000000,128000],["gpt-6-sol-max-priority","GPT-6 Sol Max Thinking Fast",1000000,128000]]],
  ["gpt-6-luna","GPT-6 Luna",[],[["gpt-6-luna-medium","GPT-6 Luna Medium Thinking",1000000,128000],["gpt-6-luna-none","GPT-6 Luna No Thinking",1000000,128000],["gpt-6-luna-low","GPT-6 Luna Low Thinking",1000000,128000],["gpt-6-luna-high","GPT-6 Luna High Thinking",1000000,128000],["gpt-6-luna-xhigh","GPT-6 Luna XHigh Thinking",1000000,128000],["gpt-6-luna-max","GPT-6 Luna Max Thinking",1000000,128000],["gpt-6-luna-none-priority","GPT-6 Luna No Thinking Fast",1000000,128000],["gpt-6-luna-low-priority","GPT-6 Luna Low Thinking Fast",1000000,128000],["gpt-6-luna-medium-priority","GPT-6 Luna Medium Thinking Fast",1000000,128000],["gpt-6-luna-high-priority","GPT-6 Luna High Thinking Fast",1000000,128000],["gpt-6-luna-xhigh-priority","GPT-6 Luna XHigh Thinking Fast",1000000,128000],["gpt-6-luna-max-priority","GPT-6 Luna Max Thinking Fast",1000000,128000]]],
  ["gemini-4-argon","Gemini 4 Argon",[],[["gemini-4-argon-medium","Gemini 4 Argon Medium",1048576,1000000],["gemini-4-argon-low","Gemini 4 Argon Low",1048576,1000000],["gemini-4-argon-high","Gemini 4 Argon High",1048576,1000000]]],
  ["kimi-k3","Kimi K3",[],[["kimi-k3-high","Kimi K3 High",1048576,131072],["kimi-k3-low","Kimi K3 Low",1048576,131072],["kimi-k3-max","Kimi K3 Max",1048576,131072]]],
  ["glm-5.2","GLM-5.2",[],[["glm-5-2","GLM-5.2 High",200000,128000],["glm-5-2-max","GLM-5.2 Max",200000,128000],["glm-5-2-1m","GLM-5.2 High 1M",1000000,128000],["glm-5-2-max-1m","GLM-5.2 Max 1M",1000000,128000],["glm-5-2-none","GLM-5.2 No Thinking",200000,128000],["glm-5-2-none-1m","GLM-5.2 No Thinking 1M",1000000,128000]]],
  ["glm-5-3","GLM-5.3",[],[["glm-5-3-low","GLM-5.3 Low",1048576,128000],["glm-5-3-high","GLM-5.3 High",1048576,128000],["glm-5-3-max","GLM-5.3 Max",1048576,128000]]],
  ["claude-sonnet-5-5","Claude Sonnet 5.5",[],[["claude-sonnet-5-5-medium","Claude Sonnet 5.5 Medium",1000000,128000],["claude-sonnet-5-5-low","Claude Sonnet 5.5 Low",1000000,128000],["claude-sonnet-5-5-high","Claude Sonnet 5.5 High",1000000,128000],["claude-sonnet-5-5-xhigh","Claude Sonnet 5.5 XHigh",1000000,128000],["claude-sonnet-5-5-max","Claude Sonnet 5.5 Max",1000000,128000]]],
  ["gemini-3-8-flash","Gemini 3.8 Flash",["gemini"],[["gemini-3-8-flash-medium","Gemini 3.8 Flash Medium",1048576,65535],["gemini-3-8-flash-low","Gemini 3.8 Flash Low",1048576,65535],["gemini-3-8-flash-high","Gemini 3.8 Flash High",1048576,65535]]],
  ["claude-opus-4.7","Claude Opus 4.7",[],[["claude-opus-4-7-medium","Claude Opus 4.7 Medium",1000000,128000],["claude-opus-4-7-low","Claude Opus 4.7 Low",1000000,128000],["claude-opus-4-7-high","Claude Opus 4.7 High",1000000,128000],["claude-opus-4-7-xhigh","Claude Opus 4.7 XHigh",1000000,128000],["claude-opus-4-7-max","Claude Opus 4.7 Max",1000000,128000]]],
  ["claude-opus-4.8","Claude Opus 4.8",[],[["claude-opus-4-8-medium","Claude Opus 4.8 Medium",1000000,128000],["claude-opus-4-8-low","Claude Opus 4.8 Low",1000000,128000],["claude-opus-4-8-high","Claude Opus 4.8 High",1000000,128000],["claude-opus-4-8-xhigh","Claude Opus 4.8 XHigh",1000000,128000],["claude-opus-4-8-max","Claude Opus 4.8 Max",1000000,128000],["claude-opus-4-8-low-fast","Claude Opus 4.8 Low Fast",1000000,128000],["claude-opus-4-8-medium-fast","Claude Opus 4.8 Medium Fast",1000000,128000],["claude-opus-4-8-high-fast","Claude Opus 4.8 High Fast",1000000,128000],["claude-opus-4-8-xhigh-fast","Claude Opus 4.8 XHigh Fast",1000000,128000],["claude-opus-4-8-max-fast","Claude Opus 4.8 Max Fast",1000000,128000]]],
  ["claude-opus-5","Claude Opus 5",["opus"],[["claude-opus-5-medium","Claude Opus 5 Medium",1000000,128000],["claude-opus-5-low","Claude Opus 5 Low",1000000,128000],["claude-opus-5-high","Claude Opus 5 High",1000000,128000],["claude-opus-5-xhigh","Claude Opus 5 XHigh",1000000,128000],["claude-opus-5-max","Claude Opus 5 Max",1000000,128000],["claude-opus-5-low-fast","Claude Opus 5 Low Fast",1000000,128000],["claude-opus-5-medium-fast","Claude Opus 5 Medium Fast",1000000,128000],["claude-opus-5-high-fast","Claude Opus 5 High Fast",1000000,128000],["claude-opus-5-xhigh-fast","Claude Opus 5 XHigh Fast",1000000,128000],["claude-opus-5-max-fast","Claude Opus 5 Max Fast",1000000,128000]]],
  ["claude-5-fable","Claude Fable 5",[],[["claude-5-fable-low","Claude Fable 5 Low",1000000,128000],["claude-5-fable-medium","Claude Fable 5 Medium",1000000,128000],["claude-5-fable-high","Claude Fable 5 High",1000000,128000],["claude-5-fable-xhigh","Claude Fable 5 XHigh",1000000,128000],["claude-5-fable-max","Claude Fable 5 Max",1000000,128000]]],
  ["claude-sonnet-5","Claude Sonnet 5",["claude","sonnet"],[["claude-sonnet-5-low","Claude Sonnet 5 Low",1000000,128000],["claude-sonnet-5-medium","Claude Sonnet 5 Medium",1000000,128000],["claude-sonnet-5-high","Claude Sonnet 5 High",1000000,128000],["claude-sonnet-5-xhigh","Claude Sonnet 5 XHigh",1000000,128000],["claude-sonnet-5-max","Claude Sonnet 5 Max",1000000,128000]]],
  ["claude-haiku-5-5","Claude Haiku 5.5",[],[["claude-haiku-5-5-low","Claude Haiku 5.5 Low",1000000,128000],["claude-haiku-5-5-medium","Claude Haiku 5.5 Medium",1000000,128000],["claude-haiku-5-5-high","Claude Haiku 5.5 High",1000000,128000],["claude-haiku-5-5-xhigh","Claude Haiku 5.5 XHigh",1000000,128000],["claude-haiku-5-5-max","Claude Haiku 5.5 Max",1000000,128000]]],
  ["gemini-3.5-flash","Gemini 3.5 Flash",[],[["gemini-3-5-flash-minimal","Gemini 3.5 Flash Minimal",1048576,65535],["gemini-3-5-flash-low","Gemini 3.5 Flash Low",1048576,65535],["gemini-3-5-flash-medium","Gemini 3.5 Flash Medium",1048576,65535],["gemini-3-5-flash-high","Gemini 3.5 Flash High",1048576,65535]]],
  ["gemini-3.6-flash","Gemini 3.6 Flash",[],[["gemini-3-6-flash-minimal","Gemini 3.6 Flash Minimal",1048576,65535],["gemini-3-6-flash-low","Gemini 3.6 Flash Low",1048576,65535],["gemini-3-6-flash-medium","Gemini 3.6 Flash Medium",1048576,65535],["gemini-3-6-flash-high","Gemini 3.6 Flash High",1048576,65535]]],
  ["gemini-3-7-flash","Gemini 3.7 Flash",[],[["gemini-3-7-flash-low","Gemini 3.7 Flash Low",1048576,65535],["gemini-3-7-flash-medium","Gemini 3.7 Flash Medium",1048576,65535],["gemini-3-7-flash-high","Gemini 3.7 Flash High",1048576,65535]]],
  ["gpt-5.6-sol","GPT-5.6 Sol",[],[["gpt-5-6-sol-none","GPT-5.6 Sol No Thinking",1000000,128000],["gpt-5-6-sol-low","GPT-5.6 Sol Low Thinking",1000000,128000],["gpt-5-6-sol-medium","GPT-5.6 Sol Medium Thinking",1000000,128000],["gpt-5-6-sol-high","GPT-5.6 Sol High Thinking",1000000,128000],["gpt-5-6-sol-xhigh","GPT-5.6 Sol XHigh Thinking",1000000,128000],["gpt-5-6-sol-max","GPT-5.6 Sol Max Thinking",1000000,128000],["gpt-5-6-sol-none-priority","GPT-5.6 Sol No Thinking Fast",1000000,128000],["gpt-5-6-sol-low-priority","GPT-5.6 Sol Low Thinking Fast",1000000,128000],["gpt-5-6-sol-medium-priority","GPT-5.6 Sol Medium Thinking Fast",1000000,128000],["gpt-5-6-sol-high-priority","GPT-5.6 Sol High Thinking Fast",1000000,128000],["gpt-5-6-sol-xhigh-priority","GPT-5.6 Sol XHigh Thinking Fast",1000000,128000],["gpt-5-6-sol-max-priority","GPT-5.6 Sol Max Thinking Fast",1000000,128000]]],
  ["gpt-5.6-terra","GPT-5.6 Terra",[],[["gpt-5-6-terra-none","GPT-5.6 Terra No Thinking",1000000,128000],["gpt-5-6-terra-low","GPT-5.6 Terra Low Thinking",1000000,128000],["gpt-5-6-terra-medium","GPT-5.6 Terra Medium Thinking",1000000,128000],["gpt-5-6-terra-high","GPT-5.6 Terra High Thinking",1000000,128000],["gpt-5-6-terra-xhigh","GPT-5.6 Terra XHigh Thinking",1000000,128000],["gpt-5-6-terra-max","GPT-5.6 Terra Max Thinking",1000000,128000],["gpt-5-6-terra-none-priority","GPT-5.6 Terra No Thinking Fast",1000000,128000],["gpt-5-6-terra-low-priority","GPT-5.6 Terra Low Thinking Fast",1000000,128000],["gpt-5-6-terra-medium-priority","GPT-5.6 Terra Medium Thinking Fast",1000000,128000],["gpt-5-6-terra-high-priority","GPT-5.6 Terra High Thinking Fast",1000000,128000],["gpt-5-6-terra-xhigh-priority","GPT-5.6 Terra XHigh Thinking Fast",1000000,128000],["gpt-5-6-terra-max-priority","GPT-5.6 Terra Max Thinking Fast",1000000,128000]]],
  ["gpt-5.6-luna","GPT-5.6 Luna",[],[["gpt-5-6-luna-none","GPT-5.6 Luna No Thinking",1000000,128000],["gpt-5-6-luna-low","GPT-5.6 Luna Low Thinking",1000000,128000],["gpt-5-6-luna-medium","GPT-5.6 Luna Medium Thinking",1000000,128000],["gpt-5-6-luna-high","GPT-5.6 Luna High Thinking",1000000,128000],["gpt-5-6-luna-xhigh","GPT-5.6 Luna XHigh Thinking",1000000,128000],["gpt-5-6-luna-max","GPT-5.6 Luna Max Thinking",1000000,128000],["gpt-5-6-luna-none-priority","GPT-5.6 Luna No Thinking Fast",1000000,128000],["gpt-5-6-luna-low-priority","GPT-5.6 Luna Low Thinking Fast",1000000,128000],["gpt-5-6-luna-medium-priority","GPT-5.6 Luna Medium Thinking Fast",1000000,128000],["gpt-5-6-luna-high-priority","GPT-5.6 Luna High Thinking Fast",1000000,128000],["gpt-5-6-luna-xhigh-priority","GPT-5.6 Luna XHigh Thinking Fast",1000000,128000],["gpt-5-6-luna-max-priority","GPT-5.6 Luna Max Thinking Fast",1000000,128000]]],
  ["gpt-6-1-sol","GPT-6.1 Sol",[],[["gpt-6-1-sol-low","GPT-6.1 Sol Low Thinking",1000000,128000],["gpt-6-1-sol-medium","GPT-6.1 Sol Medium Thinking",1000000,128000],["gpt-6-1-sol-high","GPT-6.1 Sol High Thinking",1000000,128000],["gpt-6-1-sol-xhigh","GPT-6.1 Sol XHigh Thinking",1000000,128000],["gpt-6-1-sol-max","GPT-6.1 Sol Max Thinking",1000000,128000],["gpt-6-1-sol-low-priority","GPT-6.1 Sol Low Thinking Fast",1000000,128000],["gpt-6-1-sol-medium-priority","GPT-6.1 Sol Medium Thinking Fast",1000000,128000],["gpt-6-1-sol-high-priority","GPT-6.1 Sol High Thinking Fast",1000000,128000],["gpt-6-1-sol-xhigh-priority","GPT-6.1 Sol XHigh Thinking Fast",1000000,128000],["gpt-6-1-sol-max-priority","GPT-6.1 Sol Max Thinking Fast",1000000,128000]]],
  ["gpt-6-1-terra","GPT-6.1 Terra",[],[["gpt-6-1-terra-low","GPT-6.1 Terra Low Thinking",1000000,128000],["gpt-6-1-terra-medium","GPT-6.1 Terra Medium Thinking",1000000,128000],["gpt-6-1-terra-high","GPT-6.1 Terra High Thinking",1000000,128000],["gpt-6-1-terra-xhigh","GPT-6.1 Terra XHigh Thinking",1000000,128000],["gpt-6-1-terra-max","GPT-6.1 Terra Max Thinking",1000000,128000],["gpt-6-1-terra-low-priority","GPT-6.1 Terra Low Thinking Fast",1000000,128000],["gpt-6-1-terra-medium-priority","GPT-6.1 Terra Medium Thinking Fast",1000000,128000],["gpt-6-1-terra-high-priority","GPT-6.1 Terra High Thinking Fast",1000000,128000],["gpt-6-1-terra-xhigh-priority","GPT-6.1 Terra XHigh Thinking Fast",1000000,128000],["gpt-6-1-terra-max-priority","GPT-6.1 Terra Max Thinking Fast",1000000,128000]]],
  ["grok-4-6","Grok 4.6",[],[["grok-4-6-low","Grok 4.6 Low",500000,100000],["grok-4-6-medium","Grok 4.6 Medium",500000,100000],["grok-4-6-high","Grok 4.6 High",500000,100000],["grok-4-6-xhigh","Grok 4.6 XHigh",500000,100000]]],
  ["grok-4-7","Grok 4.7",[],[["grok-4-7-low","Grok 4.7 Low",500000,100000],["grok-4-7-medium","Grok 4.7 Medium",500000,100000],["grok-4-7-high","Grok 4.7 High",500000,100000],["grok-4-7-xhigh","Grok 4.7 XHigh",500000,100000]]],
  ["muse-wonder-1-0","Muse Wonder",[],[["muse-wonder-1-0-minimal","Muse Wonder Minimal",1048576,131072],["muse-wonder-1-0-low","Muse Wonder Low",1048576,131072],["muse-wonder-1-0-medium","Muse Wonder Medium",1048576,131072],["muse-wonder-1-0-high","Muse Wonder High",1048576,131072],["muse-wonder-1-0-xhigh","Muse Wonder XHigh",1048576,131072],["muse-wonder-1-0-max","Muse Wonder Max",1048576,131072]]],
  ["nemotron-3-5-super","Nemotron 3.5 Super",[],[["nemotron-3-5-super-none","Nemotron 3.5 Super None",1048576,65536],["nemotron-3-5-super-medium","Nemotron 3.5 Super Medium",1048576,65536],["nemotron-3-5-super-high","Nemotron 3.5 Super High",1048576,65536]]],
  ["glm-5-3-flash","GLM-5.3 Flash",[],[["glm-5-3-flash-low","GLM-5.3 Flash Low",1000000,131072],["glm-5-3-flash-high","GLM-5.3 Flash High",1000000,131072],["glm-5-3-flash-max","GLM-5.3 Flash Max",1000000,131072]]],
  ["deepseek-v4-flash","DeepSeek V4 Flash",[],[["deepseek-v4-flash-high","DeepSeek V4 Flash High",1048576,384000],["deepseek-v4-flash-max","DeepSeek V4 Flash Max",1048576,384000]]],
  ["deepseek-v4-1-flash-1017","DeepSeek V4.1 Flash",[],[["deepseek-v4-1-flash-1017-none","DeepSeek V4.1 Flash None",1048576,384000],["deepseek-v4-1-flash-1017-low","DeepSeek V4.1 Flash Low",1048576,384000],["deepseek-v4-1-flash-1017-high","DeepSeek V4.1 Flash High",1048576,384000],["deepseek-v4-1-flash-1017-max","DeepSeek V4.1 Flash Max",1048576,384000]]],
  ["swe-1.7","SWE-1.7",[],[["swe-1-7","SWE-1.7 Max",262000,128000],["swe-1-7-medium","SWE-1.7 Medium",262000,128000]]],
  ["claude-opus-4.6","Claude Opus 4.6",[],[["claude-opus-4-6","Claude Opus 4.6",200000,128000],["claude-opus-4-6-thinking","Claude Opus 4.6 Thinking",200000,128000],["claude-opus-4-6-1m","Claude Opus 4.6 1M",1000000,128000],["claude-opus-4-6-thinking-1m","Claude Opus 4.6 Thinking 1M",1000000,128000]]],
  ["gpt-5.4","GPT-5.4",[],[["gpt-5-4-none","GPT-5.4 No Thinking",272000,128000],["gpt-5-4-low","GPT-5.4 Low Thinking",272000,128000],["gpt-5-4-medium","GPT-5.4 Medium Thinking",272000,128000],["gpt-5-4-high","GPT-5.4 High Thinking",272000,128000],["gpt-5-4-xhigh","GPT-5.4 XHigh Thinking",272000,128000],["gpt-5-4-none-priority","GPT-5.4 No Thinking Fast",272000,128000],["gpt-5-4-low-priority","GPT-5.4 Low Thinking Fast",272000,128000],["gpt-5-4-medium-priority","GPT-5.4 Medium Thinking Fast",272000,128000],["gpt-5-4-high-priority","GPT-5.4 High Thinking Fast",272000,128000],["gpt-5-4-xhigh-priority","GPT-5.4 XHigh Thinking Fast",272000,128000]]],
  ["gpt-5.5","GPT-5.5",["gpt"],[["gpt-5-5-none","GPT-5.5 No Thinking",272000,128000],["gpt-5-5-low","GPT-5.5 Low Thinking",272000,128000],["gpt-5-5-medium","GPT-5.5 Medium Thinking",272000,128000],["gpt-5-5-high","GPT-5.5 High Thinking",272000,128000],["gpt-5-5-xhigh","GPT-5.5 XHigh Thinking",272000,128000],["gpt-5-5-none-priority","GPT-5.5 No Thinking Fast",272000,128000],["gpt-5-5-low-priority","GPT-5.5 Low Thinking Fast",272000,128000],["gpt-5-5-medium-priority","GPT-5.5 Medium Thinking Fast",272000,128000],["gpt-5-5-high-priority","GPT-5.5 High Thinking Fast",272000,128000],["gpt-5-5-xhigh-priority","GPT-5.5 XHigh Thinking Fast",272000,128000]]],
  ["gpt-5.4-mini","GPT-5.4 Mini",[],[["gpt-5-4-mini-low","GPT-5.4 Mini Low Thinking",400000,128000],["gpt-5-4-mini-medium","GPT-5.4 Mini Medium Thinking",400000,128000],["gpt-5-4-mini-high","GPT-5.4 Mini High Thinking",400000,128000],["gpt-5-4-mini-xhigh","GPT-5.4 Mini XHigh Thinking",400000,128000]]],
  ["claude-sonnet-4.6","Claude Sonnet 4.6",[],[["claude-sonnet-4-6","Claude Sonnet 4.6",200000,128000],["claude-sonnet-4-6-thinking","Claude Sonnet 4.6 Thinking",200000,128000],["claude-sonnet-4-6-1m","Claude Sonnet 4.6 1M",1000000,128000],["claude-sonnet-4-6-thinking-1m","Claude Sonnet 4.6 Thinking 1M",1000000,128000]]],
  ["kimi-k2.6","Kimi K2.6",[],[["kimi-k2-6","Kimi K2.6",262144,8192]]],
  ["kimi-k2.7","Kimi K2.7",[],[["kimi-k2-7","Kimi K2.7",262144,16000]]],
  ["nemotron-3-ultra","Nemotron 3 Ultra",[],[["nemotron-3-ultra-none","Nemotron 3 Ultra None",1000000,32768],["nemotron-3-ultra-medium","Nemotron 3 Ultra Medium",1000000,32768],["nemotron-3-ultra-high","Nemotron 3 Ultra High",1000000,32768]]],
  ["swe-1.6","SWE-1.6",[],[["swe-1-6","SWE-1.6",200000,128000]]],
  ["deepseek-v4-pro","DeepSeek V4 Pro",[],[["deepseek-v4-pro-high","DeepSeek V4 Pro High",1048576,384000],["deepseek-v4-pro-max","DeepSeek V4 Pro Max",1048576,384000]]],
  ["swe-1.7-lightning","SWE-1.7 Lightning",[],[["swe-1-7-lightning","SWE-1.7 Lightning Max",202752,96000],["swe-1-7-lightning-medium","SWE-1.7 Lightning Medium",202752,96000]]],
  ["inkling","Inkling",[],[["inkling-none","Inkling None",1048576,131072],["inkling-low","Inkling Low",1048576,131072],["inkling-medium","Inkling Medium",1048576,131072],["inkling-high","Inkling High",1048576,131072],["inkling-xhigh","Inkling X-High",1048576,131072],["inkling-max","Inkling Max",1048576,131072]]],
  ["grok-4.5","Grok 4.5",[],[["grok-4-5-low","Grok 4.5 Low",500000,100000],["grok-4-5-medium","Grok 4.5 Medium",500000,100000],["grok-4-5-high","Grok 4.5 High",500000,100000]]],
  ["gpt-5.2","GPT-5.2",[],[["MODEL_GPT_5_2_LOW","GPT-5.2 Low Thinking",384000,128000],["MODEL_GPT_5_2_MEDIUM","GPT-5.2 Medium Thinking",384000,128000],["MODEL_GPT_5_2_NONE","GPT-5.2 No Thinking",384000,128000],["MODEL_GPT_5_2_HIGH","GPT-5.2 High Thinking",384000,128000],["MODEL_GPT_5_2_XHIGH","GPT-5.2 XHigh Thinking",384000,128000]]],
  ["claude-opus-4.5","Claude Opus 4.5",[],[["MODEL_CLAUDE_4_5_OPUS","Claude Opus 4.5",200000,64000],["MODEL_CLAUDE_4_5_OPUS_THINKING","Claude Opus 4.5 Thinking",200000,64000]]],
  ["Claude Haiku 4.5","Claude Haiku 4.5",[],[["MODEL_PRIVATE_11","Claude Haiku 4.5",200000,64000]]],
  ["claude-sonnet-4.5","Claude Sonnet 4.5",[],[["MODEL_PRIVATE_2","Claude Sonnet 4.5",200000,64000],["MODEL_PRIVATE_3","Claude Sonnet 4.5 Thinking",200000,64000]]],
  ["GPT-4.1","GPT-4.1",[],[["MODEL_CHAT_GPT_4_1_2025_04_14","GPT-4.1",1047576,32768]]],
  ["gpt-5.1","GPT-5.1",[],[["MODEL_PRIVATE_12","GPT-5.1 No Thinking",272000,128000],["MODEL_PRIVATE_13","GPT-5.1 Low Thinking",272000,128000],["MODEL_PRIVATE_14","GPT-5.1 Medium Thinking",272000,128000],["MODEL_PRIVATE_15","GPT-5.1 High Thinking",272000,128000]]],
  ["gpt-5.3-codex","GPT-5.3-Codex",["codex"],[["gpt-5-3-codex-low","GPT-5.3-Codex Low",400000,128000],["gpt-5-3-codex-medium","GPT-5.3-Codex Medium",400000,128000],["gpt-5-3-codex-high","GPT-5.3-Codex High",400000,128000],["gpt-5-3-codex-xhigh","GPT-5.3-Codex X-High",400000,128000],["gpt-5-3-codex-low-priority","GPT-5.3-Codex Low Fast",400000,128000],["gpt-5-3-codex-medium-priority","GPT-5.3-Codex Medium Fast",400000,128000],["gpt-5-3-codex-high-priority","GPT-5.3-Codex High Fast",400000,128000],["gpt-5-3-codex-xhigh-priority","GPT-5.3-Codex XHigh Fast",400000,128000]]],
  ["swe-1.6-fast","SWE-1.6 Fast",[],[["swe-1-6-fast","SWE-1.6 Fast",200000,128000]]],
  ["gemini-3.1-pro","Gemini 3.1 Pro",[],[["gemini-3-1-pro-low","Gemini 3.1 Pro Low Thinking",1048576,65535],["gemini-3-1-pro-high","Gemini 3.1 Pro High Thinking",1048576,65535]]],
  ["gemini-3.0-flash","Gemini 3 Flash",[],[["MODEL_GOOGLE_GEMINI_3_0_FLASH_MINIMAL","Gemini 3 Flash Minimal",1048576,65535],["MODEL_GOOGLE_GEMINI_3_0_FLASH_LOW","Gemini 3 Flash Low",1048576,65535],["MODEL_GOOGLE_GEMINI_3_0_FLASH_MEDIUM","Gemini 3 Flash Medium",1048576,65535],["MODEL_GOOGLE_GEMINI_3_0_FLASH_HIGH","Gemini 3 Flash High",1048576,65535]]],
]

const familiesOf = (rows) => rows.map(([uid, label, aliases, vs]) => ({ uid, label, aliases, models: vs.map(([id, name, context, output]) => ({ id, name, context, output })) }))
const SNAPSHOT_FAMILIES = familiesOf(SNAPSHOT)

// parseFamilies reads `devin models list --format json`.
function parseFamilies(text) {
  let list
  try {
    list = JSON.parse(text)
  } catch {
    return []
  }
  const out = []
  for (const f of list?.families ?? []) {
    if (!f?.family_uid) continue
    const low = String(f.family_uid).toLowerCase()
    if (low === "adaptive" || low === "fusion") continue
    out.push({
      uid: f.family_uid,
      label: f.family_label || f.family_uid,
      aliases: f.aliases ?? [],
      models: (f.variants ?? [])
        .filter((v) => v?.model_uid)
        .map((v) => ({ id: v.model_uid, name: v.label || v.model_uid, context: v.max_context_tokens || 0, output: v.max_output_tokens || 0 })),
    })
  }
  return out
}

const LEVEL_RANK = ["none", "minimal", "low", "medium", "high", "xhigh", "max"]
// the effort words Devin's variant ids end in (swe-2-high, …_HIGH,
// gpt-6-sol-none), and the level each is
const LEVELS = [["none", "none"], ["xhigh", "xhigh"], ["minimal", "minimal"], ["min", "minimal"], ["low", "low"], ["medium", "medium"], ["high", "high"], ["max", "max"]]
// the words a variant id may end in after its effort, for a quicker run of
// the same model at it (claude-opus-5-5-high-fast)
const TIERS = [["fast", "Fast"], ["priority", "Priority"]]

// levelOf is the effort an id says it runs at, "" when it says none.
function levelOf(id) {
  const low = id.toLowerCase()
  for (const [word, level] of LEVELS) if (low.endsWith("-" + word) || low.endsWith("_" + word)) return level
  return ""
}

// tierOf is the tier an id is in and its effort: claude-opus-5-5-high-fast
// is ["fast", "high"], swe-2-high ["", "high"]; a tier word with no effort
// before it (swe-1-6-fast) is no tier.
function tierOf(id) {
  const low = id.toLowerCase()
  for (const [word] of TIERS)
    for (const sep of ["-", "_"])
      if (low.endsWith(sep + word)) {
        const l = levelOf(low.slice(0, -(sep + word).length))
        if (l) return [word, l]
      }
  return ["", levelOf(id)]
}

const named = (f, id) => f.uid === id || f.aliases.includes(id)

// byLevel is the family's variant at each effort, in the tier, the first
// at each.
function byLevel(f, tier) {
  const out = {}
  for (const m of f.models) {
    const [t, l] = tierOf(m.id)
    if (t === tier && l && m.id !== f.uid && !out[l]) out[l] = m.id
  }
  return out
}

const efforts = (f, tier) => {
  const by = byLevel(f, tier)
  return LEVEL_RANK.filter((l) => by[l])
}

const tiers = (f) => TIERS.map(([w]) => w).filter((t) => Object.keys(byLevel(f, t)).length > 0)

// suffixed is whether an id is another variant's with a word after its
// effort that is no tier: SWE-2's swe-2-medium-lightning, which Devin
// lists at the High cost tier beside the free swe-2-medium (2026-10-15).
function suffixed(id) {
  const i = id.lastIndexOf("-")
  if (i < 0) return false
  const word = id.slice(i + 1).toLowerCase()
  return !TIERS.some(([w]) => w === word) && levelOf(id.slice(0, i)) !== ""
}

// defaultModel is the variant a family's id asks for when no effort is
// asked: its first that isn't suffixed, as the first Devin lists may be a
// paid -lightning one; the first when all are.
function defaultModel(f) {
  return f.models.find((m) => !suffixed(m.id)) ?? f.models[0]
}

// defaultLevel is the effort of the variant the family's id asks for when
// none is asked (defaultModel), medium when that names none.
function defaultLevel(f) {
  if (f.models.length) {
    const [t, l] = tierOf(defaultModel(f).id)
    if (!t && l) return l
  }
  return "medium"
}

// nearest is the one of levels nearest the one asked for, a tie going up.
function nearest(want, levels) {
  const at = LEVEL_RANK.indexOf(want)
  if (at < 0 || !levels.length || levels.includes(want)) return want
  let best = want
  let dist = LEVEL_RANK.length
  for (const l of levels) {
    const i = LEVEL_RANK.indexOf(l)
    const d = Math.abs(i - at)
    if (d < dist || (d === dist && i > at)) [best, dist] = [l, d]
  }
  return best
}

// variantFor is the model to ask the API for: a family's id follows its
// newest model, which the API takes only as one of its variants — the one
// at the effort asked for, or the nearest the family has; with none asked,
// the family's default. A family's fast run is its fast variant at that
// effort. A family the account's list doesn't name (picked from SNAPSHOT's
// list, which OpenCode's config offers) is SNAPSHOT's family, so swe-2
// goes as swe-2-high, never as the bare family id Devin takes as no
// model. Any other id (a variant's own) goes as it is.
function variantFor(families, model, effort) {
  for (const f of families) {
    if (!named(f, model) || !f.models.length) continue
    if (effort) {
      const id = byLevel(f, "")[nearest(effort, efforts(f, ""))]
      if (id) return id
    }
    return defaultModel(f).id
  }
  for (const f of families)
    for (const tier of tiers(f)) {
      if (!model.endsWith("-" + tier) || !named(f, model.slice(0, -(tier.length + 1)))) continue
      const by = byLevel(f, tier)
      const levels = efforts(f, tier)
      return by[nearest(effort || defaultLevel(f), levels)] || by[levels[0]]
    }
  if (families !== SNAPSHOT_FAMILIES && !families.some((f) => f.models.some((m) => m.id === model)))
    return variantFor(SNAPSHOT_FAMILIES, model, effort)
  return model
}

// listed is Devin's list as it is offered: each family one model, with
// the efforts its variants are at (picked as any model's effort is, and
// turned into the variant by variantFor), its fast run likewise, and the
// variants at no effort (glm-5-2-1m); a family's only variant is its id.
// A variant in keep (one the user picked: swe-2-medium) stays, at the one
// effort its id is at, and goes to Devin as it is, as magpie's built-in
// keeps it (devinCollapse).
// Each entry says whether it takes images (image) as images, Devin's word
// for each variant id, gives it: a variant its own, a family (and its fast
// run) what all its variants Devin named say; undefined when Devin said
// nothing of it or its variants disagree. An entry is free (free: true) when
// every variant of Devin's it stands for is in free, the ids Devin says its
// quota doesn't count (parseFree). A family stands for the variants
// variantFor sends it as, those at an effort and its default, not every
// model Devin files under it: Devin gives SWE-2 three -lightning variants
// at the High cost tier (2026-10-15), which no effort of swe-2 is sent as,
// and with them in, swe-2 was no longer free. An entry's price (cost) is
// what Devin lists for the variants it stands for when they all list the
// same (parsePrices); none when they differ or Devin lists none.
function listed(families, keep = [], images = {}, free = new Set(), prices = new Map()) {
  const all = (ids) => ids.length > 0 && ids.every((id) => free.has(id))
  const priced = (ids) => {
    const ps = ids.map((id) => prices.get(id))
    if (!ps.length || !ps[0] || ps.some((p) => JSON.stringify(p) !== JSON.stringify(ps[0]))) return undefined
    return ps[0]
  }
  const own = (f, t) => {
    const ids = Object.values(byLevel(f, t))
    if (!t && f.models.length && !ids.includes(defaultModel(f).id)) ids.push(defaultModel(f).id)
    return ids
  }
  const out = []
  const seen = new Set()
  const add = ({ free, cost, ...m }) => {
    if (seen.has(m.id)) return
    seen.add(m.id)
    out.push({ ...m, ...(free ? { free } : cost ? { cost } : {}) })
  }
  for (const f of families) {
    const context = f.models.find((m) => m.context)?.context ?? 0
    const output = f.models.find((m) => m.output)?.output ?? 0
    const image = familyImages(f, images)
    add({ id: f.uid, name: f.label, context, output, efforts: efforts(f, ""), image, free: all(own(f, "")), cost: priced(own(f, "")) })
    for (const t of tiers(f)) {
      const id = f.uid + "-" + t
      if (families.some((g) => named(g, id))) continue
      add({ id, name: f.label + " " + TIERS.find(([w]) => w === t)[1], context, output, efforts: efforts(f, t), image, free: all(own(f, t)), cost: priced(own(f, t)) })
    }
    if (f.models.length === 1) continue
    for (const m of f.models) {
      if (m.id === f.uid || tierOf(m.id)[1]) continue
      add({ id: m.id, name: m.name, context: m.context || context, output: m.output || output, efforts: [], image: images[m.id], free: free.has(m.id), cost: prices.get(m.id) })
    }
  }
  for (const id of keep) {
    if (seen.has(id)) continue
    const f = families.find((g) => g.models.some((m) => m.id === id))
    const m = f?.models.find((m) => m.id === id)
    const level = tierOf(id)[1]
    if (!m && !level) continue
    add({ id, name: m?.name || id, context: m?.context ?? 0, output: m?.output ?? 0, efforts: level ? [level] : [], image: images[id], free: free.has(id), cost: prices.get(id) })
  }
  return out
}

// familyImages is what a family's variants Devin named all say of images.
function familyImages(f, images) {
  let said
  for (const m of f.models) {
    const v = images[m.id]
    if (typeof v !== "boolean") continue
    if (said !== undefined && said !== v) return undefined
    said = v
  }
  return said
}

// Which of Devin's models take images is what Devin tells its CLI's model
// picker (GetCliModelConfigs: each ClientModelConfig's supports_images), as
// magpie's built-in asks it (devin_images.go): `devin models list` says
// nothing of images and models.dev doesn't know Devin's own ids, so swe-2
// was said to take none and agents dropped its images (面条 on magpie's
// Discord). NO_IMAGES are the ids Devin said take none, as of 2026-11-05;
// every other id in SNAPSHOT takes them, which is what a list is told
// before Devin is asked, or when it can't be.
const NO_IMAGES = new Set([
  "glm-5-2", "glm-5-2-max", "glm-5-2-1m", "glm-5-2-max-1m", "glm-5-2-none", "glm-5-2-none-1m",
  "glm-5-3-low", "glm-5-3-high", "glm-5-3-max",
  "inkling-none", "inkling-low", "inkling-medium", "inkling-high", "inkling-xhigh", "inkling-max",
  "deepseek-v4-flash-high", "deepseek-v4-flash-max", "deepseek-v4-pro-high", "deepseek-v4-pro-max",
  "nemotron-3-ultra-none", "nemotron-3-ultra-medium", "nemotron-3-ultra-high",
  "swe-2-flash-medium", "swe-2-flash-high", "swe-2-flash-max",
])
const SNAPSHOT_IMAGES = Object.fromEntries(SNAPSHOT.flatMap(([, , , vs]) => vs.map(([id]) => [id, !NO_IMAGES.has(id)])))

const MODEL_CONFIGS_RPC = "/exa.api_server_pb.ApiServerService/GetCliModelConfigs"

// parseModelConfigs reads GetCliModelConfigsResponse: its
// client_model_configs (1), each with its model_uid (22) and
// supports_images (5), a bool proto3 leaves out when false.
function parseModelConfigs(b) {
  const out = {}
  for (const f of fields(b)) {
    if (f.num !== 1 || f.wire !== 2) continue
    let uid = ""
    let images = false
    for (const g of fields(f.data)) {
      if (g.num === 22 && g.wire === 2) uid = dec.decode(g.data)
      else if (g.num === 5 && g.wire === 0) images = g.n !== 0
    }
    if (uid) out[uid] = images
  }
  return Object.keys(out).length ? out : null
}

// FREE_TIER is the model_cost_tier (ClientModelConfig's 24) of a model the
// account's quota doesn't count: the CLI's picker labels its tiers "Low
// cost", "Med cost", "High cost" and "Free", 1 to 4. On 2026-10-14 Devin
// gave SWE-2's three variants 4 and no other model of its 262 (太陽と向日葵
// on magpie's Discord: with the quota used up, SWE-2 still answered, but
// magpie held the account for it as for every other model).
const FREE_TIER = 4

// parseFree reads the same response for the ids of the models that are
// free: each config's model_uid (22) whose model_cost_tier (24) is
// FREE_TIER. A config that says no tier is not free.
function parseFree(b) {
  const out = new Set()
  for (const f of fields(b)) {
    if (f.num !== 1 || f.wire !== 2) continue
    let uid = ""
    let tier = 0
    for (const g of fields(f.data)) {
      if (g.num === 22 && g.wire === 2) uid = dec.decode(g.data)
      else if (g.num === 24 && g.wire === 0) tier = g.n
    }
    if (uid && tier === FREE_TIER) out.add(uid)
  }
  return out
}

// parsePrices reads the same response for what Devin lists each model at,
// in USD per 1M tokens: a config's model_uid (22) and its prices (32, one
// each), each a label (1: "Input", "Cached input", "Output"), a fixed32
// float (2) and its unit (3: "1M tokens"). A model in the Free tier lists
// none. Only a price per 1M tokens is taken, and a model is priced only
// when it lists input or output above 0.
function parsePrices(b) {
  const out = new Map()
  const words = { Input: "input", "Cached input": "read", Output: "output" }
  for (const f of fields(b)) {
    if (f.num !== 1 || f.wire !== 2) continue
    let uid = ""
    const p = {}
    for (const g of fields(f.data)) {
      if (g.num === 22 && g.wire === 2) uid = dec.decode(g.data)
      else if (g.num === 32 && g.wire === 2) {
        let label = ""
        let unit = ""
        let v = NaN
        for (const h of fields(g.data)) {
          if (h.num === 1 && h.wire === 2) label = dec.decode(h.data)
          else if (h.num === 3 && h.wire === 2) unit = dec.decode(h.data)
          else if (h.num === 2 && h.wire === 5) v = new DataView(h.data.buffer, h.data.byteOffset, 4).getFloat32(0, true)
        }
        // a float32's 1.4 is 1.39999997…: the price as Devin wrote it
        if (words[label] && unit === "1M tokens" && Number.isFinite(v) && v >= 0) p[words[label]] = +v.toPrecision(6)
      }
    }
    if (uid && (p.input > 0 || p.output > 0)) out.set(uid, { input: p.input ?? 0, output: p.output ?? 0, cache: { read: p.read ?? 0 } })
  }
  return out
}

// parseConfigFamilies reads the same response as the families `devin
// models list` makes of it, in its order: each config's label (1), context
// (18), and model_info (23) with its output (13) and family uid (23); the
// family's label is its family_metadata's (30) first field. A config that
// names no family is a family of its own under its label, as the CLI makes
// MODEL_PRIVATE_11 "Claude Haiku 4.5". The aliases are the CLI's own, so
// they are taken from SNAPSHOT's family of the same id.
function parseConfigFamilies(b) {
  const fams = new Map()
  for (const f of fields(b)) {
    if (f.num !== 1 || f.wire !== 2) continue
    let uid = ""
    let name = ""
    let context = 0
    let output = 0
    let fam = ""
    let famLabel = ""
    for (const g of fields(f.data)) {
      if (g.num === 22 && g.wire === 2) uid = dec.decode(g.data)
      else if (g.num === 1 && g.wire === 2) name = dec.decode(g.data)
      else if (g.num === 18 && g.wire === 0) context = g.n
      else if (g.num === 23 && g.wire === 2) {
        for (const h of fields(g.data)) {
          if (h.num === 13 && h.wire === 0) output = h.n
          else if (h.num === 23 && h.wire === 2) fam = dec.decode(h.data)
        }
      } else if (g.num === 30 && g.wire === 2) {
        for (const h of fields(g.data)) if (h.num === 1 && h.wire === 2) famLabel = dec.decode(h.data)
      }
    }
    if (!uid) continue
    const id = fam || famLabel || name || uid
    const low = id.toLowerCase()
    if (low === "adaptive" || low === "fusion") continue
    let e = fams.get(id)
    if (!e) {
      const known = SNAPSHOT.find(([u]) => u === id)
      fams.set(id, (e = { uid: id, label: famLabel || name || id, aliases: known ? known[2] : [], models: [] }))
    }
    e.models.push({ id: uid, name: name || uid, context, output })
  }
  return [...fams.values()]
}

// Each account's word on images and its list, kept and asked again as the
// CLI's list is.
const said = new Map()

// configsFor is what Devin last said of key's account's models
// ({images, families}, each null until it has said); with wait false, a
// first ask isn't waited for. A failed ask keeps what was said before and
// is asked again after RETRY; its reason is kept (error) and logged once
// when the asks start failing, so a list or free models that never come
// say why (usage shows it too).
async function configsFor(key, server, wait = true) {
  let c = said.get(key)
  if (!c) said.set(key, (c = { images: null, families: null, free: new Set(), prices: new Map(), at: 0, failed: 0, error: "", asking: null }))
  const ask = () =>
    (c.asking ??= (async () => {
      try {
        const res = await fetch(server + MODEL_CONFIGS_RPC, {
          method: "POST",
          headers: { "Content-Type": "application/proto", "Connect-Protocol-Version": "1" },
          body: new PB().bytes(1, metadata(key)).done(),
          signal: AbortSignal.timeout(15_000),
        })
        if (!res.ok) throw new Error(`GetCliModelConfigs: ${res.status}`)
        const b = new Uint8Array(await res.arrayBuffer())
        const images = parseModelConfigs(b)
        if (!images) throw new Error("GetCliModelConfigs: no models")
        const families = parseConfigFamilies(b)
        Object.assign(c, { images, families: families.length ? families : null, free: parseFree(b), prices: parsePrices(b), at: Date.now(), failed: 0, error: "" })
      } catch (e) {
        const why = e?.message || String(e)
        if (!c.error) console.error(`devin: GetCliModelConfigs failed (${why}); ${c.images ? "the last list is kept" : "the free models and the account's own list are unknown"}, asked again every ${RETRY / 1000}s`)
        Object.assign(c, { failed: Date.now(), error: why })
      } finally {
        c.asking = null
      }
    })())
  if (!c.images || Date.now() - c.at >= FRESH) {
    if (Date.now() - c.failed >= RETRY) {
      const p = ask()
      if (wait && !c.images) await p
    }
  }
  return c
}

// imagesFor is what Devin says of each model id's images for key's
// account, SNAPSHOT_IMAGES under it; with wait false, a first ask isn't
// waited for.
async function imagesFor(key, server, wait = true) {
  const c = await configsFor(key, server, wait)
  return { ...SNAPSHOT_IMAGES, ...(c.images ?? {}) }
}

// seesImages is whether a model Devin said nothing of takes images, as
// magpie's built-in tells it (models.go: m.Images || catalog.SeesImages):
// models.dev's word for the id — most of the providers listing it taking
// images — from the catalog magpie's `magpie sync` or OpenCode keeps, and
// no when neither has it.
let seen = null
function seesImages(id) {
  if (!seen) {
    seen = new Set()
    const cache = process.env.XDG_CACHE_HOME || join(homedir(), ".cache")
    for (const p of [join(cache, "magpie", "models.json"), join(homedir(), ".cache", "opencode", "models.json")]) {
      let m
      try {
        m = JSON.parse(readFileSync(p, "utf8"))
      } catch {
        continue
      }
      if (!m || typeof m !== "object" || !Object.keys(m).length) continue
      const votes = new Map()
      for (const pr of Object.values(m))
        for (const [mid, x] of Object.entries(pr?.models ?? {})) {
          const b = bare(mid)
          votes.set(b, (votes.get(b) ?? 0) + ((x?.modalities?.input ?? []).includes("image") ? 1 : -1))
        }
      for (const [b, v] of votes) if (v > 0) seen.add(b)
      break
    }
  }
  return seen.has(bare(id))
}
const bare = (id) => String(id).toLowerCase().split("/").pop()

function configModel(m) {
  const image = m.image ?? seesImages(m.id)
  return {
    id: m.id,
    name: m.name,
    tool_call: true,
    reasoning: m.efforts.length > 0,
    attachment: image,
    temperature: true,
    modalities: { input: image ? ["text", "image"] : ["text"], output: ["text"] },
    limit: { context: m.context, output: m.output },
    ...(isClaude(m.id) ? { provider: { npm: ANTHROPIC, api: BASE } } : {}),
    ...(m.efforts.length ? { variants: Object.fromEntries(m.efforts.map((e) => [e, variantOf(m.id, e)])) } : {}),
  }
}

function runtimeModel(m) {
  const image = m.image ?? seesImages(m.id)
  return {
    id: m.id,
    providerID: ID,
    name: m.name,
    api: { id: m.id, url: BASE, npm: npmOf(m.id) },
    status: "active",
    headers: {},
    options: {},
    cost: { input: m.cost?.input ?? 0, output: m.cost?.output ?? 0, cache: { read: m.cost?.cache?.read ?? 0, write: 0 } },
    limit: { context: m.context, output: m.output },
    capabilities: {
      temperature: true,
      reasoning: m.efforts.length > 0,
      attachment: image,
      toolcall: true,
      input: { text: true, image, audio: false, video: false, pdf: false },
      output: { text: true, image: false, audio: false, video: false, pdf: false },
      interleaved: false,
    },
    release_date: "",
    variants: Object.fromEntries(m.efforts.map((e) => [e, variantOf(m.id, e)])),
    // magpie's: a model the account's quota doesn't count
    ...(m.free ? { free: true } : {}),
  }
}

// withImages is a list of models with what entries (listed's) say of their
// images on them; a model they say nothing of is left as it was.
// fellBack marks a list that isn't the account's own (magpie's plugin
// host reads Symbol.for("magpie.fellBack"))
function fellBack(models) {
  return Object.assign(models, { [Symbol.for("magpie.fellBack")]: true })
}

function withImages(models, entries) {
  const by = new Map(entries.map((m) => [m.id, m.image]))
  return Object.fromEntries(
    Object.entries(models ?? {}).map(([id, m]) => {
      const image = by.get(id)
      if (typeof image !== "boolean") return [id, m]
      const caps = m?.capabilities ?? {}
      return [id, { ...m, capabilities: { ...caps, attachment: image, input: { ...(caps.input ?? { text: true }), image } } }]
    }),
  )
}

// ---- the devin CLI -----------------------------------------------------------------

// cliPath finds the devin CLI, "" without one.
function cliPath() {
  const exe = process.platform === "win32" ? "devin.exe" : "devin"
  for (const dir of (process.env.PATH ?? "").split(process.platform === "win32" ? ";" : ":"))
    if (dir && isFile(join(dir, exe))) return join(dir, exe)
  for (const p of [join(homedir(), ".local", "bin", "devin"), "/usr/local/bin/devin", "/opt/homebrew/bin/devin"]) if (isFile(p)) return p
  return ""
}

function isFile(p) {
  try {
    return statSync(p).isFile()
  } catch {
    return false
  }
}

// cliCredentialsPath is where the CLI keeps its own sign-in.
function cliCredentialsPath() {
  if (process.platform === "win32" && process.env.APPDATA) return join(process.env.APPDATA, "devin", "credentials.toml")
  return join(process.env.XDG_DATA_HOME || join(homedir(), ".local", "share"), "devin", "credentials.toml")
}

const tomlString = (s) => '"' + String(s).replaceAll("\\", "\\\\").replaceAll('"', '\\"') + '"'

// credentials is credentials.toml as `devin auth login` writes it.
function credentials(key, server, webapp, api) {
  return [
    ["windsurf_api_key", key],
    ["api_server_url", server || SERVER],
    ["devin_webapp_host", webapp || "app.devin.ai"],
    ["devin_api_url", api || "https://api.devin.ai"],
  ]
    .map(([k, v]) => `${k} = ${tomlString(v)}\n`)
    .join("")
}

// readCredentials reads the keys of a credentials.toml the CLI wrote.
function readCredentials(text) {
  const out = {}
  for (const line of text.split(/\r?\n/)) {
    const m = /^\s*([A-Za-z0-9_]+)\s*=\s*(?:"((?:[^"\\]|\\.)*)"|'([^']*)')\s*$/.exec(line)
    if (m) out[m[1]] = m[2] !== undefined ? m[2].replace(/\\(.)/g, "$1") : m[3]
  }
  return out
}

// homeFor is a data folder of this plugin's own, laid out as the CLI's,
// with the account's credentials in it: the CLI run with it as its data
// folder answers for that account, and its own sign-in is never touched.
async function homeFor(key, server) {
  const base = join(process.env.XDG_CACHE_HOME || join(homedir(), ".cache"), "opencode-devin-auth")
  const home = join(base, createHash("sha256").update(key).digest("hex").slice(0, 16))
  const file = join(home, "devin", "credentials.toml")
  if (!existsSync(file)) {
    await mkdir(join(home, "devin"), { recursive: true, mode: 0o700 })
    await writeFile(file, credentials(key, server), { mode: 0o600 })
  }
  return home
}

// runCLI runs the devin CLI, for the account in home ("" for its own),
// with its output; it asks Devin's servers, so it has 30 seconds.
function runCLI(home, ...args) {
  const path = cliPath()
  if (!path) return Promise.reject(new Error("devin is not installed"))
  const env = { ...process.env }
  if (home) {
    for (const k of Object.keys(env)) if (["XDG_DATA_HOME", "APPDATA"].includes(k.toUpperCase())) delete env[k]
    env.XDG_DATA_HOME = home
    env.APPDATA = home
  }
  return new Promise((resolve, reject) => {
    const p = spawn(path, args, { env, stdio: ["ignore", "pipe", "ignore"] })
    let out = ""
    p.stdout.on("data", (b) => (out += b))
    const timer = setTimeout(() => p.kill(), 30_000)
    p.on("error", (e) => {
      clearTimeout(timer)
      reject(e)
    })
    p.on("close", (code) => {
      clearTimeout(timer)
      resolve({ out, code })
    })
  })
}

// signedOut says the CLI's report is one of nobody signed in: it says so,
// or Devin's servers refused the account's token.
const signedOut = (out) => ["Not logged in", "Authentication required", "Invalid token", "try logging out and logging in again"].some((s) => out.includes(s))

// statusField is a field of `devin auth status`'s report, "" without it.
function statusField(out, key) {
  for (const l of out.split(/\r?\n/)) {
    const t = l.trim()
    if (t.startsWith(key + ":")) return t.slice(key.length + 1).trim()
  }
  return ""
}

// parseStatus reads `devin auth status`'s report: its User's Email (or
// Name), its Account's Tier (or Plan), and its Team ID when one is shown.
function parseStatus(out) {
  if (!out.includes("Logged in")) return null
  const field = (key) => statusField(out, key)
  const teamId = field("Team ID")
  return { user: field("Email") || field("Name"), plan: field("Tier") || field("Plan"), ...(teamId ? { teamId } : {}) }
}

// inside says file is in dir, whichever way either is spelled.
function inside(file, dir) {
  const real = (p) => {
    let r
    try {
      r = realpathSync(p)
    } catch {
      r = resolve(p)
    }
    return process.platform === "win32" ? r.toLowerCase() : r
  }
  const rel = relative(real(dir), real(file))
  return rel !== "" && !rel.startsWith("..") && !isAbsolute(rel)
}

// readsHome says the CLI's report is of the credentials.toml in home: the
// devin CLI on Windows reads %APPDATA%\devin\ whatever APPDATA it is run
// with (#17), and so answers for its own account, not home's. A report that
// names no file is taken at its word.
function readsHome(out, home) {
  const file = statusField(out, "File")
  return !home || !file || inside(file, home)
}

// identity is who the CLI says is signed in in home: {user, plan}, null
// when it says nobody is, undefined when it can't tell (no CLI, no answer,
// a CLI that read another credentials.toml than home's).
async function identity(home) {
  try {
    const { out } = await runCLI(home, "auth", "status")
    if (!readsHome(out, home)) return undefined
    const st = parseStatus(out)
    if (st?.user) return st
    if (signedOut(out)) return null
  } catch {}
  return undefined
}

// tierName words a teamsTier as `devin auth status` says it:
// TEAMS_TIER_DEVIN_PRO is "Devin Pro", TEAMS_TIER_DEVIN_TEAMS_V2 "Devin
// Teams" (the CLI leaves the tier's version out).
const tierName = (t) =>
  String(t ?? "")
    .replace(/^TEAMS_TIER_/, "")
    .split("_")
    .filter((w) => w && w !== "UNSPECIFIED" && !/^V\d+$/.test(w))
    .map((w) => w[0] + w.slice(1).toLowerCase())
    .join(" ")

// whoOfStatus names the account GetUserStatus describes: its email (or
// handle), and for a seat in an organization the organization's display
// name too ("email · org"), so two organizations under one email are kept
// apart as two accounts with their own quota pools.
function whoOfStatus(u = {}) {
  const base = String(u.email || u.name || "").trim()
  if (!base) return undefined
  const info = u.planStatus?.planInfo ?? {}
  const devin = info.devinInfo ?? {}
  const org = String(devin.accountDisplayName || info.teamName || u.teamName || "").trim()
  const orgId = String(devin.orgId || u.teamId || "").trim()
  const teamId = String(u.teamId || "").trim()
  const named = org && org.toLowerCase() !== base.toLowerCase()
  const user = named ? `${base} · ${org}` : base
  return {
    user,
    ...(named ? { email: base } : {}),
    plan: tierName(u.teamsTier || info.teamsTier) || info.planName || "",
    ...(orgId ? { orgId } : {}),
    ...(teamId ? { teamId } : {}),
  }
}

// whoByKey is whose key it is, as GetUserStatus (usage's) says, asked with
// the key itself: {user, plan, orgId?, teamId?}, null when Devin refuses
// the key, undefined when it can't tell.
async function whoByKey(key, server) {
  let res, text
  try {
    res = await userStatus(key, server || SERVER)
    text = await res.text()
  } catch {
    return undefined
  }
  if (res.status === 401 || failure(res.status, text).status === 401) return null
  if (!res.ok) return undefined
  let u
  try {
    u = JSON.parse(text || "{}")?.userStatus ?? {}
  } catch {
    return undefined
  }
  return whoOfStatus(u)
}

// cliAnswersFor says whether the CLI, run with home as its data folder,
// answers for key's account: the account it names is the one Devin says
// the key is. A CLI that reads another credentials.toml than home's (on
// Windows it reads %APPDATA%\devin\ whatever APPDATA it is given, #17)
// answers only when it names that account; one that reads home's is taken
// at its word when Devin can't tell. undefined when it can't tell.
async function cliAnswersFor(key, server, home) {
  let out
  try {
    ;({ out } = await runCLI(home, "auth", "status"))
  } catch {
    return undefined
  }
  const own = readsHome(out, home)
  const st = parseStatus(out)
  if (!st?.user) return own
  const who = await whoByKey(key, server)
  if (!who?.user) return own
  if (who.teamId && st.teamId && who.teamId !== st.teamId) return false
  return (who.email || who.user).toLowerCase() === st.user.toLowerCase()
}

// Each account's model list as the CLI last gave it, kept FRESH; one past
// its time is served while it is read again, one that failed is asked
// again after RETRY. A CLI that doesn't answer for the account (#17: on
// Windows it lists its own account's) is never asked for it.
const lists = new Map()

// familiesFor is key's account's list: what Devin tells the CLI's model
// picker for the key (GetCliModelConfigs, the list `devin models list`
// prints, asked with the key itself, so on any system and for every
// account), else the CLI's when it answers for the account, else Devin's
// list as of SNAPSHOT. On Windows the CLI answered for no account added
// in the browser, and an account without the CLI had only SNAPSHOT, so
// neither got Gemini 4 Argon (plugins #115).
async function familiesFor(key, server, wait = true) {
  return (await ownFamilies(key, server, wait)) ?? familiesOf(SNAPSHOT)
}

// ownFamilies is familiesFor's list when Devin or the CLI gave one, null
// when neither has.
async function ownFamilies(key, server, wait = true) {
  const told = (await configsFor(key, server, wait)).families
  if (told) return told
  let c = lists.get(key)
  if (!c) lists.set(key, (c = { families: null, at: 0, failed: 0, asking: null, cli: undefined }))
  const ask = () =>
    (c.asking ??= (async () => {
      try {
        const home = await homeFor(key, server)
        if (c.cli === undefined) c.cli = await cliAnswersFor(key, server, home)
        if (c.cli === false) return
        const { out } = await runCLI(home, "models", "list", "--format", "json")
        const fams = parseFamilies(out)
        if (!fams.length) throw new Error("devin models list: no models")
        Object.assign(c, { families: fams, at: Date.now(), failed: 0 })
      } catch {
        c.failed = Date.now()
      } finally {
        c.asking = null
      }
    })())
  if (c.families) {
    if (Date.now() - c.at >= FRESH && Date.now() - c.failed >= RETRY && c.cli !== false && cliPath()) ask()
    return c.families
  }
  if (c.cli !== false && cliPath() && Date.now() - c.failed >= RETRY) {
    const p = ask()
    if (wait) await p
  }
  return c.families
}

// ---- signing in ----------------------------------------------------------------------

function page(ok, title, text) {
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c])
  return `<!doctype html><meta charset="utf-8"><title>${esc(title)}</title>
<style>body{font:15px system-ui,sans-serif;display:grid;place-items:center;min-height:90vh;margin:0;color:#222;background:#fafafa}
@media (prefers-color-scheme:dark){body{color:#eee;background:#161616}}main{text-align:center;max-width:28rem;padding:1rem}
.d{font-size:2rem;color:${ok ? "#2a9d5c" : "#c0392b"}}</style>
<main><div class="d">${ok ? "✓" : "✕"}</div><h1>${esc(title)}</h1><p>${esc(text)}</p></main>`
}

// exchange trades the callback's code for the session token `devin auth
// login` keeps — already shaped "devin-session-token$<jwt>" — and the
// hosts the account is on.
async function exchange(code, verifier, redirect) {
  const res = await fetch(SERVER + EXCHANGE, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({ code, code_verifier: verifier, redirect_uri: redirect }),
    signal: AbortSignal.timeout(30_000),
  })
  const text = await res.text()
  if (!res.ok) throw new Error(`Devin's exchange: ${res.status} ${text.slice(0, 300)}`)
  let r = {}
  try {
    r = JSON.parse(text)
  } catch {}
  const key = r.sessionToken || r.session_token
  if (!key) throw new Error("Devin's exchange returned no session token")
  return { key, webapp: r.devinWebappHost, api: r.devinApiUrl }
}

// unknownAccount names a credential without revealing it. The same key on
// the same server keeps its slot, while two unreadable accounts don't both
// become "Devin" and replace each other in magpie (#931).
const unknownAccount = (key, server) =>
  `Devin · ${createHash("sha256").update(server || SERVER).update("\0").update(key).digest("hex").slice(0, 12)}`

// success names a key's account as Devin does when asked with the key
// (GetUserStatus), or, when Devin can't tell, as the CLI does in a data
// folder of the plugin's own: never by the CLI alone, which on Windows
// names its own account whatever key it is given (#17). A key Devin or the
// CLI says nobody is signed in with fails it; with neither able to tell,
// a stable fingerprint keeps that credential apart from another (#931).
async function success(key, server) {
  let who = await whoByKey(key, server)
  if (who === undefined) who = await identity(await homeFor(key, server))
  if (who === null) throw new Error("Devin didn't take the sign-in: nobody is signed in with the token it gave")
  const metadata = { email: who?.user || unknownAccount(key, server) }
  if (who?.plan) metadata.plan = who.plan
  const orgId = who?.orgId || who?.teamId
  if (orgId) metadata.orgId = orgId
  if (who?.teamId) metadata.teamId = who.teamId
  if (server && server !== SERVER) metadata.server = server
  return { type: "success", provider: ID, key, metadata }
}

// browserSignIn is `devin auth login`'s round, run by the plugin: PKCE
// through app.devin.ai, back to a callback on 127.0.0.1.
async function browserSignIn() {
  const verifier = randomBytes(48).toString("base64url")
  const state = randomBytes(24).toString("base64url")
  const challenge = createHash("sha256").update(verifier).digest("base64url")
  let over = false
  let settle
  const done = new Promise((r) => (settle = r))
  const finish = (result) => {
    if (over) return
    over = true
    settle(result)
  }
  let redirect = ""
  const server = createServer(async (req, res) => {
    const url = new URL(req.url ?? "/", "http://127.0.0.1")
    const html = (code, body) => {
      res.writeHead(code, { "Content-Type": "text/html; charset=utf-8" })
      res.end(body)
    }
    if (url.pathname !== "/callback") return res.writeHead(404).end()
    const q = url.searchParams
    if (over) return html(200, page(false, "This sign-in is over", "Start it again."))
    if (q.get("error")) {
      const msg = q.get("error_description") || q.get("error")
      finish({ type: "failed", error: msg })
      return html(200, page(false, "Sign-in didn't finish", msg))
    }
    if (q.get("state") !== state || !q.get("code")) return html(200, page(false, "This link isn't from this sign-in", "Start it again."))
    try {
      const x = await exchange(q.get("code"), verifier, redirect)
      const r = await success(x.key, SERVER)
      finish(r)
      html(200, page(true, "You're signed in", `${r.metadata.email} is signed in. You can close this tab.`))
    } catch (e) {
      finish({ type: "failed", error: e.message })
      html(200, page(false, "Sign-in didn't finish", e.message))
    }
  })
  await new Promise((resolve, reject) => {
    server.once("error", reject)
    server.listen(0, "127.0.0.1", resolve)
  })
  redirect = `http://127.0.0.1:${server.address().port}/callback`
  const timer = setTimeout(() => finish({ type: "failed", error: "the sign-in timed out" }), SIGN_IN_TIMEOUT)
  done.then(() => {
    clearTimeout(timer)
    setTimeout(() => server.close(), 5_000).unref?.()
  })
  const q = new URLSearchParams({
    redirect_uri: redirect,
    state,
    prompt: "select_account",
    code_challenge: challenge,
    code_challenge_method: "S256",
    cli_pkce_marker: "1",
  })
  return {
    url: `${AUTHORIZE}?${q}`,
    instructions: "Sign in to Devin in the browser.",
    method: "auto",
    callback: () => done,
  }
}

// cliSignIn takes the account the devin CLI is signed in to, reading its
// credentials.toml and changing nothing.
async function cliSignIn() {
  const path = cliCredentialsPath()
  return {
    url: "",
    instructions: `Uses the account in ${path}.`,
    method: "auto",
    callback: async () => {
      try {
        const c = readCredentials(await readFile(path, "utf8"))
        if (!c.windsurf_api_key) return { type: "failed", error: `Devin isn't signed in: ${path} has no key` }
        const r = await success(c.windsurf_api_key, (c.api_server_url || SERVER).replace(/\/+$/, ""))
        // a string: OpenCode 1 keeps an auth's metadata as strings and drops
        // an auth.json entry with any other value, so its requests go past
        // this fetch to BASE (a 404). live() takes it as truthy.
        r.metadata.cli = "true"
        return r
      } catch (e) {
        return { type: "failed", error: e?.code === "ENOENT" ? "Devin isn't signed in: run `devin auth login`" : e.message }
      }
    },
  }
}

// ---- protobuf, by hand ---------------------------------------------------------------

const enc = new TextEncoder()
const dec = new TextDecoder()

// pb builds a protobuf message field by field.
class PB {
  constructor() {
    this.parts = []
  }
  uvarint(n) {
    const b = []
    n = BigInt(n)
    while (n >= 0x80n) {
      b.push(Number(n & 0x7fn) | 0x80)
      n >>= 7n
    }
    b.push(Number(n))
    this.parts.push(Uint8Array.from(b))
  }
  varint(num, v) {
    this.uvarint((num << 3) | 0)
    this.uvarint(v)
    return this
  }
  bytes(num, v) {
    if (typeof v === "string") v = enc.encode(v)
    else if (v instanceof PB) v = v.done()
    this.uvarint((num << 3) | 2)
    this.uvarint(v.length)
    this.parts.push(v)
    return this
  }
  str(num, v) {
    return this.bytes(num, v)
  }
  double(num, v) {
    this.uvarint((num << 3) | 1)
    const b = new Uint8Array(8)
    new DataView(b.buffer).setFloat64(0, v, true)
    this.parts.push(b)
    return this
  }
  done() {
    const n = this.parts.reduce((s, p) => s + p.length, 0)
    const out = new Uint8Array(n)
    let at = 0
    for (const p of this.parts) {
      out.set(p, at)
      at += p.length
    }
    return out
  }
}

// fields reads a message's fields; a malformed tail is dropped.
function fields(b) {
  const out = []
  let i = 0
  const uvarint = () => {
    let n = 0n
    let shift = 0n
    for (;;) {
      if (i >= b.length) return null
      const c = b[i++]
      n |= BigInt(c & 0x7f) << shift
      if (!(c & 0x80)) return n
      shift += 7n
    }
  }
  while (i < b.length) {
    const key = uvarint()
    if (key === null) break
    const f = { num: Number(key >> 3n), wire: Number(key & 7n), n: 0, data: null }
    if (f.wire === 0) {
      const v = uvarint()
      if (v === null) break
      f.n = Number(v)
    } else if (f.wire === 1) {
      if (i + 8 > b.length) break
      i += 8
    } else if (f.wire === 2) {
      const l = uvarint()
      if (l === null || i + Number(l) > b.length) break
      f.data = b.subarray(i, i + Number(l))
      i += Number(l)
    } else if (f.wire === 5) {
      if (i + 4 > b.length) break
      f.data = b.subarray(i, i + 4)
      i += 4
    } else break
    out.push(f)
  }
  return out
}

// frame wraps a message as the one frame of a Connect stream. A message
// past GZIP_AT goes gzipped (flag 1, with Connect-Content-Encoding: gzip),
// as the devin CLI sends it: Devin's nginx turns away a body past 10 MiB on
// the wire (413). The CLI (3000.11.92) gzips a GetChatMessage of 8,333
// bytes and sends one of 8,083 as it is, and names the encoding only on a
// gzipped request; it sends no Connect-Accept-Encoding.
const GZIP_AT = 8 << 10
function frame(msg) {
  const zip = msg.length > GZIP_AT
  const body = zip ? gzipSync(msg) : msg
  const out = new Uint8Array(5 + body.length)
  out[0] = zip ? 1 : 0
  new DataView(out.buffer).setUint32(1, body.length)
  out.set(body, 5)
  return out
}

// frames reads a Connect stream: each message, or its end with its JSON.
async function* frames(body) {
  let buf = new Uint8Array(0)
  const reader = body.getReader()
  try {
    for (;;) {
      while (buf.length >= 5) {
        const n = new DataView(buf.buffer, buf.byteOffset).getUint32(1)
        if (n > 64 << 20) throw new Error("a malformed stream")
        if (buf.length < 5 + n) break
        const flags = buf[0]
        let data = buf.slice(5, 5 + n)
        buf = buf.slice(5 + n)
        if (flags & 1) data = new Uint8Array(gunzipSync(data))
        yield { end: !!(flags & 2), data }
      }
      const { value, done } = await reader.read()
      if (done) {
        if (buf.length) throw new Error("unexpected EOF")
        return
      }
      const next = new Uint8Array(buf.length + value.length)
      next.set(buf)
      next.set(value, buf.length)
      buf = next
    }
  } finally {
    reader.releaseLock()
  }
}

// ---- the request ----------------------------------------------------------------------

const USER = 1
const ASSISTANT = 2
const TOOL = 4
// answers a call the conversation never answered
const NO_RESULT = "Tool use was interrupted and did not produce a result."

const textOf = (c) =>
  typeof c === "string" ? c : Array.isArray(c) ? c.filter((p) => p?.type === "text").map((p) => p.text ?? "").join("") : ""

// joinSplitCalls joins an assistant message onto the assistant message
// before it when that one made tool calls: Anthropic takes consecutive
// assistant messages as one turn, and an agent can send a turn's parallel
// calls split over two of them, answered together after (yetone/magpie#1275).
// Answered at the second message, the first calls would be marked
// interrupted and their real results dropped. msgs is left as it is.
function joinSplitCalls(msgs) {
  const out = []
  for (const m of msgs) {
    const prev = out.at(-1)
    if (m?.role === "assistant" && prev?.role === "assistant" && prev.tool_calls?.length) {
      const content = [textOf(prev.content), textOf(m.content)].filter(Boolean).join("\n\n")
      const reasoning = [reasoningOf(prev), reasoningOf(m)].filter(Boolean).join("\n\n")
      out[out.length - 1] = { ...prev, content, tool_calls: [...prev.tool_calls, ...(m.tool_calls ?? [])], ...(reasoning ? { reasoning_content: reasoning } : {}) }
      continue
    }
    out.push(m)
  }
  return out
}

// reasoningOf is an assistant message's reasoning as a chat completion
// carries it: reasoning_content, or reasoning as some clients name it.
function reasoningOf(m) {
  for (const v of [m?.reasoning_content, m?.reasoning]) if (typeof v === "string" && v) return v
  return ""
}

// effortOf is the effort a request names, as magpie reads it.
function effortOf(s) {
  const e = String(s ?? "").trim().toLowerCase()
  // none and minimal go as given: the family's variant nearest them, as
  // magpie's built-in picks it (devinVariantIn)
  if (["none", "minimal", "low", "medium", "high", "xhigh", "max"].includes(e)) return e
  if (e === "ultra") return "max"
  return ""
}

// argsOf is a call's arguments as JSON.
function argsOf(s) {
  if (s && typeof s === "object") return JSON.stringify(s)
  try {
    const v = JSON.parse(s || "{}")
    return JSON.stringify(v && typeof v === "object" ? v : {})
  } catch {
    return "{}"
  }
}

// toolDescriptions is what each tool says of itself, for the
// instructions.
function toolDescriptions(tools) {
  const said = tools.filter((t) => t.description)
  if (!said.length) return ""
  return "<tool_descriptions>\n" + said.map((t) => `<tool name="${t.name}">\n${t.description.trim()}\n</tool>\n`).join("") + "</tool_descriptions>"
}

const joinNonEmpty = (...s) => s.filter(Boolean).join("\n\n")

// objectRoot is a tool's parameters as a plain object at the root, with no
// anyOf, oneOf or allOf there: Devin's Claude models turn away a request
// offering a tool whose schema has one ("There is an issue with this
// request, please try a different model", magpie#1196; Codex desktop's
// codex_app automation_update has a root oneOf), as Anthropic does behind
// Factory (magpie#646). It folds the schema as magpie's built-in does
// (provider.ObjectRoot): allOf's branches are all merged, properties and
// required alike; of anyOf's and oneOf's object branches the properties are
// merged, a field each of them requires stays required, and the other
// branches go; a branch that is a union itself is folded first, so its
// fields are kept (magpie#1271). Branches may be local $refs. A schema already a plain object
// is returned as it came; the caller's own is never changed.
function objectRoot(ps) {
  return foldRoot(ps, ps, 0)
}

function foldRoot(root, ps, depth) {
  if (!isObj(ps)) return ps
  const has = (k) => Object.hasOwn(ps, k)
  if (ps.type === "object" && !has("anyOf") && !has("oneOf") && !has("allOf")) return ps
  const out = { ...ps }
  const props = { ...(isObj(ps.properties) ? ps.properties : {}) }
  let required = Array.isArray(ps.required) ? [...ps.required] : []
  const ref = (b) => {
    if (!isObj(b)) return null
    if (typeof b.$ref !== "string" || !b.$ref) return b
    for (const k of ["$defs", "definitions"]) {
      const pre = "#/" + k + "/"
      if (b.$ref.startsWith(pre)) {
        const d = root[k]?.[b.$ref.slice(pre.length)]
        return isObj(d) ? d : null
      }
    }
    return null
  }
  for (const b of Array.isArray(ps.allOf) ? ps.allOf : []) {
    const bm = ref(b)
    if (!bm) continue
    if (isObj(bm.properties)) for (const [k, v] of Object.entries(bm.properties)) if (!Object.hasOwn(props, k)) props[k] = v
    if (Array.isArray(bm.required)) required.push(...bm.required)
  }
  delete out.allOf
  const branches = []
  for (const k of ["anyOf", "oneOf"]) {
    for (const b of Array.isArray(ps[k]) ? ps[k] : []) {
      let bm = ref(b)
      if (!bm) continue
      // a branch that is itself a union (zod's discriminated create and
      // update in automation_update) is folded first, not dropped
      if (depth < 8 && ["anyOf", "oneOf", "allOf"].some((u) => Object.hasOwn(bm, u))) bm = foldRoot(root, bm, depth + 1)
      if (bm.type !== "object" && !Object.hasOwn(bm, "properties")) continue
      branches.push(bm)
    }
    delete out[k]
  }
  // a field every branch requires stays required, beside the root's and
  // allOf's own, which no branch can drop; a field the root doesn't define
  // takes each schema the branches give it, as anyOf when they differ
  let common = null
  const from = new Map()
  for (const b of branches) {
    for (const [k, v] of Object.entries(isObj(b.properties) ? b.properties : {})) {
      if (Object.hasOwn(props, k)) continue
      const vs = from.get(k) ?? []
      if (!vs.some((w) => JSON.stringify(w) === JSON.stringify(v))) vs.push(v)
      from.set(k, vs)
    }
    const br = Array.isArray(b.required) ? b.required : []
    common = common === null ? [...br] : common.filter((r) => br.includes(r))
  }
  for (const [k, vs] of from) props[k] = vs.length === 1 ? vs[0] : { anyOf: vs }
  for (const r of common ?? []) if (!required.includes(r)) required.push(r)
  required = [...new Set(required)]
  out.type = "object"
  out.properties = props
  if (required.length) out.required = required
  else delete out.required
  return out
}

const isObj = (v) => !!v && typeof v === "object" && !Array.isArray(v)

// geminiSchema is a tool's parameters as Devin's Gemini models take them.
// Devin answers "There is an issue with this request, please try a
// different model" (invalid_argument) to a Gemini model offered a tool
// whose schema, at any depth, has a type that is a list (["string",
// "null"], as zod-to-json-schema writes a nullable field), an array with
// no items, items that are a list or true, or properties or an enum with no
// type (7eleven on Discord, ZCode on gemini-4-argon). Its Claude models
// and swe-2 take all of them, so only a Gemini uid gets this. A list type
// becomes its one type, nullable when it had "null", or anyOf of each;
// such an array's items become {} (a one-schema list, that schema); a
// schema with properties is an object; an enum's type comes from its
// values, and an enum of mixed values goes. The caller's own is never
// changed.
//
// Below the root it also refuses an anyOf beside a type, which is what
// magpie's gateway sends for a Gemini model: it writes the type the
// branches agree on beside an anyOf that had none, so Kimi Code's Read
// (line_offset: anyOf of two integers) and every Optional field came in
// as {type: "integer", anyOf: [...]} and were refused (songyq26,
// plugins#458). A oneOf beside a type, an anyOf at the root and an anyOf
// with no type are taken, and a oneOf with no type beside nullable is
// not, so only an anyOf beside a type is changed: its null branches
// become nullable, one branch left of that type (or of none) is merged
// into the schema, and two or more are sent as a oneOf (into allOf when
// there is a oneOf already).
function geminiSchema(s, depth = 0) {
  if (!isObj(s) || depth > 32) return s
  let out = { ...s }
  const sub = (v) => geminiSchema(v, depth + 1)
  for (const k of ["properties", "patternProperties", "$defs", "definitions", "dependentSchemas"])
    if (isObj(out[k])) out[k] = Object.fromEntries(Object.entries(out[k]).map(([n, v]) => [n, sub(v)]))
  for (const k of ["anyOf", "oneOf", "allOf", "prefixItems"]) if (Array.isArray(out[k])) out[k] = out[k].map(sub)
  for (const k of ["additionalProperties", "not", "if", "then", "else", "contains"]) if (isObj(out[k])) out[k] = sub(out[k])
  if (Array.isArray(out.type)) {
    const types = [...new Set(out.type.filter((t) => typeof t === "string"))]
    const some = types.filter((t) => t !== "null")
    if (some.length < types.length && some.length) out.nullable = true
    if (some.length === 1) out.type = some[0]
    else if (!some.length) out.type = types.length ? "null" : undefined
    else {
      delete out.type
      const branches = some.map((t) => ({ type: t, ...(t === "array" ? { items: {} } : {}) }))
      out.anyOf = Array.isArray(out.anyOf) ? [...out.anyOf, ...branches] : branches
    }
    if (out.type === undefined) delete out.type
  }
  if (depth > 0 && out.type !== undefined && Array.isArray(out.anyOf)) {
    const isNull = (b) => isObj(b) && b.type === "null"
    const some = out.anyOf.filter((b) => !isNull(b))
    if (some.length < out.anyOf.length) out.nullable = true
    delete out.anyOf
    const one = some.length === 1 && isObj(some[0]) ? some[0] : undefined
    if (one && (one.type === undefined || one.type === out.type)) {
      out = { ...one, ...out }
    } else if (some.length) {
      if (!Array.isArray(out.oneOf)) out.oneOf = some
      else out.allOf = [...(Array.isArray(out.allOf) ? out.allOf : []), { oneOf: some }]
    }
  }
  if (out.type === undefined && Array.isArray(out.enum)) {
    const vals = out.enum.filter((v) => v !== null)
    if (vals.length < out.enum.length) out.nullable = true
    const kinds = new Set(vals.map((v) => (Number.isInteger(v) ? "integer" : typeof v)))
    const one = kinds.size === 1 ? [...kinds][0] : kinds.size === 2 && kinds.has("integer") && kinds.has("number") ? "number" : ""
    if (["string", "integer", "number", "boolean"].includes(one)) {
      out.type = one
      out.enum = vals
    } else delete out.enum
  }
  if (out.type === undefined && isObj(out.properties)) out.type = "object"
  if (out.type === "array" || (out.type === undefined && Object.hasOwn(out, "items"))) {
    if (Array.isArray(out.items)) out.items = out.items.length === 1 && isObj(out.items[0]) ? sub(out.items[0]) : {}
    else out.items = isObj(out.items) ? sub(out.items) : {}
    out.type = "array"
  }
  return out
}

const osName = () => (process.platform === "win32" ? "windows" : process.platform)

// metadata is what each request says of the client: the CLI's own (with
// its ide and extension names alone Devin lists one model).
const metadata = (key) =>
  new PB().str(1, "devin-cli").str(2, CLI_VERSION).str(3, key).str(4, "en").str(5, osName()).str(7, CLI_VERSION).str(12, "chisel").str(28, "chisel")

// Devin names a call after its tool and turn (Bash:0#a65b6a5e…), and
// Claude Code takes a tool_use id only of [A-Za-z0-9_-]: it drops a call
// whose id has the ':' or '#', and the turn fails "could not be parsed"
// (yetone/magpie#1304). Such an id goes out as "dv_" and its base64url, and
// comes back to Devin as it was, so its result still answers its call. An
// id that is already safe goes out as it came, unless it begins "dv_".
const SAFE_ID = /^[A-Za-z0-9_-]+$/
const outID = (id) => (SAFE_ID.test(id) && !id.startsWith("dv_") ? id : "dv_" + Buffer.from(id).toString("base64url"))
const inID = (id) => {
  if (typeof id !== "string" || !id.startsWith("dv_") || !SAFE_ID.test(id)) return id
  const raw = Buffer.from(id.slice(3), "base64url").toString()
  return raw && outID(raw) === id ? raw : id
}

// formatText is the structured output a chat's response_format asks for,
// said in words as magpie's built-in says it (format.go's instruction):
// json_schema's schema, or any JSON object for json_object or a schema of
// no shape; "" for text or none.
function formatText(f) {
  if (f?.type === "json_object") return "Respond with a single JSON object and nothing else."
  if (f?.type !== "json_schema") return ""
  const schema = f.json_schema ? f.json_schema.schema : f.schema
  if (schema === undefined || schema === null) return "Respond with a single JSON object and nothing else."
  return "Respond with a single JSON value and nothing else, matching this JSON schema:\n" + JSON.stringify(schema) + "."
}

// inlineImage is an image_url part as Devin takes an image, its bytes and
// type, or null for one that carries no bytes: Devin takes no URL, and
// magpie's built-in sends only an image with its bytes (inlineImages).
function inlineImage(p) {
  if (p?.type !== "image_url") return null
  const u = typeof p.image_url === "string" ? p.image_url : p.image_url?.url ?? ""
  const d = /^data:([^,]*),(.*)$/s.exec(u)
  return d && d[2] ? { data: d[2], type: imageType(d[2], d[1].replace(/;base64$/, "") || "image/png") } : null
}

// imageType is the type an image's bytes (base64) are, by their first
// bytes, else the type it was said to be. Devin answers "There is an issue
// with this request, please try a different model" (invalid_argument) to
// a PNG said to be a JPEG or a WebP, on every Claude model, and the
// picture stays in the conversation, so every turn after fails the same:
// a tool that names a screenshot by its file's extension is enough.
function imageType(data, said) {
  const b = Buffer.from(String(data).slice(0, 24), "base64")
  if (b.length >= 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "image/png"
  if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg"
  if (b.length >= 6 && b.toString("latin1", 0, 4) === "GIF8") return "image/gif"
  if (b.length >= 12 && b.toString("latin1", 0, 4) === "RIFF" && b.toString("latin1", 8, 12) === "WEBP") return "image/webp"
  return said
}

// A chat's tool message holds text alone, so magpie's gateway (buildChat's
// seeLater) sends the images a tool returned in the user message after the
// results: each result's text ends saying how many follow (NOTE), and its
// images are headed FROM "<tool> (tool call <id>):]" or FROM
// "tool call <id>:]", ahead of the user's own words and images.
const FROM = "[From the result of "
const NOTE = /(?:\n\n)?\[The tool returned (an image; it|(\d+) images; they) follows? in the next message\.\]$/

// noted is how many images a result's text says follow it, and its text
// without saying so.
function noted(text) {
  const m = NOTE.exec(text)
  if (!m) return { n: 0, text }
  return { n: m[2] ? Number(m[2]) : 1, text: text.slice(0, m.index) }
}

// build is the GetChatMessage request for a chat completion, to the model
// uid.
function build(chat, uid, key, opts = {}) {
  const claude = isClaude(uid)
  const msgs = []
  let pending = [] // calls the last reply made, not yet answered
  const answer = () => {
    for (const c of pending) msgs.push({ role: TOOL, callID: c.id, text: NO_RESULT })
    pending = []
  }
  const system = []
  // the results just sent, by the call id the chat gave each, for the
  // images that follow them in the user message after
  const results = new Map()
  const resultFor = (text) => {
    if (typeof text !== "string" || !text.startsWith(FROM)) return null
    for (const [id, r] of results) if (r.said.n > r.seen && (text === `${FROM}tool call ${id}:]` || text.endsWith(` (tool call ${id}):]`))) return r
    return null
  }
  // settleResults gives each result just sent its text: without the note
  // that its images follow when every one went back with it, and "(no
  // output)" for none, as the built-in words it
  const settleResults = () => {
    for (const r of results.values()) {
      if (r.said.n > 0 && r.seen === r.said.n) r.msg.text = r.said.text
      r.msg.text ||= "(no output)"
    }
    results.clear()
  }
  for (const m of joinSplitCalls(chat.messages ?? [])) {
    if (m.role === "system" || m.role === "developer") {
      system.push(textOf(m.content))
      continue
    }
    if (m.role !== "tool" && m.role !== "user") settleResults()
    if (m.role === "assistant") {
      const calls = (m.tool_calls ?? []).map((c) => ({ id: inID(c.id), name: c.function?.name, args: argsOf(c.function?.arguments) }))
      const text = typeof m.content === "string" ? m.content : Array.isArray(m.content) ? m.content.filter((p) => p?.type === "text" && p.text).map((p) => p.text).join("\n\n") : ""
      if (!text && !calls.length) continue // a turn that only thought, or failed
      answer()
      // the reply's reasoning goes back as its thinking (11), unsigned, to
      // a model that isn't Claude: swe-2 stops thinking on a tool loop's
      // later turns when the turns before carry none (plugins#703). A chat
      // completion has no field for a signature, and Claude's thinking
      // goes back only signed (plugins#665), so Claude gets none, as before.
      const reasoning = claude ? "" : reasoningOf(m)
      // a Gemini reply goes back with its thought signature, as the
      // devin CLI sends it (thoughts)
      const signed = opts.unsigned ? null : thoughtFor(uid, calls, text)
      const thinking = signed ? { text: reasoning, ...signed } : reasoning ? { text: reasoning } : null
      msgs.push({ role: ASSISTANT, text, calls, ...(thinking ? { thinking } : {}) })
      // a copy: answering a call takes it off pending, never off the
      // reply that made it, which goes to Devin with every call it made
      pending = [...calls]
      continue
    }
    if (m.role === "tool") {
      // only a call just made is answered, and only once
      const i = pending.findIndex((c) => c.id === inID(m.tool_call_id))
      if (i >= 0) {
        const images = Array.isArray(m.content) ? m.content.map(inlineImage).filter(Boolean) : []
        const msg = { role: TOOL, callID: pending[i].id, text: textOf(m.content), images }
        msgs.push(msg)
        results.set(m.tool_call_id, { msg, said: noted(msg.text), seen: 0 })
        pending.splice(i, 1)
      }
      continue
    }
    if (m.role !== "user") continue
    const texts = []
    const images = []
    if (typeof m.content === "string") {
      if (m.content) texts.push(m.content)
    } else {
      // the images a tool returned, which a chat's tool message can't
      // hold, go back with the result that returned them, as magpie's
      // built-in sends them (inlineImages): a tool message's images
      // (field 10) and not a user message of their own
      let to = null // the result the images that follow are of, until it has the number it said
      for (const p of m.content ?? []) {
        if (p?.type === "text") {
          to = results.size ? resultFor(p.text) : null
          if (!to && p.text) texts.push(p.text)
        } else if (p?.type === "image_url") {
          const im = inlineImage(p)
          if (to) {
            if (im) to.msg.images.push(im)
            if (++to.seen === to.said.n) to = null
          } else if (im) images.push(im)
        }
      }
    }
    settleResults()
    // words that are only white space are none: Devin turns a user prompt
    // of them away (invalid_argument), as it does an empty one
    const text = texts.join("\n\n").trim() ? texts.join("\n\n") : ""
    if (!text && !images.length) continue
    answer()
    msgs.push({ role: USER, text, images })
  }
  settleResults()
  answer()
  // Devin has no field for the answer's format: it is told in words, at
  // the end of the instructions, as magpie's built-in tells it (inSystem)
  const format = formatText(chat.response_format)
  if (format) system.push(format)
  const last = msgs[msgs.length - 1]
  if (!last || (last.role === ASSISTANT && !last.calls.length)) msgs.push({ role: USER, text: "Please proceed with the task." })

  // the instructions go at the head of the first user message: Devin turns
  // away some agents' own in its system field. The tools' descriptions go
  // there too, each tool sent with only a pointer to its own: Devin
  // answers "an internal error occurred" to some agents' tools as they
  // describe themselves, and the same words in a message go through
  let tools = (chat.tools ?? [])
    .filter((t) => (!t?.type || t.type === "function") && t.function?.name)
    .map((t) => ({ name: t.function.name, description: t.function.description ?? "", schema: objectRoot(t.function.parameters) }))
  if (chat.tool_choice === "none") tools = []
  if (/gemini/i.test(uid)) tools = tools.map((t) => ({ ...t, schema: geminiSchema(t.schema) }))
  const instructions = joinNonEmpty(system.join("\n\n"), toolDescriptions(tools))
  if (instructions) {
    let at = msgs.findIndex((m) => m.role === USER)
    if (at < 0) {
      msgs.unshift({ role: USER, text: "" })
      at = 0
    }
    msgs[at].text = joinNonEmpty(instructions, msgs[at].text)
  }
  return encodeRequest(msgs, tools, { max: chat.max_completion_tokens || chat.max_tokens, temperature: chat.temperature, top_p: chat.top_p }, uid, key)
}

// encodeRequest is the GetChatMessage request of msgs, with tools offered
// and the sampling asked, to the model uid. Its cache keepalive ping
// (keepalivePing) is the same request, byte for byte, with one more user
// prompt, "continue", and max_tokens 1, as the devin CLI pings
// (plugins#592): each prompt is encoded once, so both carry the same bytes.
function encodeRequest(msgs, tools, chat, uid, key) {
  const head = metadata(key).done()
  const prompts = msgs.map(encodeMsg)
  // Devin answers "an internal error occurred" to a temperature or top_p of
  // exactly 0 (on every model: its Claude ones and swe-2), where 1e-6 goes
  // through; a 0 is sent as the smallest step above it, as near greedy
  const above0 = (v) => (v === 0 ? 1e-6 : v)
  const temp = above0(typeof chat.temperature === "number" ? chat.temperature : 1)
  const topP = above0(typeof chat.top_p === "number" ? chat.top_p : 0.95)
  const sampling = (max) => new PB().varint(1, 1).varint(2, max).varint(3, 400).double(5, temp).varint(7, 40).double(8, topP)

  // the caller's tools, and any the conversation used that it no longer
  // offers
  const offered = new Set()
  const toolParts = []
  const tool = (name, desc, schema) => {
    if (!schema || typeof schema !== "object") schema = { type: "object", properties: {} }
    offered.add(name)
    toolParts.push(new PB().str(1, name).str(2, desc || name).bytes(3, JSON.stringify(schema)).done())
  }
  for (const t of tools) tool(t.name, t.description ? `Described under <tool name="${t.name}"> in <tool_descriptions>, in the instructions.` : "", t.schema)
  for (const m of msgs) for (const c of m.calls ?? []) if (!offered.has(c.name)) tool(c.name, "Tool")

  const assemble = (more, max) => {
    const out = new PB().bytes(1, head)
    for (const p of [...prompts, ...more]) out.bytes(3, p)
    out.varint(7, 5)
    out.bytes(8, sampling(max))
    for (const t of toolParts) out.bytes(10, t)
    return out.str(21, uid).done()
  }
  const bytes = assemble([], chat.max || 128000) // the server holds max to the model's own
  pingOf.set(bytes, () => assemble([encodeMsg({ role: USER, text: "continue" })], 1))
  sentOf.set(bytes, { signed: msgs.some((m) => m.thinking?.signature), tokens: estimate(msgs, toolParts) })
  return bytes
}

// sentOf is what each request carried that its failure is read by: any
// signed thinking, and about how many tokens its prompt is (estimate)
const sentOf = new WeakMap()

// estimate is about how many tokens msgs and the tools offered come to,
// a token counted as four bytes of text and an image as 1,600 tokens (a
// picture's base64 is no measure of its tokens): text runs under four
// bytes a token, code nearer three (Devin counted 991,278 tokens of
// 2,350,000 bytes of Go), so this is low, never high, and it is read
// against half the window (TOO_LONG_AT).
function estimate(msgs, toolParts) {
  let bytes = 0
  let images = 0
  for (const m of msgs) {
    bytes += Buffer.byteLength(m.text ?? "") + Buffer.byteLength(m.thinking?.text ?? "")
    for (const c of m.calls ?? []) bytes += Buffer.byteLength(c.name ?? "") + Buffer.byteLength(c.args ?? "")
    images += m.images?.length ?? 0
  }
  for (const t of toolParts) bytes += t.length
  return Math.ceil(bytes / 4) + images * 1600
}

// pingOf is each request's keepalive ping, made when one is first sent
const pingOf = new WeakMap()
const keepalivePing = (bytes) => pingOf.get(bytes)?.()

function encodeMsg(m) {
  const b = new PB().str(1, randomUUID()).varint(2, m.role)
  if (m.text) b.str(3, m.text)
  for (const c of m.calls ?? []) b.bytes(6, new PB().str(1, c.id ?? "").str(2, c.name ?? "").bytes(3, c.args))
  if (m.callID) b.str(7, m.callID)
  // prompt_cache_options {type: EPHEMERAL}, as the devin CLI marks its
  // own: where the client put cache_control (#566)
  if (m.cache) b.bytes(8, new PB().varint(1, 1))
  for (const p of m.images ?? []) b.bytes(10, new PB().str(1, p.data).str(2, p.type))
  // the thinking the reply had, sent back as Devin wrote it: thinking
  // (11), and Claude's signature (12) and signature_type (18) when it was
  // signed (plugins#665). Another model's thinking has no signature and
  // goes back as its text alone (plugins#703); which thinking reaches
  // here is the builders' to say.
  if (m.thinking?.text) b.str(11, m.thinking.text)
  if (m.thinking?.signature) {
    b.str(12, m.thinking.signature)
    if (m.thinking.type) b.str(18, m.thinking.type)
    if (m.thinking.model) b.str(22, m.thinking.model)
  }
  return b.done()
}

// sigTypes is each thinking signature's type (delta_signature_type) as
// Devin said it, by the signature, for the next request's thinking: a
// Messages thinking block has no field for it. The most recent are kept;
// one not kept is Anthropic's, which is what Devin says for Claude's.
const sigTypes = new Map()
const SIG_TYPES_KEPT = 512
function rememberSigType(signature, type) {
  if (!signature || !type) return
  sigTypes.delete(signature)
  sigTypes.set(signature, type)
  if (sigTypes.size > SIG_TYPES_KEPT) sigTypes.delete(sigTypes.keys().next().value)
}
const sigTypeOf = (signature) => sigTypes.get(signature) ?? "anthropic"

// thoughts is each Gemini reply's thought signature, by the reply's tool
// call ids (or, for a reply that made none, its text), for the request
// that sends the reply back. The devin CLI sends a Gemini reply back with
// its signature (12), its type "gemini" (18) and the model that wrote it
// (22); without them Devin's Gemini models, deep in a tool loop, answer
// with usage and nothing else (X, gemini-4-hydrogen in dsh). Neither a
// chat completion nor a Messages tool_use has a field for it, so it is
// kept here, as sigTypes are; the most recent are kept.
const thoughts = new Map()
const THOUGHTS_KEPT = 4096
const isGemini = (uid) => /gemini/i.test(String(uid ?? ""))
const textKey = (text) => "text:" + createHash("sha256").update(String(text).replace(/\s+/g, "")).digest("base64url")
function rememberThought({ calls, text }, thought) {
  const keys = calls.length ? calls : text ? [textKey(text)] : []
  for (const k of keys) {
    thoughts.delete(k)
    thoughts.set(k, thought)
    if (thoughts.size > THOUGHTS_KEPT) thoughts.delete(thoughts.keys().next().value)
  }
}
// thoughtFor is the signature kept for a reply sent back with these calls
// (Devin's ids) and text, to a Gemini model; null for none.
function thoughtFor(uid, calls, text) {
  if (!isGemini(uid)) return null
  for (const c of calls) {
    const t = thoughts.get(c.id)
    if (t) return t
  }
  return (!calls.length && text && thoughts.get(textKey(text))) || null
}

// ---- the reply -----------------------------------------------------------------------

// statusText is a status as magpie's built-in words an error that says
// nothing (Go's http.StatusText).
const statusText = (s) =>
  ({ 413: "Request Entity Too Large", 414: "Request URI Too Long", 416: "Requested Range Not Satisfiable", 418: "I'm a teapot", 509: "" })[s] ?? STATUS_CODES[s] ?? ""

// failure is the status and message for a Connect error: {"code",
// "message"}, or at a stream's end {"error": {"code", "message"}}.
function failure(status, text) {
  let msg = String(text ?? "").trim()
  let code = ""
  try {
    const e = JSON.parse(text)
    if (e?.error && typeof e.error === "object") [code, msg] = [e.error.code ?? "", e.error.message ?? ""]
    else if (e?.code) [code, msg] = [e.code, e.message ?? ""]
    msg ||= code
  } catch {}
  msg ||= statusText(status) || `HTTP ${status}`
  const low = msg.toLowerCase()
  if (code === "unauthenticated") return { status: 401, message: msg + " — sign in to Devin again" }
  if (code === "resource_exhausted" || low.includes("quota") || low.includes("rate limit")) return { status: 429, message: "usage limit reached: " + msg }
  // Devin turns away some system prompts outright; sent again, the same
  // one is turned away again
  if (low.includes("content policy")) return { status: 400, message: msg }
  if (low.includes("too long") || low.includes("context length") || low.includes("too many tokens"))
    return { status: 400, message: "input is too long for the model's context: " + msg }
  if (code === "invalid_argument") return { status: 400, message: msg, code }
  if (code === "unavailable") return { status: 503, message: msg }
  if (code) return { status: 502, message: msg }
  return { status, message: msg }
}

// events turns the reply's frames into chat completion pieces: text,
// reasoning, each tool call opened with its id and name, its arguments in
// pieces after, then the finish with the usage.
async function* events(it, uid = "") {
  let tools = -1
  let stop = 0
  let said = 0
  // a Gemini reply's thought signature, to go back with it (thoughts)
  const own = { calls: [], text: "", signature: "", type: "" }
  const usage = { input: 0, output: 0, cacheWrite: 0, cacheRead: 0 }
  for (;;) {
    let r
    try {
      r = await it.next()
    } catch (e) {
      yield { error: { status: 502, message: "the reply broke off: " + e.message } }
      return
    }
    if (r.done) break
    const f = r.value
    if (f.end) {
      const e = failure(200, dec.decode(f.data))
      if (e.status >= 300) {
        yield { error: e }
        return
      }
      break
    }
    for (const x of fields(f.data)) {
      if (x.num === 3 && x.wire === 2 && x.data.length) {
        said += x.data.length
        const text = dec.decode(x.data)
        own.text += text
        yield { text }
      } else if (x.num === 9 && x.wire === 2 && x.data.length) {
        said += x.data.length
        yield { reasoning: dec.decode(x.data) }
      } else if (x.num === 10 && x.wire === 2 && x.data.length) {
        // delta_signature: the thinking's signature, Claude's opaque state
        // to continue it from (plugins#665); no words of the reply
        const signature = dec.decode(x.data)
        own.signature += signature
        yield { signature }
      } else if (x.num === 21 && x.wire === 2 && x.data.length) {
        // delta_signature_type: whose signature it is ("anthropic")
        const signatureType = dec.decode(x.data)
        own.type = signatureType
        yield { signatureType }
      } else if (x.num === 6 && x.wire === 2) {
        let id = ""
        let name = ""
        let args = ""
        for (const g of fields(x.data)) {
          if (g.num === 1) id = dec.decode(g.data ?? new Uint8Array())
          else if (g.num === 2) name = dec.decode(g.data ?? new Uint8Array())
          else if (g.num === 3) args += dec.decode(g.data ?? new Uint8Array())
        }
        if (name) {
          tools++
          const tool = { index: tools, id: id ? outID(id) : "call_" + randomBytes(12).toString("hex"), name }
          own.calls.push(inID(tool.id))
          yield { tool }
        }
        if (args && tools >= 0) yield { args: { index: tools, text: args } }
      } else if (x.num === 5 && x.wire === 0) stop = x.n
      else if (x.num === 7 && x.wire === 2) {
        for (const g of fields(x.data)) {
          if (g.wire !== 0 || !g.n) continue
          if (g.num === 2) usage.input = g.n
          else if (g.num === 3) usage.output = g.n
          else if (g.num === 4) usage.cacheWrite = g.n
          else if (g.num === 5) usage.cacheRead = g.n
        }
      }
    }
  }
  if (!said && tools < 0) {
    yield { error: { status: 502, message: "an empty reply (Devin returned no text, reasoning or tool call)" } }
    return
  }
  if (own.signature && isGemini(uid) && (own.type || "gemini") === "gemini")
    rememberThought(own, { signature: own.signature, type: own.type || "gemini", model: uid })
  if (!usage.output) usage.output = Math.floor((said + 3) / 4)
  const prompt = usage.input + usage.cacheRead + usage.cacheWrite
  yield {
    stop: tools >= 0 || stop === 10 ? "tool_calls" : stop === 3 ? "length" : "stop",
    usage: {
      prompt_tokens: prompt,
      completion_tokens: usage.output,
      total_tokens: prompt + usage.output,
      prompt_tokens_details: { cached_tokens: usage.cacheRead, cache_write_tokens: usage.cacheWrite },
    },
    tokens: usage,
  }
}

// errorResponse is a failure as the built-in answered it. None marks the
// account lapsed: the built-in's 401s (a key Devin turned away, none to
// send) were answered without touching the account, so each says
// X-Magpie-Sign-In: kept — as a success does, which cleared nothing either.
const errorResponse = ({ status, message }) =>
  new Response(JSON.stringify({ error: { message, type: "devin_error", code: status } }), {
    status,
    headers: { "Content-Type": "application/json", "X-Magpie-Sign-In": "kept" },
  })

async function* prepend(first, rest) {
  yield first
  yield* rest
}

// roundtrip sends a chat to GetChatMessage and answers with its event
// iterator, or an error ({status, message}).
// A wire is how a request is read: chat completions' or Messages'.
const CHAT_WIRE = { effort: (chat) => effortOf(chat.reasoning_effort), build }
const MESSAGES = { effort: anthropicEffort, build: buildMessages }

// rpcHeaders are a GetChatMessage's headers for a framed body.
const rpcHeaders = (key, body) => ({ "Content-Type": "application/connect+proto", "Connect-Protocol-Version": "1", ...(body[0] & 1 ? { "Connect-Content-Encoding": "gzip" } : {}), Authorization: "Basic " + key })

// keep, when given, is the conversation's cache keepalive (keepaliveFor):
// once the reply has finished, its pings are scheduled.
//
// Devin answers "There is an issue with this request, please try a
// different model" (invalid_argument) to a conversation past the model's
// window and to a thinking signature it didn't give (another vendor's
// Claude, or one a client changed), alike. Either stays in the
// conversation, so every turn after fails the same while a new session
// works (a1pha1nthefog on X). A request with signed thinking that is
// turned away is sent again once with no signature, its Claude thinking
// left out, as Anthropic takes a past turn's; one still turned away at
// half the model's window or more (TOO_LONG_AT) is told as too long, so
// the agent compacts the conversation rather than stopping.
async function roundtrip({ key, server, families, keep }, chat, signal, wire = CHAT_WIRE) {
  const uid = variantFor(families, chat.model, wire.effort(chat))
  let msg = wire.build(chat, uid, key)
  let r = await askOnce(key, server, msg, signal, uid)
  if (r.code === "invalid_argument" && sentOf.get(msg)?.signed && !signal?.aborted) {
    msg = wire.build(chat, uid, key, { unsigned: true })
    r = await askOnce(key, server, msg, signal, uid)
  }
  if (r.code === "invalid_argument") r = tooLongFor(r, sentOf.get(msg)?.tokens ?? 0, windowOf(families, uid), uid)
  if (!r.it) return r
  return { it: keep ? keptAfter(r.it, keep, { key, server, msg, sentAt: r.sentAt }) : r.it, uid }
}

// askOnce sends one GetChatMessage, msg, and answers with its event iterator
// and when it was sent, or an error ({status, message, code}).
async function askOnce(key, server, msg, signal, uid) {
  const body = frame(msg)
  // when Devin was asked, which its cache's 5 minutes run from: the pings
  // are timed from it, not from the reply's end (plugins#626)
  const sentAt = now()
  let res
  try {
    res = await fetch(server + CHAT_RPC, {
      method: "POST",
      headers: rpcHeaders(key, body),
      body,
      signal,
    })
  } catch (e) {
    return { status: 502, message: e.message }
  }
  if (!res.ok) return failure(res.status, (await res.text()).slice(0, 1 << 20))
  // an error comes as the stream's end, before anything else: read that
  // far so it is answered with its own status
  const fr = frames(res.body)
  let first
  try {
    first = await fr.next()
  } catch (e) {
    return { status: 502, message: "the reply broke off: " + e.message }
  }
  if (first.done) return { status: 502, message: "the reply broke off: EOF" }
  if (first.value.end) {
    const e = failure(200, dec.decode(first.value.data))
    return e.status < 300 ? { status: 502, message: "an empty reply" } : e
  }
  // 先等到实际内容或错误，才能让网关在空回复时切换渠道。
  const source = events(prepend(first.value, fr), uid)
  const head = await source.next()
  if (head.done) return { status: 502, message: "an empty reply" }
  if (head.value.error) {
    await fr.return?.()
    return head.value.error
  }
  return { it: prepend(head.value, source), sentAt }
}

// TOO_LONG_AT is how much of a model's window a request Devin turns away
// (invalid_argument) must be estimated at to be told as too long: the
// estimate runs low (estimate), and Devin says nothing of length.
const TOO_LONG_AT = 0.5

// tooLongFor is e, a request turned away, as too long for the model's
// window when it was estimated at TOO_LONG_AT of it or more; e otherwise.
function tooLongFor(e, tokens, window, uid) {
  if (!window || tokens < window * TOO_LONG_AT) return e
  return { status: 400, message: `input is too long for the model's context: about ${tokens} tokens or more, for ${uid}'s window of ${window} (Devin answered: ${e.message})` }
}

// windowOf is the context window of the model uid, from the account's
// list or else the snapshot's; 0 when neither says.
function windowOf(families, uid) {
  for (const fs of [families, SNAPSHOT_FAMILIES]) for (const f of fs ?? []) for (const m of f.models ?? []) if (m.id === uid && m.context) return m.context
  return 0
}

// complete answers a chat completion through GetChatMessage.
async function complete({ key, server, families, keep }, chat, signal) {
  const rt = await roundtrip({ key, server, families, keep }, chat, signal)
  if (!rt.it) return errorResponse(rt)
  const it = rt.it
  const id = "chatcmpl-" + randomBytes(12).toString("hex")
  const created = Math.floor(Date.now() / 1000)

  if (!chat.stream) {
    const msg = { role: "assistant", content: "" }
    let reasoning = ""
    const calls = []
    let stop = "stop"
    let usage
    for await (const e of it) {
      if (e.error) return errorResponse(e.error)
      if (e.text) msg.content += e.text
      if (e.reasoning) reasoning += e.reasoning
      if (e.tool) calls.push({ id: e.tool.id, type: "function", function: { name: e.tool.name, arguments: "" } })
      if (e.args) calls[e.args.index].function.arguments += e.args.text
      if (e.stop) [stop, usage] = [e.stop, e.usage]
    }
    if (reasoning) msg.reasoning_content = reasoning
    if (calls.length) msg.tool_calls = calls
    return Response.json({ id, object: "chat.completion", created, model: chat.model, choices: [{ index: 0, message: msg, finish_reason: stop }], usage }, { headers: { "X-Magpie-Sign-In": "kept" } })
  }

  const chunk = (delta, finish_reason = null, extra = {}) =>
    enc.encode(`data: ${JSON.stringify({ id, object: "chat.completion.chunk", created, model: chat.model, choices: [{ index: 0, delta, finish_reason }], ...extra })}\n\n`)
  let began = false
  const stream = new ReadableStream({
    async pull(ctl) {
      if (!began) {
        began = true
        ctl.enqueue(chunk({ role: "assistant", content: "" }))
      }
      // a pull that sends nothing isn't pulled again: what a chat
      // completion has no field for (a thinking signature) is passed over
      let r
      do r = await it.next()
      while (!r.done && (r.value.signature || r.value.signatureType))
      if (r.done) {
        ctl.enqueue(enc.encode("data: [DONE]\n\n"))
        return ctl.close()
      }
      const e = r.value
      if (e.text) ctl.enqueue(chunk({ content: e.text }))
      else if (e.reasoning) ctl.enqueue(chunk({ reasoning_content: e.reasoning }))
      else if (e.tool) ctl.enqueue(chunk({ tool_calls: [{ index: e.tool.index, id: e.tool.id, type: "function", function: { name: e.tool.name, arguments: "" } }] }))
      else if (e.args) ctl.enqueue(chunk({ tool_calls: [{ index: e.args.index, function: { arguments: e.args.text } }] }))
      else if (e.stop) ctl.enqueue(chunk({}, e.stop, { usage: e.usage }))
      else if (e.error) {
        ctl.enqueue(enc.encode(`data: ${JSON.stringify({ error: { message: e.error.message, code: e.error.status } })}\n\n`))
        ctl.close()
      }
    },
    cancel() {
      it.return?.()
    },
  })
  return new Response(stream, { status: 200, headers: { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", "X-Magpie-Sign-In": "kept" } })
}

// ---- Anthropic's Messages, for the Claude models ------------------------------------

// Claude Code's billing line, a system block of its own whose cch changes
// every turn: Devin would read it as the prompt's first words, and no
// turn's prefix would be the last's
const BILLING_LINE = /^x-anthropic-billing-header:(\s*[A-Za-z_]+=[^;\s]*;)*\s*(\n|$)/

// marked says whether the client asked for the cache to end at a block.
const marked = (b) => !!(b && typeof b === "object" && b.cache_control && typeof b.cache_control === "object")

// anthropicImage is an image block as Devin takes an image, or null for
// one that carries no bytes (Devin takes no URL).
function anthropicImage(b) {
  const s = b?.type === "image" ? b.source : null
  if (s?.type !== "base64" || !s.data) return null
  return { data: s.data, type: imageType(s.data, s.media_type || "image/png") }
}

// anthropicEffort is the effort a Messages request asks for, as magpie
// reads it: output_config's, else the thinking budget's; none with the
// thinking turned off.
function anthropicEffort(req) {
  const t = req.thinking?.type
  if (t === "disabled") return ""
  if (req.output_config?.effort) return effortOf(req.output_config.effort)
  if (t !== "enabled" && t !== "adaptive") return ""
  const n = Number(req.thinking?.budget_tokens) || 0
  return n <= 0 ? "" : n <= 4096 ? "low" : n <= 12000 ? "medium" : n <= 24000 ? "high" : "xhigh"
}

// buildMessages is the GetChatMessage request for a Messages request, to
// the model uid. Each of the client's blocks is a ChatMessagePrompt of its
// own, in order, and one the client marked with cache_control carries
// prompt_cache_options: Devin's cache ends only where a prompt says so,
// and only at a prompt's end, so a block joined to others lost its mark
// (#566). Every boundary is kept, not only the marked ones: a mark moves
// forward as the history grows, and the prompts it passed must stay as
// they were sent for the cache to be read (yetone/magpie#3835).
function buildMessages(req, uid, key, opts = {}) {
  const claude = isClaude(uid)
  // Messages alternate roles; a client that sends two of one role in a row
  // means one turn
  const turns = []
  for (const m of req.messages ?? []) {
    if (m?.role !== "user" && m?.role !== "assistant" && m?.role !== "system") continue
    const blocks = typeof m.content === "string" ? (m.content ? [{ type: "text", text: m.content }] : []) : Array.isArray(m.content) ? m.content : []
    // Empty effort notices must not split a streamed assistant turn.
    if (m.role === "system" && !blocks.some((b) => b?.type === "text" && typeof b.text === "string" && b.text)) continue
    const last = turns[turns.length - 1]
    if (last?.role === m.role) last.blocks.push(...blocks)
    else turns.push({ role: m.role, blocks: [...blocks] })
  }

  const msgs = []
  const notices = [] // held until the pending tool calls are answered
  let pending = [] // calls the last reply made, not yet answered
  const answer = () => {
    for (const c of pending) msgs.push({ role: TOOL, callID: c.id, text: NO_RESULT })
    pending = []
    msgs.push(...notices)
    notices.length = 0
  }
  for (const t of turns) {
    if (t.role === "assistant") {
      const own = []
      const calls = []
      let mark = false // a tool_use the client marked: the prompt with the calls ends there
      // a thinking block, for the prompt that follows it: Claude's thinking
      // goes back with its signature, which Anthropic wants on a tool
      // loop's next turn (plugins#665), and unsigned thinking to Claude
      // goes no further, as before. Another model's thinking goes back as
      // its text alone, never with a signature (plugins#703).
      let thought = null
      const take = (p) => {
        if (thought) [p.thinking, thought] = [thought, null]
        return p
      }
      for (const [i, b] of t.blocks.entries()) {
        if (b?.type === "text" && typeof b.text === "string") {
          if (b.text) own.push(take({ role: ASSISTANT, text: b.text, calls: [], cache: marked(b) }))
          else if (marked(b) && own.length) own[own.length - 1].cache = true
        } else if (b?.type === "tool_use" && b.name) {
          calls.push({ id: inID(b.id), name: b.name, args: JSON.stringify(b.input ?? {}) })
          mark ||= marked(b)
        } else if (b?.type === "thinking" && claude && !opts.unsigned && typeof b.signature === "string" && b.signature) {
          // Devin rejects a signed thought on an otherwise empty assistant prompt.
          // A gateway search can leave adjacent thoughts; keep the last one intact.
          const next = t.blocks[i + 1]
          if (next?.type === "thinking" && typeof next.signature === "string" && next.signature) continue
          if (thought) own.push(take({ role: ASSISTANT, text: "", calls: [] }))
          thought = { text: typeof b.thinking === "string" ? b.thinking : "", signature: b.signature, type: sigTypeOf(b.signature) }
        } else if (b?.type === "thinking" && !claude && typeof b.thinking === "string" && b.thinking) {
          if (thought) own.push(take({ role: ASSISTANT, text: "", calls: [] }))
          thought = { text: b.thinking }
        }
      }
      if (calls.length) {
        if (!own.length || (thought && own[own.length - 1].thinking)) own.push({ role: ASSISTANT, text: "", calls: [] })
        take(own[own.length - 1])
        own[own.length - 1].calls = calls
        own[own.length - 1].cache ||= mark
      } else if (thought && own.length && !own[own.length - 1].thinking) take(own[own.length - 1])
      // a Gemini reply goes back with its thought signature, on the
      // prompt with its calls (or its last words), as the devin CLI sends
      // it (thoughts)
      const signed = own.length && !opts.unsigned ? thoughtFor(uid, calls, own.map((p) => p.text).join("")) : null
      if (signed) {
        const p = own[own.length - 1]
        p.thinking = { text: p.thinking?.text ?? "", ...signed }
      }
      if (!own.length) continue // a turn that only thought
      answer()
      msgs.push(...own)
      pending = [...calls]
      continue
    }
    let held = [] // images ahead of the user's next words in this turn
    let words = null // the turn's last prompt of the user's own
    for (const b of t.blocks) {
      if (b?.type === "tool_result") {
        // only a call just made is answered, and only once
        const i = pending.findIndex((c) => c.id === inID(b.tool_use_id))
        if (i < 0) continue
        const inner = typeof b.content === "string" ? [{ type: "text", text: b.content }] : Array.isArray(b.content) ? b.content : []
        const text = inner.filter((x) => x?.type === "text" && x.text).map((x) => x.text).join("\n\n")
        const images = inner.map(anthropicImage).filter(Boolean)
        // Devin has no failed mark on a result: it is said in the text, as
        // magpie's gateway says it on chat completions (failedAsText)
        const said = text || "(no output)"
        msgs.push({ role: TOOL, callID: pending[i].id, text: b.is_error ? "Error: " + said : said, images, cache: marked(b) || marked(inner[inner.length - 1]) })
        pending.splice(i, 1)
        if (!pending.length) answer()
        continue
      }
      if (b?.type === "text" && typeof b.text === "string") {
        // a block of white space alone is none: Devin turns a user prompt
        // of it away (invalid_argument), as it does an empty one
        if (!b.text.trim()) {
          if (marked(b) && words) words.cache = true
          continue
        }
        // Devin requires tool results before the next user prompt. A
        // system notice can arrive first, so hold it until they follow.
        if (t.role !== "system") answer()
        words = { role: USER, text: b.text, images: held, cache: marked(b) }
        held = []
        if (t.role === "system" && pending.length) notices.push(words)
        else msgs.push(words)
        continue
      }
      const im = anthropicImage(b)
      if (!im) continue
      // an image goes with the words it follows, or the next ones
      if (words) {
        words.images.push(im)
        words.cache ||= marked(b)
      } else held.push(im)
    }
    if (held.length) {
      answer()
      msgs.push({ role: USER, text: "", images: held })
    }
  }
  answer()
  const last = msgs[msgs.length - 1]
  if (!last || (last.role === ASSISTANT && !last.calls.length)) msgs.push({ role: USER, text: "Please proceed with the task." })

  // the instructions go ahead of the first user prompt, as in build: the
  // tools' descriptions, then each system block a prompt of its own, as
  // Anthropic orders them, so a mark on the system covers the tools too
  const system = []
  const blocks = typeof req.system === "string" ? [{ type: "text", text: req.system }] : Array.isArray(req.system) ? req.system : []
  for (const b of blocks) {
    if (b?.type !== "text" || typeof b.text !== "string") continue
    const text = b.text.replace(BILLING_LINE, "")
    if (text.trim()) system.push({ role: USER, text, cache: marked(b) })
    else if (marked(b) && system.length) system[system.length - 1].cache = true
  }
  const f = req.output_config?.format
  const format = f?.type === "json_schema" ? formatText({ type: "json_schema", schema: f.schema }) : ""
  if (format) system.push({ role: USER, text: format })
  let tools = (req.tools ?? [])
    .filter((t) => (!t?.type || t.type === "custom") && t.name)
    .map((t) => ({ name: t.name, description: t.description ?? "", schema: objectRoot(t.input_schema) }))
  if (req.tool_choice?.type === "none") tools = []
  const described = toolDescriptions(tools)
  if (described) system.unshift({ role: USER, text: described, cache: false })
  if (system.length) {
    const at = msgs.findIndex((m) => m.role === USER)
    msgs.splice(at < 0 ? 0 : at, 0, ...system)
  }
  return encodeRequest(msgs, tools, { max: req.max_tokens, temperature: req.temperature, top_p: req.top_p }, uid, key)
}

// anthropicError is a failure as Anthropic words one; like errorResponse,
// it marks nothing of the account.
function anthropicError({ status, message }) {
  const type = { 400: "invalid_request_error", 401: "authentication_error", 403: "permission_error", 404: "not_found_error", 413: "request_too_large", 429: "rate_limit_error", 529: "overloaded_error" }[status] ?? "api_error"
  return new Response(JSON.stringify({ type: "error", error: { type, message } }), {
    status,
    headers: { "Content-Type": "application/json", "X-Magpie-Sign-In": "kept" },
  })
}

const STOP_REASON = { tool_calls: "tool_use", length: "max_tokens", stop: "end_turn" }
const anthropicUsage = (t = {}) => ({ input_tokens: t.input ?? 0, output_tokens: t.output ?? 0, cache_read_input_tokens: t.cacheRead ?? 0, cache_creation_input_tokens: t.cacheWrite ?? 0 })

// completeMessages answers a Messages request through GetChatMessage, as
// Anthropic would: the reply's blocks, its stop reason and the usage with
// what was read from the cache and written to it.
async function completeMessages({ key, server, families, keep }, req, signal) {
  const rt = await roundtrip({ key, server, families, keep }, req, signal, MESSAGES)
  if (!rt.it) return anthropicError(rt)
  const it = rt.it
  const id = "msg_" + randomBytes(12).toString("hex")
  // a signature is sent on for Claude's thinking only: another model's
  // thinking stays unsigned, as before, so no path sends it on as Claude's
  const claude = isClaude(rt.uid)

  if (!req.stream) {
    const content = []
    let stop = "end_turn"
    let usage = anthropicUsage()
    const block = (type) => {
      const b = content[content.length - 1]
      if (b?.type === type && type !== "tool_use") return b
      const n = type === "text" ? { type, text: "" } : { type, thinking: "", signature: "" }
      content.push(n)
      return n
    }
    const args = []
    let sigType = ""
    for await (const e of it) {
      if (e.error) return anthropicError(e.error)
      if (e.text) block("text").text += e.text
      if (e.reasoning) block("thinking").thinking += e.reasoning
      // the signature goes on the thinking it signs, the last one
      if (e.signature && claude) {
        const t = content.findLast((b) => b.type === "thinking")
        if (t) t.signature += e.signature
      }
      if (e.signatureType) sigType = e.signatureType
      if (e.tool) {
        args[e.tool.index] = ""
        content.push({ type: "tool_use", id: e.tool.id, name: e.tool.name, input: {}, index: e.tool.index })
      }
      if (e.args) args[e.args.index] += e.args.text
      if (e.stop) [stop, usage] = [STOP_REASON[e.stop] ?? "end_turn", anthropicUsage(e.tokens)]
    }
    for (const b of content) {
      if (b.type !== "tool_use") continue
      try {
        b.input = JSON.parse(args[b.index] || "{}")
      } catch {
        b.input = {}
      }
      delete b.index
    }
    for (const b of content) if (b.type === "thinking") rememberSigType(b.signature, sigType)
    return Response.json({ id, type: "message", role: "assistant", model: req.model, content, stop_reason: stop, stop_sequence: null, usage }, { headers: { "X-Magpie-Sign-In": "kept" } })
  }

  const sse = (event, data) => enc.encode(`event: ${event}\ndata: ${JSON.stringify({ type: event, ...data })}\n\n`)
  let began = false
  let index = -1
  let open = "" // the kind of the block being sent: text, thinking or tool_use
  let sig = "" // the signature of the thinking block last sent
  let sigType = ""
  const stream = new ReadableStream({
    async pull(ctl) {
      if (!began) {
        began = true
        ctl.enqueue(sse("message_start", { message: { id, type: "message", role: "assistant", model: req.model, content: [], stop_reason: null, stop_sequence: null, usage: anthropicUsage() } }))
      }
      const close = () => {
        if (open === "thinking") rememberSigType(sig, sigType)
        if (open) ctl.enqueue(sse("content_block_stop", { index }))
        open = ""
      }
      const start = (kind, content_block) => {
        close()
        index++
        open = kind
        ctl.enqueue(sse("content_block_start", { index, content_block }))
      }
      // a pull that sends nothing isn't pulled again: the events that send
      // nothing are read past here
      let r
      for (;;) {
        r = await it.next()
        if (r.done) return ctl.close()
        const q = r.value
        if (q.signatureType) {
          sigType = q.signatureType
          rememberSigType(sig, sigType)
          continue
        }
        // a signature goes on Claude's thinking block, before its stop, as
        // Anthropic streams it; one that comes once the block has closed
        // has no block to go on
        if (q.signature && !(open === "thinking" && claude)) continue
        break
      }
      const e = r.value
      if (e.text) {
        if (open !== "text") start("text", { type: "text", text: "" })
        ctl.enqueue(sse("content_block_delta", { index, delta: { type: "text_delta", text: e.text } }))
      } else if (e.reasoning) {
        if (open !== "thinking") {
          start("thinking", { type: "thinking", thinking: "", signature: "" })
          sig = ""
        }
        ctl.enqueue(sse("content_block_delta", { index, delta: { type: "thinking_delta", thinking: e.reasoning } }))
      } else if (e.signature) {
        sig += e.signature
        ctl.enqueue(sse("content_block_delta", { index, delta: { type: "signature_delta", signature: e.signature } }))
      } else if (e.tool) start("tool_use", { type: "tool_use", id: e.tool.id, name: e.tool.name, input: {} })
      else if (e.args) {
        if (open === "tool_use") ctl.enqueue(sse("content_block_delta", { index, delta: { type: "input_json_delta", partial_json: e.args.text } }))
      } else if (e.stop) {
        close()
        ctl.enqueue(sse("message_delta", { delta: { stop_reason: STOP_REASON[e.stop] ?? "end_turn", stop_sequence: null }, usage: anthropicUsage(e.tokens) }))
        ctl.enqueue(sse("message_stop", {}))
      } else if (e.error) {
        ctl.enqueue(enc.encode(`event: error\ndata: ${JSON.stringify({ type: "error", error: { type: "api_error", message: e.error.message } })}\n\n`))
        ctl.close()
      }
    },
    cancel() {
      it.return?.()
    },
  })
  return new Response(stream, { status: 200, headers: { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", "X-Magpie-Sign-In": "kept" } })
}

// ---- cache keepalive (plugins#592) -----------------------------------------------

// Devin's prompt cache lasts 5 minutes, and has no longer TTL to ask for
// (PromptCacheOptions has only type EPHEMERAL). The devin CLI keeps it warm
// (3000.11.205, cache_keepalive.rs): after a reply it sends the same
// GetChatMessage again every 285 s, with "continue" at the end and
// max_tokens 1, which reads the cache and renews it. This is the same,
// off by default (each ping is billed as a read of the whole context):
// after any reply that read or wrote the cache, up to max pings, until the
// conversation's next real request, a refusal (401, 402, 429) or two
// pings in a row that read less than half their prompt from the cache.
// Unlike the CLI's, it also runs while the user is reading, not only while
// a tool or subagent works: magpie can't tell those apart, and the issue's
// reporter wants both. The CLI's ping carries query_label
// "cache_keepalive" in its trace; this plugin labels no request, so its
// ping doesn't either.
const KEEPALIVE = "cache_keepalive"
const KEEPALIVE_INTERVAL = 285 // seconds
const KEEPALIVE_MAX = 6
const KEEPALIVE_KEPT = 32 // conversations kept warm at once; past it the oldest stops
const KEEPALIVE_STOP = new Set([401, 402, 429])

// timers are what the pings wait on, and the clock they are timed by;
// tests hand in their own. A timer is unref'd: it never keeps a process or
// a test running.
const realTimers = { set: (fn, ms) => setTimeout(fn, ms), clear: (t) => clearTimeout(t), now: () => Date.now() }
let timers = realTimers
const now = () => (timers.now ?? Date.now)()

const keeps = new Map() // conversation → {n, misses, timer, ctl}

// keepaliveSettings are the interval (ms) and the most pings, from the
// plugin's options (cacheKeepaliveInterval in seconds, 30–299;
// cacheKeepaliveMaxPings, 1–50), else the CLI's interval and 6.
function keepaliveSettings(options = {}) {
  const sec = Number(options?.cacheKeepaliveInterval)
  const max = Number(options?.cacheKeepaliveMaxPings)
  return {
    interval: (Number.isFinite(sec) && sec >= 30 && sec <= 299 ? sec : KEEPALIVE_INTERVAL) * 1000,
    max: Number.isInteger(max) && max >= 1 && max <= 50 ? max : KEEPALIVE_MAX,
  }
}

// the headers an agent names its session in, as magpie's gateway reads them;
// first magpie's own, which tells a plugin's fetch the session the agent
// named to magpie (the agent's own headers never reach the plugin through
// magpie: plugins#620)
const SESSION_HEADERS = ["x-magpie-session", "x-claude-code-session-id", "x-session-id", "session_id", "session-id", "x-opencode-session", "x-session-affinity", "x-conversation-id"]

// textsOf is a message's or system's words, without the cache marks a
// client moves forward as the history grows
const textsOf = (c) => (typeof c === "string" ? [c] : Array.isArray(c) ? c.map((b) => (typeof b === "string" ? b : typeof b?.text === "string" ? b.text : b?.type ?? "")) : [])

// keepaliveKey is the conversation a request is of: the session the agent
// names, the Claude Code subagent it is of (x-claude-code-agent-id, never
// sent for the lead's own turns), and a hash of what every turn of it
// shares: the instructions and the tools' names. A subagent's, or Claude
// Code's permission check's, instructions and tools are their own, so their
// requests never stop the lead's pings, nor the lead's theirs.
//
// The first user message is not part of it: Claude Code Auto's permission
// check sends the whole history in its first message, which grows on every
// check, and each check's key was then new, so a check left its older
// pings running beside its new ones (plugins#620, zelong77). Only a
// request that names no session is told apart by its first message too,
// as two conversations could share the rest; there, a first message that
// grew from one seen before (blocks added, or the last one's text added
// to) is still that conversation (firstOf).
function keepaliveKey(req, messages, headers) {
  let h
  try {
    h = new Headers(headers ?? {})
  } catch {
    h = new Headers()
  }
  const session = SESSION_HEADERS.map((k) => h.get(k)?.trim()).find(Boolean) ?? ""
  // the Claude Code subagent, as Claude Code names it, or as magpie tells
  // the plugin it (x-magpie-subagent)
  const agent = (h.get("x-claude-code-agent-id")?.trim() || h.get("x-magpie-subagent")?.trim()) ?? ""
  let prefix, first
  if (messages) {
    const system = textsOf(req.system).map((t) => t.replace(BILLING_LINE, ""))
    prefix = [system, (req.tools ?? []).map((t) => t?.name ?? "")]
    first = textsOf(req.messages?.[0]?.content)
  } else {
    const ms = req.messages ?? []
    const system = ms.filter((m) => m?.role === "system" || m?.role === "developer").map((m) => textsOf(m.content))
    prefix = [system, (req.tools ?? []).map((t) => t?.function?.name ?? "")]
    first = textsOf(ms.find((m) => m?.role === "user")?.content)
  }
  const group = [session, agent, sha(JSON.stringify(prefix))].join("\n")
  if (session) return group
  return firstOf(group, first)
}

const sha = (s) => createHash("sha256").update(s).digest("hex").slice(0, 32)

// firsts are the first messages of the conversations seen without a
// session, by key: each block's hash but the last's, and the last's length
// and hash, so a grown message is told without holding its text
const firsts = new Map() // key → {group, n, blocks: [hash], last: {len, hash}}
const FIRSTS_KEPT = 256

// firstOf is the key of the conversation, in group, whose first message
// first is, or grew from (the longest such one), else a new key.
function firstOf(group, first) {
  const hashes = first.map(sha)
  let best, most
  for (const [id, f] of firsts) {
    if (f.group !== group || f.n > first.length || (f.n === 0) !== (first.length === 0)) continue
    if (f.n > 0) {
      const t = first[f.n - 1]
      if (f.blocks.some((x, j) => x !== hashes[j]) || t.length < f.last.len || sha(t.slice(0, f.last.len)) !== f.last.hash) continue
    }
    if (!best || f.n > most.n || (f.n === most.n && f.last.len > most.last.len)) (best = id), (most = f)
  }
  const id = best ?? [group, sha(JSON.stringify(first))].join("\n")
  const t = first.at(-1) ?? ""
  firsts.delete(id)
  firsts.set(id, { group, n: first.length, blocks: hashes.slice(0, -1), last: { len: t.length, hash: sha(t) } })
  while (firsts.size > FIRSTS_KEPT) firsts.delete(firsts.keys().next().value)
  return id
}

// stopKeepalive stops a conversation's pings, one in flight too.
function stopKeepalive(id) {
  const k = keeps.get(id)
  if (!k) return
  keeps.delete(id)
  if (k.timer) timers.clear(k.timer)
  k.ctl?.abort()
}

function stopAllKeepalive() {
  for (const id of [...keeps.keys()]) stopKeepalive(id)
}

// the pings stop with the process that sends them (the plugin host)
let exitHooked = false
function hookExit() {
  if (exitHooked) return
  exitHooked = true
  process.once?.("exit", stopAllKeepalive)
}

// pingOnce sends a ping and reads its status and usage, and why it
// failed (error).
async function pingOnce(server, key, body, signal) {
  let res
  try {
    res = await fetch(server + CHAT_RPC, { method: "POST", headers: rpcHeaders(key, body), body, signal })
  } catch (e) {
    return { status: 0, error: String(e?.message || e || "fetch failed") }
  }
  const failed = (e) => ({ status: e.status, error: e.message })
  if (!res.ok) return failed(failure(res.status, (await res.text().catch(() => "")).slice(0, 1 << 16)))
  const tokens = { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 }
  try {
    for await (const f of frames(res.body)) {
      if (f.end) {
        const e = failure(200, dec.decode(f.data))
        if (e.status >= 300) return failed(e)
        break
      }
      for (const x of fields(f.data)) {
        if (x.num !== 7 || x.wire !== 2) continue
        for (const g of fields(x.data)) {
          if (g.wire !== 0) continue
          if (g.num === 2) tokens.input = g.n
          else if (g.num === 3) tokens.output = g.n
          else if (g.num === 4) tokens.cacheWrite = g.n
          else if (g.num === 5) tokens.cacheRead = g.n
        }
      }
    }
  } catch (e) {
    return { status: 0, error: String(e?.message || e || "the reply broke off") }
  }
  return { status: 200, tokens }
}

// reportPing tells magpie of a ping, for its request log and usage
// totals (magpie.usage, plugins#592): the pings were invisible there, as
// they never pass magpie's gateway. They go straight to Devin, as the
// gateway would re-shape the request and the cache would no longer match.
// An aborted one (a real request came) went nowhere worth counting; an
// older magpie, or OpenCode, has no magpie.usage and is told nothing.
function reportPing(keep, r, ms) {
  if (!keep.report || r.aborted) return
  const t = r.tokens ?? {}
  try {
    keep.report({ kind: KEEPALIVE, model: keep.model, account: keep.account, input: t.input, output: t.output, cacheRead: t.cacheRead, cacheWrite: t.cacheWrite, status: r.status, ms, error: r.error })
  } catch {}
}

// scheduleKeepalive starts a conversation's pings for the request msg
// just answered, sent at sentAt, in place of any it had.
//
// Each ping is timed from when the request before it was sent, the real
// one's or the ping's own, not from when it was answered: Devin renews its
// cache when it takes a request, and a reply of 30 to 47 s (Fable over half
// a million tokens), or a ping of 10 to 20 s, put the next ping past the
// cache's 5 minutes when it waited its whole interval from the end. Pings
// 315.9 s or more after the request they followed was sent missed, and
// each wrote the whole context again (plugins#626, zelong77). One that
// came back after its interval had passed is followed at once.
function scheduleKeepalive(keep, key, server, msg, sentAt = now()) {
  const { id, interval, max } = keep
  const ping = keepalivePing(msg)
  if (!ping) return
  stopKeepalive(id)
  while (keeps.size >= KEEPALIVE_KEPT) stopKeepalive(keeps.keys().next().value)
  const body = frame(ping)
  const k = { n: 0, misses: 0, timer: null, ctl: null }
  keeps.set(id, k)
  hookExit()
  const next = (from) => {
    k.timer = timers.set(run, Math.max(0, interval - Math.max(0, now() - from)))
    k.timer?.unref?.()
  }
  const run = async () => {
    k.timer = null
    if (keeps.get(id) !== k) return
    k.n++
    const ctl = (k.ctl = new AbortController())
    const at = now()
    const r = await pingOnce(server, key, body, ctl.signal)
    k.ctl = null
    reportPing(keep, { ...r, aborted: ctl.signal.aborted }, now() - at)
    if (keeps.get(id) !== k) return // a real request came, or the switch went off
    if (KEEPALIVE_STOP.has(r.status)) return stopKeepalive(id)
    const t = r.tokens
    const hit = r.status === 200 && t.cacheRead > 0 && t.cacheRead * 2 >= t.input + t.cacheRead + t.cacheWrite
    k.misses = hit ? 0 : k.misses + 1
    if (k.misses >= 2 || k.n >= max) return stopKeepalive(id)
    next(at)
  }
  next(sentAt)
}

// keptAfter passes a reply's events on, and once it has finished (any stop:
// a tool call waiting too) schedules the conversation's pings, when the
// reply read or wrote the cache: a request with nothing cached has nothing
// to keep.
async function* keptAfter(it, keep, { key, server, msg, sentAt }) {
  for await (const e of it) {
    if (e.stop && (e.tokens?.cacheRead || e.tokens?.cacheWrite)) scheduleKeepalive(keep, key, server, msg, sentAt)
    yield e
  }
}

// ---- OpenCode 2 ----------------------------------------------------------------------

// OpenCode 2 asks for a default export with an id and a setup(ctx). The
// sign-in becomes an integration's oauth methods, the provider and its
// static model list a provider transform, the account's own list a model
// transform, and the custom fetch an "sdk" hook that hands the runtime a
// LanguageModelV3 talking GetChatMessage. A v1 host calls server(), a v2
// host setup(); each wraps the same code. @opencode/plugin is only types
// and a define() that returns its argument, so the shape is spelled out
// here and the package keeps no dependency.

// v2Auth is the v1 auth object a v2 credential answers for live(): {type:
// "api", key, metadata}. OAuth credentials carry the key in access, key
// credentials in key; the CLI-sourced one keeps cli in its metadata.
function v2Auth(value) {
  if (value?.type === "oauth") return { type: "api", key: value.access, metadata: value.metadata ?? {} }
  if (value?.type === "key") return { type: "api", key: value.key, metadata: value.metadata ?? {} }
  return null
}

// v2Credential is the credential a v1 sign-in's success becomes: an OAuth
// one (its access the session token, never expiring, the account's name
// and plan in metadata as the v1 auth saved them).
function v2Credential(methodID, r) {
  return { type: "oauth", methodID, refresh: "", access: r.key, expires: 0, metadata: r.metadata }
}

// v2Chat is the chat completion a LanguageModelV3 call becomes: system
// messages as system, an assistant's tool calls as tool_calls with the
// call's input as its arguments JSON, a tool message of the results that
// follow the calls they answer. A result's own content parts go as its
// text; its images go with the next user message, as Devin's tool message
// is text only.
function v2Chat(options, modelID) {
  const messages = []
  // images a tool result carried, headed into the user message that follows
  // them (Devin's tool message is text only)
  let pending = []
  const flush = (content) => {
    if (!pending.length) return
    content.push(...pending)
    pending = []
  }
  for (const m of options.prompt ?? []) {
    if (m.role === "system") {
      messages.push({ role: "system", content: m.content })
      continue
    }
    if (m.role === "assistant") {
      let text = ""
      let reasoning = ""
      const calls = []
      for (const p of m.content ?? []) {
        if (p.type === "text") text += (text ? "\n\n" : "") + p.text
        // the reply's reasoning, which build sends back to a model that
        // isn't Claude (plugins#703)
        else if (p.type === "reasoning" && typeof p.text === "string" && p.text) reasoning += (reasoning ? "\n\n" : "") + p.text
        else if (p.type === "tool-call")
          calls.push({ id: p.toolCallId, type: "function", function: { name: p.toolName, arguments: JSON.stringify(p.input ?? {}) } })
      }
      if (!text && !calls.length) continue
      messages.push({ role: "assistant", content: text, ...(reasoning ? { reasoning_content: reasoning } : {}), ...(calls.length ? { tool_calls: calls } : {}) })
      continue
    }
    if (m.role === "tool") {
      for (const p of m.content ?? []) {
        if (p.type !== "tool-result") continue
        const { text, files } = v2ToolParts(p.output)
        messages.push({ role: "tool", tool_call_id: p.toolCallId, content: text })
        pending.push(...files)
      }
      continue
    }
    if (m.role !== "user") continue
    const content = []
    flush(content)
    for (const p of m.content ?? []) {
      if (p.type === "text") content.push({ type: "text", text: p.text })
      else if (p.type === "file") {
        const d = v2FileData(p)
        if (d) content.push({ type: "image_url", image_url: { url: d } })
      }
    }
    if (content.length) messages.push({ role: "user", content })
  }
  if (pending.length) messages.push({ role: "user", content: pending })
  return {
    model: modelID,
    messages,
    stream: true,
    max_completion_tokens: options.maxOutputTokens,
    temperature: options.temperature,
    top_p: options.topP,
    reasoning_effort: v2Effort(options),
    response_format: v2ResponseFormat(options.responseFormat),
    tools: (options.tools ?? [])
      .filter((t) => t?.type === "function" && t.name)
      .map((t) => ({ type: "function", function: { name: t.name, description: t.description ?? "", parameters: t.inputSchema } })),
    ...(options.toolChoice?.type === "none" ? { tool_choice: "none" } : {}),
  }
}

// v2Effort is the reasoning effort a call asks for: the variant's
// reasoningEffort lands in providerOptions under the provider's key
// (openai-compatible names it after the provider id).
function v2Effort(options) {
  for (const key of Object.keys(options.providerOptions ?? {})) {
    const e = options.providerOptions[key]?.reasoningEffort
    if (e) return e
  }
  return ""
}

// v2ToolParts is a tool result's output as the text its tool message takes
// and the image parts it can't — those go with the next user message, the
// way a result's images reach Devin otherwise.
function v2ToolParts(output) {
  if (!output || typeof output !== "object") return { text: String(output ?? ""), files: [] }
  if (output.type === "text" || output.type === "error")
    return { text: typeof output.value === "string" ? output.value : JSON.stringify(output.value ?? ""), files: [] }
  if (output.type === "json") return { text: JSON.stringify(output.value ?? null), files: [] }
  if (output.type === "content") {
    const texts = []
    const files = []
    for (const p of output.value ?? []) {
      if (p.type === "text") texts.push(p.text ?? "")
      else if (p.mediaType?.startsWith("image/")) {
        const d = v2FileData(p)
        if (d) files.push({ type: "image_url", image_url: { url: d } })
        else texts.push("[image]")
      } else texts.push(`[${p.mediaType || "file"}]`)
    }
    return { text: texts.join("\n"), files }
  }
  return { text: JSON.stringify(output), files: [] }
}

// v2FileData is a prompt file part as a data URL, "" for one without
// bytes.
function v2FileData(p) {
  const type = p.mediaType || "application/octet-stream"
  const d = p.data
  if (typeof d === "string") return d.startsWith("data:") || d.startsWith("http") ? d : `data:${type};base64,${d}`
  if (d instanceof Uint8Array) return `data:${type};base64,${Buffer.from(d).toString("base64")}`
  if (d instanceof URL) return d.href
  return ""
}

// v2ResponseFormat is the chat's response_format for the call's.
function v2ResponseFormat(f) {
  if (!f || f.type === "text") return undefined
  if (f.type === "json") return f.schema ? { type: "json_schema", json_schema: { name: f.name || "response", schema: f.schema } } : { type: "json_object" }
  return undefined
}

function v2Usage(u = {}) {
  const cacheRead = u.prompt_tokens_details?.cached_tokens, cacheWrite = u.prompt_tokens_details?.cache_write_tokens
  return {
    inputTokens: { total: u.prompt_tokens, noCache: u.prompt_tokens == null ? undefined : u.prompt_tokens - (cacheRead || 0) - (cacheWrite || 0), cacheRead, cacheWrite },
    outputTokens: { total: u.completion_tokens, text: undefined, reasoning: undefined },
  }
}

// devinLanguage is the LanguageModelV3 the sdk hook hands a devin model:
// its calls go through GetChatMessage as a streamed chat completion.
// getAuth resolves the account's key at call time so a sign-in, sign-out or
// account switch since setup is picked up.
function devinLanguage(modelID, getAuth) {
  return {
    specificationVersion: "v3",
    provider: "devin",
    modelId: modelID,
    supportedUrls: {},
    async doGenerate(options) {
      const auth = await getAuth()
      if (!auth?.key) throw new Error("Devin isn't signed in")
      const { key, server } = await live(auth)
      const families = await familiesFor(key, server)
      const chat = v2Chat(options, modelID)
      chat.stream = false
      const res = await complete({ key, server, families }, chat, options.abortSignal)
      const body = await res.json()
      if (!res.ok) throw new Error(body?.error?.message || `Devin: ${res.status}`)
      const msg = body.choices?.[0]?.message ?? {}
      const content = []
      if (msg.reasoning_content) content.push({ type: "reasoning", text: msg.reasoning_content })
      if (msg.content) content.push({ type: "text", text: msg.content })
      for (const c of msg.tool_calls ?? [])
        content.push({ type: "tool-call", toolCallId: c.id, toolName: c.function?.name, input: c.function?.arguments || "{}" })
      return {
        content,
        finishReason: { unified: body.choices?.[0]?.finish_reason === "tool_calls" ? "tool-calls" : body.choices?.[0]?.finish_reason === "length" ? "length" : "stop", raw: body.choices?.[0]?.finish_reason },
        usage: v2Usage(body.usage),
        warnings: [],
      }
    },
    async doStream(options) {
      const auth = await getAuth()
      if (!auth?.key) throw new Error("Devin isn't signed in")
      const { key, server } = await live(auth)
      const families = await familiesFor(key, server)
      const chat = v2Chat(options, modelID)
      const rt = await roundtrip({ key, server, families }, chat, options.abortSignal)
      if (!rt.it) throw new Error(rt.message || `Devin: ${rt.status}`)
      const stream = new ReadableStream({
        // the calls the reply has opened, by the index Devin gives their
        // args; _open is the one args deltas now belong to
        _calls: new Map(),
        _open: -1,
        _reasoning: false,
        _text: false,
        async start(ctl) {
          ctl.enqueue({ type: "stream-start", warnings: [] })
        },
        // reasoning-start and text-start open on their first delta, so a turn
        // without reasoning announces none.
        _openReasoning(ctl) {
          if (this._reasoning) return
          this._reasoning = true
          ctl.enqueue({ type: "reasoning-start", id: "r1" })
        },
        _openText(ctl) {
          if (this._text) return
          this._text = true
          ctl.enqueue({ type: "text-start", id: "t1" })
        },
        _close(ctl) {
          if (this._reasoning) ctl.enqueue({ type: "reasoning-end", id: "r1" })
          if (this._text) ctl.enqueue({ type: "text-end", id: "t1" })
        },
        async pull(ctl) {
          for (;;) {
            const r = await rt.it.next()
            if (r.done) {
              this._finish(ctl)
              return
            }
            const e = r.value
            if (e.text) {
              this._openText(ctl)
              return ctl.enqueue({ type: "text-delta", id: "t1", delta: e.text })
            }
            if (e.reasoning) {
              this._openReasoning(ctl)
              return ctl.enqueue({ type: "reasoning-delta", id: "r1", delta: e.reasoning })
            }
            if (e.tool) {
              this._open = e.tool.index
              this._calls.set(e.tool.index, { id: e.tool.id, name: e.tool.name, input: "" })
              ctl.enqueue({ type: "tool-input-start", id: e.tool.id, toolName: e.tool.name })
              return
            }
            if (e.args) {
              const c = this._calls.get(e.args.index ?? this._open)
              if (!c) continue
              c.input += e.args.text
              ctl.enqueue({ type: "tool-input-delta", id: c.id, delta: e.args.text })
              return
            }
            if (e.stop) {
              for (const [, c] of this._calls) {
                ctl.enqueue({ type: "tool-input-end", id: c.id })
                ctl.enqueue({ type: "tool-call", toolCallId: c.id, toolName: c.name, input: c.input || "{}" })
              }
              this._calls.clear()
              this._close(ctl)
              ctl.enqueue({ type: "finish", finishReason: { unified: e.stop === "tool_calls" ? "tool-calls" : e.stop === "length" ? "length" : "stop", raw: e.stop }, usage: v2Usage(e.usage) })
              ctl.close()
              return
            }
            if (e.error) {
              ctl.enqueue({ type: "error", error: new Error(e.error.message) })
              ctl.close()
              return
            }
          }
        },
        _finish(ctl) {
          for (const [, c] of this._calls) {
            ctl.enqueue({ type: "tool-input-end", id: c.id })
            ctl.enqueue({ type: "tool-call", toolCallId: c.id, toolName: c.name, input: c.input || "{}" })
          }
          this._calls.clear()
          this._close(ctl)
          ctl.enqueue({ type: "finish", finishReason: { unified: "stop", raw: "stop" }, usage: v2Usage() })
          ctl.close()
        },
        cancel() {
          rt.it.return?.()
        },
      })
      return { stream }
    },
  }
}

// v2Models is a listed()'s entries as v2 Model.Info's.
function v2Models(families, keep, images, free, prices) {
  return listed(families, keep, images, free, prices).map((m) => ({
    id: m.id,
    modelID: m.id,
    providerID: ID,
    name: m.name,
    capabilities: { tools: true, input: m.image ?? seesImages(m.id) ? ["text", "image"] : ["text"], output: ["text"], temperature: true },
    variants: m.efforts.map((e) => ({ id: e, settings: { reasoningEffort: e } })),
    time: { released: 0 },
    cost: [{ input: m.cost?.input ?? 0, output: m.cost?.output ?? 0, cache: { read: m.cost?.cache?.read ?? 0, write: 0 } }],
    status: "active",
    enabled: true,
    limit: { context: m.context, output: m.output },
  }))
}

// connKey identifies a connection the way OpenCode does, so a refetched
// record of the same sign-in isn't taken for a switch.
function connKey(c) {
  if (!c) return ""
  return c.type === "credential" ? `credential:${c.id}` : `env:${c.name}`
}

// v2Setup is the plugin's v2 half: the integration and its sign-in
// methods, the provider and its static list, and the sdk hook that serves
// the account's chats through GetChatMessage.
async function v2Setup(ctx) {
  const source = { connection: undefined, auth: null }

  await ctx.integration.transform((editor) => {
    editor.method.update({
      integrationID: ID,
      method: { id: "browser", type: "oauth", label: "Devin (browser)" },
      async authorize() {
        const a = await browserSignIn()
        return {
          url: a.url,
          instructions: a.instructions,
          mode: "auto",
          callback: a.callback().then((r) => {
            if (r?.type !== "success") throw new Error(r?.error || "the sign-in failed")
            return v2Credential("browser", r)
          }),
        }
      },
      label: (c) => c?.metadata?.email || "Devin",
    })
    editor.method.update({
      integrationID: ID,
      method: { id: "cli", type: "oauth", label: "Devin CLI's sign-in" },
      async authorize() {
        const a = await cliSignIn()
        return {
          url: "",
          instructions: a.instructions,
          mode: "auto",
          callback: a.callback().then((r) => {
            if (r?.type !== "success") throw new Error(r?.error || "the sign-in failed")
            return v2Credential("cli", r)
          }),
        }
      },
      label: (c) => c?.metadata?.email || "Devin",
    })
    // a key typed in, as the v1 "api" method saves it (v2Auth reads it)
    editor.method.update({ integrationID: ID, method: { type: "key", label: "Devin API key (cog_…)" } })
  })

  // authFor resolves the active connection's key each call, so a chat goes
  // out on the account that is signed in when it is made, not the one setup
  // saw: a sign-in, a sign-out or a switch of accounts is picked up without
  // a reload.
  const authFor = async () => {
    const connection = await ctx.integration.connection.active(ID)
    if (!connection) return null
    const value = await ctx.integration.connection.resolve(connection).catch(() => null)
    return v2Auth(value)
  }

  // The provider's list: SNAPSHOT's until the account's own arrives, then
  // that — so a model the account lists that the snapshot never heard of is
  // a model "opencode models" shows. The provider transform re-runs on each
  // reload, reading whatever source.models refresh() last set.
  await ctx.provider.transform((editor) => {
    editor.add({
      info: {
        id: ID,
        integrationID: ID,
        name: "Devin",
        activation: "auto",
        // a version suffix keeps AISDKNative from rewriting the package to the
        // native openai-compatible provider, which the sdk hook can't reach
        package: "aisdk:@ai-sdk/openai-compatible@2.0.41",
        settings: { baseURL: BASE },
      },
      models: source.models ?? v2Models(familiesOf(SNAPSHOT), [], SNAPSHOT_IMAGES),
      sourceConnection: source.connection,
    })
  })

  // refresh re-reads the account: a sign-in arms the sdk hook, a sign-out
  // disarms it, and the account's own model list replaces the snapshot's.
  // Its network asks (images, configs, families) run off the setup path.
  let refreshing = null
  let stale = false
  const refresh = () => {
    refreshing ??= (async () => {
      try {
        const connection = await ctx.integration.connection.active(ID)
        source.connection = connection
        if (!connection) {
          source.auth = null
          source.models = null
          await ctx.provider.reload()
          return
        }
        const value = await ctx.integration.connection.resolve(connection).catch(() => null)
        source.auth = v2Auth(value)
        if (!source.auth?.key) {
          source.models = null
          await ctx.provider.reload()
          return
        }
        const { key, server } = await live(source.auth)
        const [images, { free, prices }, families] = await Promise.all([
          imagesFor(key, server).catch(() => null),
          configsFor(key, server).catch(() => ({})),
          ownFamilies(key, server).catch(() => null),
        ])
        source.models = v2Models(families ?? familiesOf(SNAPSHOT), [], images ?? SNAPSHOT_IMAGES, free, prices)
        // the account may have signed out or switched while the asks ran:
        // its list then belongs to the connection the reads answered, so
        // drop it and take the new account's turn next.
        if (connKey(await ctx.integration.connection.active(ID)) !== connKey(connection)) {
          source.models = null
          stale = true
          return
        }
        await ctx.provider.reload()
        await ctx.model.reload()
      } finally {
        refreshing = null
        if (stale) {
          stale = false
          void refresh()
        }
      }
    })()
    return refreshing
  }

  // The models a chat is sent to Devin as, and the key it goes with. The
  // SDK the package's own factory made is replaced wholesale: every call
  // goes through GetChatMessage, resolving the active account at call time.
  await ctx.aisdk.hook(
    "sdk",
    (evt) => {
      if (!source.auth?.key) return
      evt.sdk = { languageModel: (id) => devinLanguage(id, authFor) }
    },
    { providerID: ID },
  )

  // A sign-in, sign-out or account switch re-reads the account and reloads
  // the provider list it publishes.
  if (ctx.event?.subscribe)
    void (async () => {
      try {
        for await (const event of ctx.event.subscribe())
          if (event?.type === "credential.switched" && event?.data?.integrationID === ID) await refresh()
      } catch {}
    })()

  // Setup registers the hooks and returns; the account's first read happens
  // in the background so Devin being unreachable doesn't stall the host.
  void refresh()
}

export default {
  id: "devin",
  async setup(ctx) {
    await v2Setup(ctx)
  },
  async server(input, options) {
    return DevinAuthPlugin(input, options)
  },
}

// ---- the plugin ---------------------------------------------------------------------

// ---- usage -----------------------------------------------------------------

// userStatus asks GetUserStatus about the key's account.
function userStatus(key, server) {
  return fetch(server + "/exa.seat_management_pb.SeatManagementService/GetUserStatus", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Connect-Protocol-Version": "1" },
    body: JSON.stringify({
      metadata: { ideName: "devin-cli", ideVersion: CLI_VERSION, extensionName: "devin-cli", extensionVersion: CLI_VERSION, apiKey: key, locale: "en", os: osName() },
    }),
    signal: AbortSignal.timeout(15_000),
  })
}

// usage is the account's plan and how much of its quota is gone, as
// GetUserStatus (what the CLI's /usage reads) tells them: the plan's name
// and end, the daily and weekly quotas a quota-billed plan has (the share
// left of each, and when it comes back), the ACUs a plan with a limit has
// used this cycle, and the extra usage balance. JSON leaves out what is
// zero, so a quota-billed plan's quota with a reset and no share is used
// up. magpie's
// built-in Devin account showed none of this. The day and the week don't
// count the models Devin says are free (notModels): with them used up,
// SWE-2 still answers, and magpie sends it to the account.
const SIGNED_OUT = "Devin's sign-in has expired — sign in again"
async function usage(key, server, onStatus) {
  const res = await userStatus(key, server)
  const text = await res.text()
  if (res.status === 401 || failure(res.status, text).status === 401)
    return { error: SIGNED_OUT, windows: [] }
  if (!res.ok) return { error: failure(res.status, text).message, windows: [] }
  const u = JSON.parse(text || "{}")?.userStatus ?? {}
  await onStatus?.(u)
  const st = u.planStatus ?? {}
  const info = st.planInfo ?? {}
  const num = (v) => (typeof v === "number" ? v : typeof v === "string" && v.trim() && !isNaN(Number(v)) ? Number(v) : 0)
  // no plan: the row keeps the one `devin auth status` gave the sign-in
  // ("Devin Pro"), as magpie's built-in row said it, not planName's "Pro"
  const out = { windows: [] }
  if (st.planEnd) out.until = st.planEnd
  // a quota's window is shown when Devin says what is left of it. JSON
  // leaves a 0 out, so on a quota-billed plan a window with a reset and no
  // share left is used up: a week at 0% left came as no weeklyQuota-
  // RemainingPercent beside the day's 100, and the day alone was shown
  // (面条 on magpie's Discord). Billed otherwise, a missing share is no quota.
  const quota = info.billingStrategy === "BILLING_STRATEGY_QUOTA"
  for (const [name, span, left, reset, hide] of [
    ["1 day", 24 * 3600, st.dailyQuotaRemainingPercent, st.dailyQuotaResetAtUnix, info.hideDailyQuota],
    ["7 days", 7 * 24 * 3600, st.weeklyQuotaRemainingPercent, st.weeklyQuotaResetAtUnix, info.hideWeeklyQuota],
  ]) {
    const at = num(reset)
    if (hide || ((left === undefined || left === null) && !(quota && at > 0))) continue
    out.windows.push({ name, used: Math.min(100, Math.max(0, 100 - num(left))), span, ...(at > 0 ? { resetsAt: at } : {}) })
  }
  // with Devin's word on its models unread, which are free is unknown, so
  // the day and the week count them all (a used-up quota then holds SWE-2
  // too). Ask in the background so a slow model list doesn't hide quota
  // GetUserStatus already returned; a later refresh adds free models or
  // says why the list couldn't be read.
  if (out.windows.length) {
    const free = await freeIDs(key, server, false)
    if (free.length) for (const w of out.windows) w.notModels = free
    else {
      const c = await configsFor(key, server, false)
      if (c.error && !c.at) out.windows.push({ name: "Free models", display: "unknown: Devin's model list couldn't be read (" + c.error + ")", aside: true })
    }
  }
  const limit = num(st.acuLimit)
  if (limit > 0) {
    const used = num(st.acuConsumed)
    out.windows.push({ name: "ACUs", used: Math.min(100, (100 * used) / limit), display: `${+used.toFixed(2)} / ${+limit.toFixed(2)} ACUs`, ...(st.planEnd ? { resetsAt: st.planEnd } : {}), aside: true })
  }
  const extra = num(st.overageBalanceMicros)
  if (extra > 0) out.balance = "$" + (extra / 1e6).toFixed(2)
  return out
}

// freeIDs are the ids of key's account's free models (parseFree) as magpie
// may ask for them: each variant's own, and each entry of the list that
// stands for free variants alone (swe-2 for swe-2-high, -medium and -max).
// None when Devin hasn't said.
async function freeIDs(key, server, wait = true) {
  const c = await configsFor(key, server, wait)
  if (!c.free?.size) return []
  const ids = new Set(c.free)
  for (const m of listed(c.families ?? [], [], {}, c.free)) if (m.free) ids.add(m.id)
  return [...ids]
}

// serverOf is the API server an account's requests go to:
// WINDSURF_API_SERVER_URL moves it, as it does the CLI's.
const serverOf = (auth) => (process.env.WINDSURF_API_SERVER_URL || auth?.metadata?.server || SERVER).replace(/\/+$/, "")

// live is the key and server an account has now: one taken from the CLI's
// sign-in reads credentials.toml again, as a `devin auth login` since may
// have changed it, and keeps the ones it was saved with while the CLI has
// none.
async function live(auth) {
  if (auth?.metadata?.cli) {
    try {
      const c = readCredentials(await readFile(cliCredentialsPath(), "utf8"))
      if (c.windsurf_api_key)
        return { key: c.windsurf_api_key, server: (process.env.WINDSURF_API_SERVER_URL || c.api_server_url || SERVER).replace(/\/+$/, "") }
    } catch {}
  }
  return { key: auth?.key, server: serverOf(auth) }
}

export async function DevinAuthPlugin({ client, magpie } = {}, options = {}) {
  // each ping, to magpie's request log (an older magpie has no usage)
  const report = typeof magpie?.usage === "function" ? (call) => magpie.usage(ID, call) : null
  // the cache keepalive: magpie's switch, or in OpenCode the plugin's
  // option cacheKeepalive: true
  const keepOn = () => magpie?.option?.(ID, KEEPALIVE) === true || options?.cacheKeepalive === true
  return {
    auth: {
      provider: ID,
      async loader(getAuth) {
        const auth = await getAuth()
        if (auth?.type !== "api" || !auth.key) return {}
        return {
          baseURL: BASE,
          apiKey: auth.key,
          async fetch(input, init = {}) {
            const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url
            const path = new URL(url).pathname
            const messages = /\/messages$/.test(path)
            const now = await getAuth()
            if (now?.type !== "api" || !now.key) return (messages ? anthropicError : errorResponse)({ status: 401, message: "Devin isn't signed in" })
            if (!messages && !/\/chat\/completions$/.test(path)) {
              const e = { status: 404, message: "only chat completions and messages are served" }
              return /\/messages\//.test(path) ? anthropicError(e) : errorResponse(e)
            }
            let chat
            try {
              const b = init.body ?? (input instanceof Request ? await input.clone().text() : undefined)
              chat = JSON.parse(typeof b === "string" ? b : dec.decode(b))
            } catch {
              return (messages ? anthropicError : errorResponse)({ status: 400, message: "a request that isn't JSON" })
            }
            // a real request for a conversation stops its pings; its own
            // reply starts them again
            let keep
            const on = keepOn()
            if (!on) stopAllKeepalive()
            else {
              const id = keepaliveKey(chat, messages, init.headers ?? (input instanceof Request ? input.headers : undefined))
              stopKeepalive(id)
              // the model and account the pings are reported as: the
              // request's, as magpie names them while it is in hand
              keep = { id, ...keepaliveSettings(options), report, model: chat.model, account: magpie?.account?.(ID) }
            }
            const { key, server } = await live(now)
            const families = await familiesFor(key, server)
            return (messages ? completeMessages : complete)({ key, server, families, keep }, chat, init.signal)
          },
        }
      },
      methods: [
        { type: "oauth", label: "Devin (browser)", authorize: browserSignIn },
        { type: "oauth", label: "Devin CLI's sign-in", authorize: cliSignIn },
        // a key made in Devin's settings (a service user's cog_…, or a
        // session token): sent as the sign-ins' token is, never renewed;
        // the first usage read names the account (syncOrg)
        { type: "api", label: "Devin API key (cog_…)", placeholder: "cog_…" },
      ],
      // magpie's own switches (OpenCode never reads auth.options)
      options: [
        {
          key: KEEPALIVE,
          label: "Keep the cache warm",
          description: "Devin keeps a prompt cache for 5 minutes. When on, after a reply the conversation is sent again with max_tokens 1 every 285 s, up to 6 times, so a later turn reads the cache. Each ping is billed as a cache read of the whole context and shown in Usage. Interval and count: Plugins › Options.",
          labels: { zh: "缓存保活", "zh-TW": "快取保活", ja: "キャッシュを保持", de: "Cache warm halten" },
          descriptions: {
            zh: "Devin 的提示词缓存只保留 5 分钟。开启后，每次回复结束会每 285 秒以 max_tokens 1 重发一次对话，最多 6 次，让之后的回合读取缓存而不是重写。每次保活都按整段上下文的缓存读取计费，并在用量里记为「缓存保活」。间隔和次数在插件 › 选项里改。",
            "zh-TW": "Devin 的提示詞快取只保留 5 分鐘。開啟後，每次回覆結束會每 285 秒以 max_tokens 1 重送一次對話，最多 6 次，讓之後的回合讀取快取而不是重寫。每次保活都以整段上下文的快取讀取計費，並在用量裡記為「快取保活」。間隔和次數在外掛 › 選項裡改。",
            ja: "Devin のプロンプトキャッシュは 5 分しか保持されません。オンにすると、返信のあと 285 秒ごとに会話を max_tokens 1 で再送し（最大 6 回）、次のターンがキャッシュを読めるようにします。各 ping はコンテキスト全体のキャッシュ読み取りとして課金され、使用量に表示されます。間隔と回数はプラグイン › オプションで変更できます。",
            de: "Devin hält einen Prompt-Cache nur 5 Minuten. Ist dies an, wird das Gespräch nach einer Antwort alle 285 s mit max_tokens 1 erneut gesendet, bis zu 6-mal. Jeder Ping wird als Cache-Lesen des ganzen Kontexts berechnet und unter Nutzung gezeigt. Intervall und Anzahl: Erweiterungen › Optionen.",
          },
        },
      ],
      // magpie's: the plan and how much of its quota is gone. The built-in
      // read none, so no read marks the account or clears it, not even a
      // key Devin turned away.
      async usage(getAuth) {
        const auth = await getAuth()
        if (auth?.type !== "api" || !auth.key) return { error: "Devin isn't signed in", signIn: "kept" }
        const { key, server } = await live(auth)
        const syncOrg = async (u) => {
          if (!client?.auth?.set) return
          const who = whoOfStatus(u)
          if (!who) return
          const md = { ...(auth.metadata ?? {}) }
          let changed = key !== auth.key
          if (who.user && md.email !== who.user) {
            md.email = who.user
            changed = true
          }
          const orgId = who.orgId || who.teamId
          if (orgId && md.orgId !== orgId) {
            md.orgId = orgId
            changed = true
          }
          if (who.teamId && md.teamId !== who.teamId) {
            md.teamId = who.teamId
            changed = true
          }
          if (changed) {
            try {
              await client.auth.set({ path: { id: ID }, body: { ...auth, key, metadata: md } })
            } catch {}
          }
        }
        // a key Devin refuses marks the account signed out, so magpie
        // passes over it and its row offers Sign in again; a clean read
        // takes the mark off. Any other failure keeps it.
        const u = await usage(key, server, syncOrg)
        return { ...u, signIn: u.error === SIGNED_OUT ? "expired" : u.error ? "kept" : "renewed" }
      },
    },
    async config(config) {
      config.provider ??= {}
      const was = config.provider[ID] ?? {}
      config.provider[ID] = {
        name: "Devin",
        npm: CHAT,
        api: BASE,
        ...was,
        models: { ...Object.fromEntries(listed(familiesOf(SNAPSHOT), [], SNAPSHOT_IMAGES).map((m) => [m.id, configModel(m)])), ...(was.models ?? {}) },
      }
    },
    // the account's list, as Devin or the devin CLI gives it (familiesFor),
    // with what Devin says of each model's images; with neither, the list
    // it was given with that
    provider: {
      id: ID,
      async models(provider, { auth } = {}) {
        if (auth?.type !== "api" || !auth.key) return provider.models
        const { key, server } = await live(auth)
        const images = await imagesFor(key, server)
        const { free, prices } = await configsFor(key, server)
        const families = await ownFamilies(key, server)
        // neither Devin nor the CLI named the account's models: the list
        // is the snapshot's, so magpie keeps the account's last good list
        // (and the models the user picked from it) over this one
        if (!families) return fellBack(withImages(provider.models, listed(familiesOf(SNAPSHOT), Object.keys(provider?.models ?? {}), images)))
        return Object.fromEntries(listed(families, Object.keys(provider?.models ?? {}), images, free, prices).map((m) => [m.id, runtimeModel(m)]))
      },
    },
  }
}

// for tests
export const _internal = { imageType, estimate, windowOf, TOO_LONG_AT, sigTypeOf, forgetSigTypes: () => sigTypes.clear(), forgetThoughts: () => thoughts.clear(), thoughtFor, keepaliveKey, keepaliveSettings, keepalivePing, scheduleKeepalive, stopKeepalive, stopAllKeepalive, keeping: () => [...keeps.keys()], useTimers: (t) => (timers = t ?? realTimers), KEEPALIVE, buildMessages, completeMessages, anthropicEffort, encodeMsg, parseFree, parsePrices, geminiSchema, freeIDs, outID, inID, objectRoot, seesImages, imagesFor, forgetSaid: () => said.clear(), parseModelConfigs, parseConfigFamilies, SNAPSHOT_IMAGES, withImages, forgetImages: () => (seen = null), effortOf, runtimeModel, configModel, live, build, failure, complete, parseFamilies, listed, variantFor, familiesOf, SNAPSHOT, parseStatus, readsHome, tierName, whoOfStatus, whoByKey, success, familiesFor, readCredentials, credentials, fields, frame, PB, events, frames, v2Chat, v2ToolParts, v2FileData, v2Effort, v2ResponseFormat, v2Usage, v2Auth, v2Credential, v2Models, devinLanguage, v2Setup, connKey }
